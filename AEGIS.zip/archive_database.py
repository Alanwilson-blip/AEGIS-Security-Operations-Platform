import pyodbc

SERVER = r"MR\SQLEXPRESS"
ARCHIVE_DATABASE = "AEGIS_DB"


def get_archive_connection():
    connection_string = (
        "DRIVER={ODBC Driver 18 for SQL Server};"
        f"SERVER={SERVER};"
        f"DATABASE={ARCHIVE_DATABASE};"
        "Trusted_Connection=yes;"
        "TrustServerCertificate=yes;"
    )

    connection = pyodbc.connect(
        connection_string,
        autocommit=False
    )

    try:
        cursor = connection.cursor()
        cursor.execute("SELECT DB_NAME()")
        actual_database = cursor.fetchone()[0]
        cursor.close()

        if actual_database != ARCHIVE_DATABASE:
            raise RuntimeError(
                f"SAFETY CHECK FAILED: Expected {ARCHIVE_DATABASE}, "
                f"connected to {actual_database!r}."
            )

        return connection

    except Exception:
        connection.close()
        raise


def get_archive_dry_run_report():
    """
    Read-only archive eligibility preview.
    Does not insert, update, or delete records.
    Uses AEGIS_DB only.
    """
    connection = get_archive_connection()
    cursor = connection.cursor()

    try:
        cursor.execute("SELECT DB_NAME()")
        database_name = cursor.fetchone()[0]

        if database_name != "AEGIS_DB":
            raise RuntimeError(
                f"Safety check failed: connected to {database_name}"
            )

        report = {
            "database": database_name,
            "old_events": 0,
            "eligible_incidents": 0,
            "blocked_incidents": 0,
        }

        cursor.execute("""
            SELECT COUNT_BIG(*)
            FROM dbo.access_events
            WHERE event_timestamp < DATEADD(
                HOUR, -24, SYSDATETIME()
            )
        """)
        report["old_events"] = cursor.fetchone()[0]

        cursor.execute("""
            SELECT
                SUM(CASE WHEN
                    i.status = 'RESOLVED'
                    AND inv.status = 'COMPLETED'
                    AND i.resolved_at IS NOT NULL
                    AND inv.completed_at IS NOT NULL
                    AND inv.completed_at >= i.resolved_at
                    AND i.resolved_at <= DATEADD(
                        DAY, -7, SYSDATETIME()
                    )
                    THEN 1 ELSE 0
                END) AS eligible_count,
                SUM(CASE WHEN NOT (
                    i.status = 'RESOLVED'
                    AND inv.status = 'COMPLETED'
                    AND i.resolved_at IS NOT NULL
                    AND inv.completed_at IS NOT NULL
                    AND inv.completed_at >= i.resolved_at
                    AND i.resolved_at <= DATEADD(
                        DAY, -7, SYSDATETIME()
                    )
                ) OR inv.investigation_id IS NULL
                    THEN 1 ELSE 0
                END) AS blocked_count
            FROM dbo.incidents i
            LEFT JOIN dbo.investigations inv
                ON inv.incident_id = i.incident_id
        """)

        row = cursor.fetchone()
        report["eligible_incidents"] = row[0] or 0
        report["blocked_incidents"] = row[1] or 0

        return report

    finally:
        cursor.close()
        connection.close()


if __name__ == "__main__":
    result = get_archive_dry_run_report()

    print("\n=== AEGIS ARCHIVE DRY RUN ===")
    for key, value in result.items():
        print(f"{key}: {value}")