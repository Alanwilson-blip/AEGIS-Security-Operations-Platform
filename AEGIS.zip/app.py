# =====================================================
# Security Log Analyzer
# Version : 3(under construction )

# =====================================================
from datetime import datetime
import time
import threading
db_lock = threading.Lock()
import threading
processing = False
processing_lock = threading.Lock()
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler
from storage.storage_manager import (
    initialize_storage,
    load_all,
    save_all,
    get_setting
)
from analyzer.statistics import (
    count_devices,
    count_incidents_by_severity,
    find_most_targeted_user,
    calculate_average_trust,
    count_investigation_decisions
)

# =====================================================
# SECURITY CONSTANTS
# =====================================================
last_processed_line = 0
BRUTE_FORCE_WINDOW = 120          # seconds
IMPOSSIBLE_TRAVEL_WINDOW = 7200   # seconds (2 hours)

DEFAULT_TRUST_SCORE = 50
MAX_TRUST_SCORE = 100
MIN_TRUST_SCORE = 0

TRUST_REWARD = 2
UNKNOWN_COUNTRY_PENALTY = 10
IMPOSSIBLE_TRAVEL_PENALTY = 30

BRUTE_FORCE_POINTS = 40
UNKNOWN_DEVICE_POINTS = 20
UNKNOWN_COUNTRY_POINTS = 30
VPN_POINTS = 25
IMPOSSIBLE_TRAVEL_POINTS = 50

# =====================================================
# MODULE 1 - LOG PARSING
# =====================================================
def create_login_event(
    log_time,
    username,
    event,
    ip_address,
    country,
    device,
    browser,
    vpn
):

    return {
        "timestamp": log_time,
        "username": username,
        "event": event,
        "ip_address": ip_address,
        "country": country,
        "device": device,
        "browser": browser,
        "vpn": vpn
    }

# =====================================================
# MODULE 2 - THREAT DETECTION
# =====================================================
def detect_brute_force(accounts, username, login_event):

    current_time = login_event["timestamp"]
    failed_count = 0

    for login in reversed(accounts[username]["login_history"]):

        previous_time = login["timestamp"]

        time_difference = current_time - previous_time

        seconds = time_difference.total_seconds()

        if seconds <= BRUTE_FORCE_WINDOW:

            if login["event"] == "Failed Login":
                failed_count += 1

        else:
            break

    if failed_count >= 4:
      return True, failed_count

    return False, failed_count

def detect_unknown_country(accounts, username, country):

    if country in accounts[username]["known_countries"]:
        return False

    return True
# =====================================================
# MODULE 3 - DEVICE MANAGEMENT
# =====================================================
def check_authorized_location(
    accounts,
    username,
    login_event
):

    contexts = accounts[username].get(
        "authorized_contexts",
         []
    )

    login_country = (
        str(login_event["country"])
        .strip()
        .lower()
    )

    login_time = login_event["timestamp"]

    for context in contexts:

        context_country = (
            str(context.get("country", ""))
            .strip()
            .lower()
        )

        if context_country != login_country:
            continue

        try:

            start_date = datetime.strptime(
                context["start_date"],
                "%Y-%m-%d"
            ).date()

            end_date = datetime.strptime(
                context["end_date"],
                "%Y-%m-%d"
            ).date()

        except (KeyError, ValueError):
            continue

        if start_date <= login_time.date() <= end_date:

            return True, context

    return False, None
def process_device(
    accounts,
    username,
    device,
    login_event
):

    known_devices = accounts[username]["known_devices"]
    pending_devices = accounts[username]["pending_devices"]
    blocked_devices = accounts[username]["blocked_devices"]

    if device in known_devices:
        return "KNOWN"

    if device in blocked_devices:
        return "BLOCKED"
    if device in pending_devices:
        update_pending_device(
           accounts,
           username,
           device,
          login_event
)

        return "PENDING"
    create_pending_device(
        accounts,
        username,
         device,
        login_event
)

    return "PENDING"
def create_pending_device(
    accounts,
    username,
    device,
    login_event
):

     accounts[username]["pending_devices"][device] = {
        "first_seen": login_event["timestamp"],

        "last_seen": login_event["timestamp"],

        "attempt_count": 1,

        "countries": [
               login_event["country"]
         ],

        "browsers": [
               login_event["browser"]
         ],

        "vpn_history": [
               login_event["vpn"]
        ],

        "status": "Pending",
        "incident_id" : None
    }
def update_pending_device(
          accounts,
          username,
          device,
          login_event
):

         pending_device = accounts[username]["pending_devices"][device]

         pending_device["last_seen"] = login_event["timestamp"]

         pending_device["attempt_count"] += 1

         if login_event["country"] not in pending_device["countries"]:

            pending_device["countries"].append(
            login_event["country"]
        )
         if login_event["browser"] not in pending_device["browsers"]:

             pending_device["browsers"].append(
             login_event["browser"]
        )
         if login_event["vpn"] not in pending_device["vpn_history"]:

            pending_device["vpn_history"].append(
            login_event["vpn"]
        )
           
def update_pending_risk(
    accounts,
    username,
    device,
    risk_score,
    severity,
    recommended_actions,
    detection_reasons
):

    pending_device = accounts[username]["pending_devices"][device]

    pending_device["risk_score"] = risk_score

    pending_device["severity"] = severity

    pending_device["recommended_actions"] = (
        recommended_actions.copy()
    )

    pending_device["detection_reasons"] = (
        detection_reasons.copy()
    )

# =====================================================
# MODULE 5 - ADMINISTRATOR OPERATIONS
# =====================================================
def approve_device(
    accounts,
    username,
    device,
    investigation_history,
    decision_log
):

    pending_device = accounts[username]["pending_devices"][device]
    pending_device["status"] = "Known"
    pending_device["approved_at"] = datetime.now()
    archive_investigation(
             investigation_history,
            pending_device,
            username,
            device,
            "Approved"
    )
    log_decision(
             decision_log,
             pending_device,
             username,
             device,
             "Approved"
)


    accounts[username]["known_devices"][device] = pending_device
    accounts[username]["known_devices"][device]["trust_score"] =  DEFAULT_TRUST_SCORE

    del accounts[username]["pending_devices"][device]

def block_device(
    accounts,
    username,
    device,
    investigation_history,
    decision_log
):
    pending_device = accounts[username]["pending_devices"][device]
    pending_device["status"] = "Blocked"
    pending_device["blocked_at"] = datetime.now()
    archive_investigation(
             investigation_history,
             pending_device,
             username,
             device,
             "Blocked"
    )
    log_decision(
             decision_log,
             pending_device,
             username,
             device,
             "Blocked"
)

    accounts[username]["blocked_devices"][device] = pending_device

    del accounts[username]["pending_devices"][device]

def archive_investigation(
    investigation_history,
    pending_device,
    username,
    device,
    decision    
):
    investigation = {
    "incident_id": pending_device["incident_id"],

    "username": username,

    "device": device,

    "administrator": "Admin",

    "decision": decision,

    "decision_time": datetime.now(),

    "risk_score": pending_device["risk_score"],

    "severity": pending_device["severity"],

    "countries": pending_device["countries"],

    "browsers": pending_device["browsers"],

    "vpn_history": pending_device["vpn_history"],

    "recommended_actions": pending_device["recommended_actions"],
    "detection_reasons": pending_device.get(
      "detection_reasons",
       []
    )
}     
    investigation_history.append(investigation)

def log_decision(
    decision_log,
    pending_device,
    username,
    device,
    decision
):

    decision_entry = {

        "incident_id": pending_device["incident_id"],

        "username": username,

        "device": device,

        "decision": decision,

        "administrator": "Admin",

        "decision_time": datetime.now()

    }

    decision_log.append(decision_entry)


# =====================================================
# MODULE 4 - TRUST ENGINE
# =====================================================
def increase_trust(
    accounts,
    username,
    device,
    points

):

    accounts[username]["known_devices"][device]["trust_score"] += points

    if accounts[username]["known_devices"][device]["trust_score"] >  MAX_TRUST_SCORE:

        accounts[username]["known_devices"][device]["trust_score"] =  MAX_TRUST_SCORE

def decrease_trust(
    accounts,
    username,
    device,
    points
    
):
    accounts[username]["known_devices"][device]["trust_score"] -= points

    if accounts[username]["known_devices"][device]["trust_score"] <  MIN_TRUST_SCORE:
        accounts[username]["known_devices"][device]["trust_score"] =  MIN_TRUST_SCORE

def evaluate_trust(
    accounts,
    username,
    device
):

    trust_score = accounts[username]["known_devices"][device]["trust_score"]

    if trust_score >= 80:
        print("✅ Highly Trusted Device")

    elif trust_score >= 50:
        print("🟢 Trusted Device")

    elif trust_score >= 20:
        print("🟡 Trust Decreasing - Review Recommended")

    else:
        print("🔴 Critical Trust Level")

def print_pending_device_report(
    accounts,
    username,
    device
):

    pending_device = accounts[username]["pending_devices"][device]

    print("\n====================================")
    print("PENDING DEVICE REVIEW")
    print("====================================")

    print("Incident ID   :", pending_device["incident_id"])
    print("Username      :", username)
    print("Device        :", device)
    print("Status        :", pending_device["status"])

    print("First Seen    :", pending_device["first_seen"])
    print("Last Seen     :", pending_device["last_seen"])
    print("Attempts      :", pending_device["attempt_count"])

    print("\nCountries")
    print("----------")

    for country in pending_device["countries"]:
           print("•", country)

    print("\nBrowsers")
    print("---------")

    for browser in pending_device["browsers"]:

       print("•", browser)

    print("\nVPN History")
    print("-----------")

    for vpn in pending_device["vpn_history"]:
         print("•", vpn)


def build_pending_queue(accounts):
    pending_queue = []
    for username in accounts:
        pending_devices = accounts[username]["pending_devices"]
        for device in pending_devices:
            pending_queue.append(
                (
                    username,
                    device,
                    pending_devices[device]
                )
            )
    pending_queue.sort(

        key=lambda item: item[2]["risk_score"],
        reverse=True
        )
    return pending_queue
def print_pending_queue(pending_queue):

    print("\n====================================")
    print("PENDING DEVICE QUEUE")
    print("====================================")

    if len(pending_queue) == 0:

        print("No pending devices.")

        return

    for index, item in enumerate(pending_queue, start=1):

        username = item[0]
        device = item[1]
        pending_device = item[2]

        print("\n------------------------------------")
        print("Device #", index)

        print("Username :", username)
        print("Device   :", device)

        print("Risk     :", pending_device["risk_score"])
        print("Severity :", pending_device["severity"])

def print_admin_result(
    username,
    device,
    action,
    destination
):

    print("\n====================================")
    print(f"DEVICE {action}")
    print("====================================")
    print("Username :", username)
    print("Device   :", device)
    print("Moved To :", destination)
def review_pending_device(
    pending_queue,
    index
):

    if index < 0 or index >= len(pending_queue):

        print("Invalid device selection.")

        return

    username = pending_queue[index][0]
    device = pending_queue[index][1]
    pending_device = pending_queue[index][2]

    print_pending_device_report(
        accounts,
        username,
        device
    )
    print("\n====================================")
    print("ADMINISTRATOR OPTIONS")
    print("====================================")
    print("[A] Approve Device")
    print("[B] Block Device")
    print("[S] Skip")

    decision = input("\nEnter Choice: ").lower()
    if decision == "a":
       confirm = input(
          "\nApprove this device? (Y/N): "
        ).lower()

       if confirm == "y":

             approve_device(
               accounts,
               username,
               device,
               investigation_history,
               decision_log
            )

             print_admin_result(
                           username,
                           device,
                           "APPROVED",
                           "Known Devices"
             )
             print("\nTrust Score")
             print(
                accounts[username]["known_devices"][device]["trust_score"]
            )

             print("\n====================================")
             print("INVESTIGATION HISTORY")
             print("====================================")

             for investigation in investigation_history:

                  print("------------------------------------")

                  print("Incident ID   :", investigation["incident_id"])
                  print("Username      :", investigation["username"])
                  print("Device        :", investigation["device"])
                  print("Administrator :", investigation["administrator"])
                  print("Decision      :", investigation["decision"])
                  print("Decision Time :", investigation["decision_time"])
                  print("Risk Score    :", investigation["risk_score"])
                  print("Severity      :", investigation["severity"])
                   
       else:
            print("\nApproval Cancelled.")  
    elif decision == "b":

        confirm = input("\nBlock this device? (Y/N): ").lower()

        if confirm == "y":

           block_device(
            accounts,
            username,
            device,
            investigation_history,
            decision_log
        )
           print_admin_result(
                      username,
                      device,
                      "BLOCKED",
                      "Blocked Devices"
)

           print("\nPending Devices")
           print(accounts[username]["pending_devices"])
        else:
         print("\nBlocking Cancelled.")
 
    elif decision == "s":
       print("\nDevice Skipped.")

    else:
        print("\nInvalid Choice.")
def detect_impossible_travel(accounts, username, login_event):

    print("\n========== IMPOSSIBLE TRAVEL DEBUG ==========")

    print("Username:", username)
    print("Current country:", login_event["country"])
    print("Current timestamp:", login_event["timestamp"])

    login_history = accounts[username]["login_history"]

    print("Login history length:", len(login_history))

    previous_login = None

    for login in reversed(login_history[:-1]):

        print(
            "Checking previous login:",
            login["timestamp"],
            "|",
            login["country"],
            "|",
            login["event"]
        )

        if login["event"] == "Successful Login":

            previous_login = login
            break

    if previous_login is None:

        print("❌ NO PREVIOUS SUCCESSFUL LOGIN FOUND")

        return False, None, None, None

    previous_country = previous_login["country"]
    previous_time = previous_login["timestamp"]

    current_country = login_event["country"]
    current_time = login_event["timestamp"]

    time_difference = current_time - previous_time
    seconds = time_difference.total_seconds()

    print("Previous country:", previous_country)
    print("Current country:", current_country)
    print("Time difference:", seconds, "seconds")
    print("Travel window:", IMPOSSIBLE_TRAVEL_WINDOW, "seconds")

    if previous_country != current_country:

        print("Countries are different: YES")

        if seconds < IMPOSSIBLE_TRAVEL_WINDOW:

            print("🚨 IMPOSSIBLE TRAVEL SHOULD TRIGGER")

            return (
                True,
                previous_country,
                current_country,
                seconds
            )

    print("❌ Impossible travel condition not satisfied")

    return False, None, None, None

def detect_vpn_anomaly(accounts, username, device, vpn):

    vpn_history = (
        accounts[username]
        .get("vpn_history", {})
    )

    # No previous VPN information for this device
    if device not in vpn_history:

        vpn_history[device] = vpn

        accounts[username]["vpn_history"] = vpn_history

        return False, None, vpn

    previous_vpn = vpn_history[device]

    # Update the latest VPN state
    vpn_history[device] = vpn

    accounts[username]["vpn_history"] = vpn_history

    # VPN state changed
    if previous_vpn.lower() != vpn.lower():

        return (
            True,
            previous_vpn,
            vpn
        )

    return (
        False,
        previous_vpn,
        vpn
    )
# =====================================================
# MODULE 6 - RISK ENGINE
# =====================================================
def calculate_risk(
    brute_force_detected,
    unknown_device,
    unknown_country,
    impossible_travel,
    vpn_issue
):

    risk_score = 0

    if brute_force_detected:
        risk_score += int(
            get_setting(
                "brute_force_points",
                40
            )
        )

    if unknown_device:
        risk_score += int(
            get_setting(
                "unknown_device_points",
                20
            )
        )

    if unknown_country:
        risk_score += int(
            get_setting(
                "unknown_country_points",
                30
            )
        )

    if impossible_travel:
        risk_score += int(
            get_setting(
                "impossible_travel_points",
                50
            )
        )

    if vpn_issue:
        risk_score += int(
            get_setting(
                "vpn_anomaly_points",
                25
            )
        )

    medium_threshold = int(
        get_setting(
            "medium_threshold",
            30
        )
    )

    high_threshold = int(
        get_setting(
            "high_threshold",
            60
        )
    )

    critical_threshold = int(
        get_setting(
            "critical_threshold",
            90
        )
    )

    if risk_score >= critical_threshold:
        severity = "CRITICAL"

    elif risk_score >= high_threshold:
        severity = "HIGH"

    elif risk_score >= medium_threshold:
        severity = "MEDIUM"

    else:
        severity = "LOW"

    return risk_score, severity
   
def generate_recommendations(severity):

    recommended_actions = []

    if severity == "LOW":

        recommended_actions.append("Log the Event")

    elif severity == "MEDIUM":

        recommended_actions.append("Notify Administrator")
        recommended_actions.append("Monitor User Activity")

    elif severity == "HIGH":

        recommended_actions.append("Verify User Identity")
        recommended_actions.append("Notify Security Team")
        recommended_actions.append("Monitor User Activity")

    elif severity == "CRITICAL":

        recommended_actions.append("Lock Account")
        recommended_actions.append("Terminate Active Sessions")
        recommended_actions.append("Notify SOC")
        recommended_actions.append("Open Security Incident")

    return recommended_actions

def generate_detection_reasons(
    brute_force_detected,
    unknown_device,
    unknown_country,
    impossible_travel,
    vpn_issue
):
    detection_reasons = []

    if brute_force_detected:
        detection_reasons.append("Brute Force Activity")

    if unknown_device:
        detection_reasons.append("Unknown Device")

    if unknown_country:
        detection_reasons.append("Unknown Country")

    if impossible_travel:
        detection_reasons.append("Impossible Travel")

    if vpn_issue:
        detection_reasons.append("VPN Anomaly")

    return detection_reasons
# =====================================================
# MODULE 7 - INCIDENT MANAGEMENT
# =====================================================
def generate_incident_id(incidents):

    incident_number = len(incidents) + 1

    return f"INC-{incident_number:04d}"
def store_incident(
    incidents,
    username,
    login_event,
    risk_score,
    severity,
    recommended_actions
):

    if risk_score == 0:
        return None 
    incident_id = generate_incident_id(incidents)
    incident = {

         "incident_id": incident_id,
         "username": username,
         "event": login_event["event"],
         "timestamp": login_event["timestamp"],
         "ip_address": login_event["ip_address"],
         "country": login_event["country"],
         "device": login_event["device"],
         "browser": login_event["browser"],
         "vpn": login_event["vpn"],
         "risk_score": risk_score,
         "severity": severity,
         "recommended_actions": recommended_actions.copy(),
         "status": "Open",
         "resolution_notes": ""

}
    incidents.append(incident)
    return incident_id

def print_login_report(
    username,
    event,
    failed_attempts,
    login_history_length,
    country,
    vpn
):

    print("----------------------------")
    print("\n==============================")
    print("LOGIN EVENT REPORT")
    print("==============================")
    print("Username :", username)
    print("Event    :", event)
    print("Failed Attempts :", failed_attempts)
    print("Login History Length :", login_history_length)
    print("Country :", country)
    print("VPN :", vpn)


def print_incident_summary(incidents):

    print("\n==============================")
    print("INCIDENT SUMMARY")
    print("==============================")

    for incident in incidents:

        print("------------------------------")
        print("Incident ID:", incident["incident_id"])
        print("Username   :", incident["username"])
        print("Event      :", incident["event"])
        print("Timestamp  :", incident["timestamp"])
        print("Risk Score :", incident["risk_score"])
        print("Severity   :", incident["severity"])
        print("Status     :", incident["status"])

        print("Recommended Actions:")

        for action in incident["recommended_actions"]:
            print(" -", action)

        print("Resolution :", incident["resolution_notes"])
# =====================================================
# MODULE 8 - SECURITY DASHBOARD
# =====================================================

def print_security_dashboard(
    accounts,
    incidents,
    investigation_history
):

    known, pending, blocked = count_devices(accounts)

    critical, high, medium, low = (
        count_incidents_by_severity(incidents)
    )

    most_targeted, incident_count = (
        find_most_targeted_user(incidents)
    )

    average_trust = (
        calculate_average_trust(accounts)
    )

    approved, blocked_decisions = (
        count_investigation_decisions(
            investigation_history
        )
    )

    print("\n====================================")
    print(" SECURITY OPERATIONS DASHBOARD")
    print("====================================")

    print("\nDEVICES")
    print("-------")
    print("Known Devices   :", known)
    print("Pending Devices :", pending)
    print("Blocked Devices :", blocked)

    print("\nINCIDENTS")
    print("---------")
    print("Critical :", critical)
    print("High     :", high)
    print("Medium   :", medium)
    print("Low      :", low)

    print("\nMOST TARGETED USER")
    print("------------------")
    print(most_targeted, "-", incident_count, "incident(s)")

    print("\nAVERAGE TRUST SCORE")
    print("-------------------")
    print(average_trust)

    print("\nINVESTIGATION DECISIONS")
    print("-----------------------")
    print("Approved :", approved)
    print("Blocked  :", blocked_decisions)

    print("====================================")

def print_session_summary(
    accounts,
    incidents,
    investigation_history
):
    

    known, pending, blocked = count_devices(accounts)

    average_trust = calculate_average_trust(accounts)

    most_targeted, incident_count = (
        find_most_targeted_user(incidents)
    )

    print("\n====================================")
    print(" SECURITY SESSION SUMMARY")
    print("====================================")

    print("Incidents Created   :", len(incidents))

    print(
        "Investigations      :",
        len(investigation_history)
    )

    print("Known Devices       :", known)

    print("Pending Devices     :", pending)

    print("Blocked Devices     :", blocked)

    print("Average Trust Score :", average_trust)

    print(
        "Most Targeted User  :",
        most_targeted
    )

    print("\nSession Completed Successfully")

    print("====================================")
def is_setting_enabled(setting_name, default=True):

    default_value = "true" if default else "false"

    return (
        get_setting(
            setting_name,
            default_value
        ).lower() == "true"
    )
# =====================================================
# MAIN LOG PROCESSING
# =====================================================

def process_logs(
    accounts,
    events,
    incidents,
    investigation_history,
    decision_log
):

    global last_processed_line

    print("\n========== DEBUG ==========")
    print("Before reading:", last_processed_line)

    with open("logs/sample.log", "r") as file:

        lines = file.readlines()

        print("Total lines in file:", len(lines))
        print("Last processed line:", last_processed_line)

        new_lines = lines[last_processed_line:]

        if not new_lines:
            print("No new logs.")
            return

        last_processed_line = len(lines)

        print("New lines found:", len(new_lines))


    for line in new_lines:

        print("Processing:", line.strip())

        if line.strip() == "":
            continue

        parts = line.split("|")
        parts = [item.strip() for item in parts]

        timestamp = parts[0]
        log_time = datetime.strptime(
            timestamp,
            "%Y-%m-%d %H:%M:%S"
        )

        username = parts[1]
        event = parts[2]
        ip_address = parts[3]
        country = parts[4]
        device = parts[5]
        browser = parts[6]
        vpn = parts[7]


        # ====================================
        # Log Parsing
        # ====================================

        login_event = create_login_event(
            log_time,
            username,
            event,
            ip_address,
            country,
            device,
            browser,
            vpn
        )


        events.append({

            "timestamp": login_event["timestamp"],
            "username": username,
            "event": event,
            "ip_address": ip_address,
            "country": country,
            "device": device,
            "browser": browser,
            "vpn": vpn,
            "result": (
                "FAILED"
                if event == "Failed Login"
                else "SUCCESS"
            ),
            "incident_id": None

        })


        print("\n===== EVENT CREATED =====")
        print(events[-1])
        print("Total events:", len(events))


        # ====================================
        # Account Initialization
        # ====================================

        if username not in accounts:

            accounts[username] = {

                "failed_attempts": 0,
                "login_history": [],

                "known_devices": {},
                "pending_devices": {},
                "blocked_devices": {},
                "vpn_history": {},

                "known_countries": set(),

                "department": "Unassigned",
                "role": "Not Assigned",

                "authorized_contexts": []

            }

        else:

            accounts[username].setdefault(
                "failed_attempts",
                0
            )

            accounts[username].setdefault(
                "login_history",
                []
            )

            accounts[username].setdefault(
                "known_devices",
                {}
            )

            accounts[username].setdefault(
                "pending_devices",
                {}
            )

            accounts[username].setdefault(
                "blocked_devices",
                {}
            )

            accounts[username].setdefault(
                "known_countries",
                set()
            )

            accounts[username].setdefault(
                "department",
                "Unassigned"
            )

            accounts[username].setdefault(
                "role",
                "Not Assigned"
            )

            accounts[username].setdefault(
                "authorized_contexts",
                []
            )


        # ====================================
        # Login History
        # ====================================

        accounts[username]["login_history"].append(
            login_event
        )


        # ====================================
        # Detection Flags
        # ====================================

        risk_score = 0
        recommended_actions = []

        brute_force_detected = False
        unknown_device = False
        unknown_country = False
        impossible_travel = False
        vpn_issue = False


        # ====================================
        # Failed Login / Brute Force
        # ====================================

        if event == "Failed Login":

            accounts[username]["failed_attempts"] += 1

            if is_setting_enabled(
                "brute_force_enabled"
            ):

                brute_force_detected, failed_count = (
                    detect_brute_force(
                        accounts,
                        username,
                        login_event
                    )
                )

                if brute_force_detected:

                    print(
                        "\n🚨 BRUTE FORCE ATTACK DETECTED 🚨"
                    )

                    print(
                        "Username :",
                        username
                    )

                    print(
                        "Failed Logins :",
                        failed_count
                    )

                    print(
                        "Time Window : 120 Seconds"
                    )

        # ====================================
        # Device Processing
        # ====================================

        device_status = process_device(
            accounts,
            username,
            device,
            login_event
        )


        if (
            device_status == "PENDING"
            and is_setting_enabled(
                "unknown_device_enabled"
            )
        ):

            unknown_device = True


        # ====================================
        # Trust Evaluation
        # ====================================

        if (
            device_status == "KNOWN"
            and event == "Successful Login"
        ):

            increase_trust(
                accounts,
                username,
                device,
                TRUST_REWARD
            )

            print(
                "Trust Score :",
                accounts[username]
                ["known_devices"]
                [device]
                ["trust_score"]
            )

            evaluate_trust(
                accounts,
                username,
                device
            )


        # ====================================
        # Country / Location Verification
        # ====================================

        print(
            "\n===== LOCATION CONTEXT DEBUG ====="
        )

        print(
            "Username:",
            username
        )

        print(
            "Contexts:",
            accounts[username].get(
                "authorized_contexts",
                []
            )
        )

        print(
            "Login country:",
            country
        )

        print(
            "Login date:",
            login_event["timestamp"].date()
        )


        authorized_location, location_context = (
            check_authorized_location(
                accounts,
                username,
                login_event
            )
        )


        if authorized_location:

            unknown_country = False

            print(
                "\n✓ AUTHORIZED LOCATION"
            )

            print(
                "Context :",
                location_context.get("type")
            )

            print(
                "Country :",
                location_context.get("country")
            )

        else:

            if is_setting_enabled(
              "unknown_country_enabled"
):

             unknown_country = detect_unknown_country(
                     accounts,
                     username,
                     country
    )

            else:

               unknown_country = False


            if (
                device_status == "KNOWN"
                and unknown_country
            ):

                decrease_trust(
                    accounts,
                    username,
                    device,
                    UNKNOWN_COUNTRY_PENALTY
                )

                print(
                    "Trust Score :",
                    accounts[username]
                    ["known_devices"]
                    [device]
                    ["trust_score"]
                )

                evaluate_trust(
                    accounts,
                    username,
                    device
                )


            if unknown_country:

                print(
                    "\n⚠ UNKNOWN COUNTRY DETECTED"
                )

                print(
                    "Username :",
                    username
                )

                print(
                    "Country :",
                    country
                )

            else:

                print(
                    "Known Country"
                )


        # ====================================
        # Impossible Travel Detection
        # ====================================

        if (
            event == "Successful Login"
            and not authorized_location
            and is_setting_enabled(
                "impossible_travel_enabled"
            )
        ):

            (
                impossible_travel,
                previous_country,
                current_country,
                seconds
            ) = detect_impossible_travel(
                accounts,
                username,
                login_event
            )

            if impossible_travel:

                print(
                    "\n🚨 IMPOSSIBLE TRAVEL DETECTED 🚨"
                )

                print(
                    "Username :",
                    username
                )

                print(
                    "Previous Country :",
                    previous_country
                )

                print(
                    "Current Country :",
                    current_country
                )

                print(
                    "Travel Time :",
                    seconds,
                    "seconds"
                )

                if device_status == "KNOWN":

                    decrease_trust(
                        accounts,
                        username,
                        device,
                        IMPOSSIBLE_TRAVEL_PENALTY
                    )

                    print(
                        "Trust Score :",
                        accounts[username]
                        ["known_devices"]
                        [device]
                        ["trust_score"]
                    )

                    evaluate_trust(
                        accounts,
                        username,
                        device
                    )
        # ====================================
        # VPN ANOMALY DETECTION
        # ====================================

        if is_setting_enabled(
         "vpn_anomaly_enabled"
        ):

         (
            vpn_issue,
            previous_vpn,
            current_vpn
        ) = detect_vpn_anomaly(
            accounts,
            username,
            device,
            vpn
        )

        if vpn_issue:

            print(
                "\n🚨 VPN ANOMALY DETECTED 🚨"
            )

            print(
                "Username :",
                username
            )

            print(
                "Device :",
                device
            )

            print(
                "Previous VPN :",
                previous_vpn
            )

            print(
                "Current VPN :",
                current_vpn
            )


        # ====================================
        # Risk Assessment
        # ====================================

        detection_reasons = generate_detection_reasons(
            brute_force_detected,
            unknown_device,
            unknown_country,
            impossible_travel,
            vpn_issue
        )

        print("\n===== ACTIVE DETECTION SETTINGS =====")
        print("Brute Force      :", get_setting("brute_force_enabled"))
        print("Unknown Device   :", get_setting("unknown_device_enabled"))
        print("Unknown Country  :", get_setting("unknown_country_enabled"))
        print("Impossible Travel:", get_setting("impossible_travel_enabled"))
        print("VPN Anomaly      :", get_setting("vpn_anomaly_enabled"))
        print("Monitoring       :", get_setting("monitoring_enabled"))

        print("\n===== DETECTION FLAGS =====")
        print("Brute Force      :", brute_force_detected)
        print("Unknown Device   :", unknown_device)
        print("Unknown Country  :", unknown_country)
        print("Impossible Travel:", impossible_travel)
        print("VPN Issue        :", vpn_issue)
        risk_score, severity = calculate_risk(
            brute_force_detected,
            unknown_device,
            unknown_country,
            impossible_travel,
            vpn_issue
        )


        print(
            "\n===== RISK ASSESSMENT ====="
        )

        print(
            "Risk Score :",
            risk_score
        )

        print(
            "Severity   :",
            severity
        )


        print(
            "\nDetection Reasons:"
        )

        for reason in detection_reasons:

            print(
                "-",
                reason
            )


        recommended_actions = (
            generate_recommendations(
                severity
            )
        )


        # ====================================
        # Pending Device Update
        # ====================================

        if device_status == "PENDING":

            update_pending_risk(
                accounts,
                username,
                device,
                risk_score,
                severity,
                recommended_actions,
                detection_reasons
            )


        print(
            "\nRecommended Actions:"
        )

        for action in recommended_actions:

            print(
                "-",
                action
            )


        # ====================================
        # Incident Logging
        # ====================================

        incident_id = store_incident(
            incidents,
            username,
            login_event,
            risk_score,
            severity,
            recommended_actions
        )


        if incident_id is not None:

            events[-1]["incident_id"] = incident_id


        if (
            incident_id is not None
            and device_status == "PENDING"
        ):

            accounts[username][
                "pending_devices"
            ][device][
                "incident_id"
            ] = incident_id


        # ====================================
        # Reports
        # ====================================

        print_login_report(
            username,
            event,
            accounts[username]["failed_attempts"],
            len(
                accounts[username]["login_history"]
            ),
            country,
            vpn
        )


        print_incident_summary(
            incidents
        )


        known, pending, blocked = (
            count_devices(accounts)
        )


        # ====================================
        # Pending Device Queue
        # ====================================

        pending_queue = build_pending_queue(
         accounts
        )

        print_pending_queue(
          pending_queue
        )


        # ====================================
        # Dashboard / Session Summary
        # ====================================

        print_security_dashboard(
            accounts,
            incidents,
            investigation_history
        )


        print_session_summary(
            accounts,
            incidents,
            investigation_history
        )


        # ====================================
        # Save Everything
        # ====================================

        save_all(
            accounts,
            events,
            incidents,
            investigation_history,
            decision_log
        )
# =====================================================
# MODULE 9 - LIVE MONITORING
# =====================================================
class LogHandler(FileSystemEventHandler):

    def on_modified(self, event):

        global processing
        if not is_setting_enabled(
            "monitoring_enabled"
        ):

            print(
                "\n⏸ Monitoring is disabled in Settings."
            )

            return

        # Ignore directories
        if event.is_directory:
            return

        # Ignore files other than sample.log
        if not event.src_path.endswith("sample.log"):
            return

        with processing_lock:

            if processing:
                print("Already processing... Ignoring duplicate event.")
                return

            processing = True

        try:

            print("EVENT:", datetime.now())
            print("\n📢 File modification detected!")

            process_logs(
                accounts,
                events,
                incidents,
                investigation_history,
                decision_log
            )

        finally:

            with processing_lock:
                processing = False
initialize_storage()

(
    accounts,
    events,
    incidents,
    investigation_history,
    decision_log
) = load_all()   

# ====================================
# BACKWARD COMPATIBILITY
# ====================================

for username in accounts:

    accounts[username].setdefault(
        "department",
        "Unassigned"
    )

    accounts[username].setdefault(
        "role",
        "Not Assigned"
    )

    accounts[username].setdefault(
        "authorized_contexts",
        []
    )


# ====================================
# TEMPORARY AUTHORIZATION TEST
# ====================================

if __name__ == "__main__":

    observer = Observer()

    with open("logs/sample.log", "r") as file:
        last_processed_line = len(file.readlines())

    event_handler = LogHandler()

    observer.schedule(
        event_handler,
        path="logs",
        recursive=False
    )

    observer.start()

    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        observer.stop()

    observer.join()
