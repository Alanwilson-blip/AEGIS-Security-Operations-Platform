USE AEGIS_DB;
GO

/* ============================================================
   AEGIS - SYNTHETIC USER DATA
   60 users = 1 user for each role
   All identities are fictional.
   ============================================================ */

INSERT INTO users
(
    employee_code,
    full_name,
    email,
    role_id,
    manager_id,
    status,
    location,
    join_date,
    mfa_enabled,
    risk_score
)
SELECT
    x.employee_code,
    x.full_name,
    x.email,
    r.role_id,
    NULL,
    'ACTIVE',
    x.location,
    x.join_date,
    x.mfa_enabled,
    0
FROM
(
    VALUES

    /* ========================================================
       ENGINEERING & DEVELOPMENT
       ======================================================== */

    ('EMP0001','Alex Morgan','alex.morgan@aegis-demo.com',
     'Software Engineer','Seattle','2024-02-12',1),

    ('EMP0002','Jordan Lee','jordan.lee@aegis-demo.com',
     'Senior Software Engineer','Redmond','2022-08-15',1),

    ('EMP0003','Taylor Brooks','taylor.brooks@aegis-demo.com',
     'Cloud Engineer','Seattle','2023-05-22',1),

    ('EMP0004','Casey Parker','casey.parker@aegis-demo.com',
     'DevOps Engineer','Redmond','2021-11-08',1),

    ('EMP0005','Morgan Reed','morgan.reed@aegis-demo.com',
     'Engineering Manager','Seattle','2020-03-16',1),


    /* ========================================================
       RESEARCH & DATA SCIENCE
       ======================================================== */

    ('EMP0006','Avery Wilson','avery.wilson@aegis-demo.com',
     'Data Scientist','Redmond','2023-01-09',1),

    ('EMP0007','Riley Carter','riley.carter@aegis-demo.com',
     'Research Scientist','Cambridge','2021-06-14',1),

    ('EMP0008','Cameron Smith','cameron.smith@aegis-demo.com',
     'Machine Learning Engineer','Seattle','2022-09-19',1),

    ('EMP0009','Drew Anderson','drew.anderson@aegis-demo.com',
     'Data Engineer','Redmond','2023-07-03',1),

    ('EMP0010','Quinn Taylor','quinn.taylor@aegis-demo.com',
     'Research Manager','Cambridge','2019-10-21',1),


    /* ========================================================
       PRODUCT & PROGRAM MANAGEMENT
       ======================================================== */

    ('EMP0011','Jamie Bennett','jamie.bennett@aegis-demo.com',
     'Product Manager','Redmond','2022-01-17',1),

    ('EMP0012','Reese Mitchell','reese.mitchell@aegis-demo.com',
     'Program Manager','Seattle','2021-04-26',1),

    ('EMP0013','Skyler Adams','skyler.adams@aegis-demo.com',
     'Technical Program Manager','Redmond','2023-03-13',1),

    ('EMP0014','Peyton Cooper','peyton.cooper@aegis-demo.com',
     'Product Operations Specialist','Seattle','2024-06-10',1),

    ('EMP0015','Blake Richardson','blake.richardson@aegis-demo.com',
     'Group Product Manager','Redmond','2019-08-05',1),


    /* ========================================================
       SALES & MARKETING
       ======================================================== */

    ('EMP0016','Harper Evans','harper.evans@aegis-demo.com',
     'Sales Specialist','New York','2024-01-22',1),

    ('EMP0017','Logan Foster','logan.foster@aegis-demo.com',
     'Account Manager','New York','2022-05-16',1),

    ('EMP0018','Emerson Gray','emerson.gray@aegis-demo.com',
     'Marketing Specialist','New York','2023-09-11',1),

    ('EMP0019','Finley Hughes','finley.hughes@aegis-demo.com',
     'Sales Operations Analyst','Chicago','2021-12-06',1),

    ('EMP0020','Rowan Phillips','rowan.phillips@aegis-demo.com',
     'Sales & Marketing Manager','New York','2020-07-20',1),


    /* ========================================================
       CUSTOMER SUPPORT
       ======================================================== */

    ('EMP0021','Elliot Ward','elliot.ward@aegis-demo.com',
     'Support Representative','Dublin','2024-03-04',1),

    ('EMP0022','Sage Murphy','sage.murphy@aegis-demo.com',
     'Technical Support Engineer','Dublin','2022-10-17',1),

    ('EMP0023','Charlie Watson','charlie.watson@aegis-demo.com',
     'Customer Success Specialist','London','2023-02-27',1),

    ('EMP0024','Dakota James','dakota.james@aegis-demo.com',
     'Support Operations Analyst','Dublin','2021-08-23',1),

    ('EMP0025','Reagan Cole','reagan.cole@aegis-demo.com',
     'Customer Support Manager','London','2019-11-18',1),


    /* ========================================================
       OPERATIONS
       ======================================================== */

    ('EMP0026','Parker Scott','parker.scott@aegis-demo.com',
     'Operations Specialist','Seattle','2024-04-15',1),

    ('EMP0027','Kendall Morris','kendall.morris@aegis-demo.com',
     'Operations Analyst','Redmond','2022-07-11',1),

    ('EMP0028','Alexis Bell','alexis.bell@aegis-demo.com',
     'Process Coordinator','Seattle','2023-05-08',1),

    ('EMP0029','Sydney Rivera','sydney.rivera@aegis-demo.com',
     'Operations Supervisor','Redmond','2021-02-01',1),

    ('EMP0030','Marley Cook','marley.cook@aegis-demo.com',
     'Operations Manager','Seattle','2019-09-09',1),


    /* ========================================================
       FINANCE
       ======================================================== */

    ('EMP0031','Bailey Morgan','bailey.morgan@aegis-demo.com',
     'Finance Analyst','New York','2023-01-30',1),

    ('EMP0032','Cory Stewart','cory.stewart@aegis-demo.com',
     'Accountant','New York','2021-05-24',1),

    ('EMP0033','Shawn Peterson','shawn.peterson@aegis-demo.com',
     'Financial Planning Analyst','Chicago','2022-11-14',1),

    ('EMP0034','Robin Turner','robin.turner@aegis-demo.com',
     'Finance Supervisor','New York','2020-06-29',1),

    ('EMP0035','Frankie Hayes','frankie.hayes@aegis-demo.com',
     'Finance Manager','Chicago','2019-03-18',1),


    /* ========================================================
       HUMAN RESOURCES
       ======================================================== */

    ('EMP0036','Mackenzie Price','mackenzie.price@aegis-demo.com',
     'HR Specialist','Redmond','2023-04-03',1),

    ('EMP0037','Jesse Collins','jesse.collins@aegis-demo.com',
     'Recruiter','Seattle','2022-02-14',1),

    ('EMP0038','Terry Ross','terry.ross@aegis-demo.com',
     'Employee Relations Specialist','Redmond','2021-09-27',1),

    ('EMP0039','Ari Simmons','ari.simmons@aegis-demo.com',
     'HR Supervisor','Seattle','2020-12-07',1),

    ('EMP0040','Sam Reynolds','sam.reynolds@aegis-demo.com',
     'HR Manager','Redmond','2019-05-13',1),


    /* ========================================================
       LEGAL
       ======================================================== */

    ('EMP0041','Chris Palmer','chris.palmer@aegis-demo.com',
     'Legal Assistant','London','2024-05-06',1),

    ('EMP0042','Dana Graham','dana.graham@aegis-demo.com',
     'Legal Analyst','London','2022-03-21',1),

    ('EMP0043','Alexandra Stone','alexandra.stone@aegis-demo.com',
     'Corporate Counsel','New York','2020-10-12',1),

    ('EMP0044','Micah Grant','micah.grant@aegis-demo.com',
     'Legal Operations Specialist','London','2023-08-07',1),

    ('EMP0045','Patricia Knight','patricia.knight@aegis-demo.com',
     'Legal Manager','New York','2018-11-19',1),


    /* ========================================================
       IT
       ======================================================== */

    ('EMP0046','Jamie Walsh','jamie.walsh@aegis-demo.com',
     'IT Support Specialist','Seattle','2024-02-05',1),

    ('EMP0047','Nolan Fisher','nolan.fisher@aegis-demo.com',
     'Systems Administrator','Redmond','2021-01-25',1),

    ('EMP0048','Evan Marshall','evan.marshall@aegis-demo.com',
     'Network Administrator','Seattle','2020-04-20',1),

    ('EMP0049','Noah Franklin','noah.franklin@aegis-demo.com',
     'IT Security Administrator','Redmond','2022-06-06',1),

    ('EMP0050','Adrian Spencer','adrian.spencer@aegis-demo.com',
     'IT Manager','Seattle','2019-07-15',1),


    /* ========================================================
       SECURITY
       ======================================================== */

    ('EMP0051','Jordan Mitchell','jordan.mitchell@aegis-demo.com',
     'Security Analyst','Redmond','2023-02-06',1),

    ('EMP0052','Maya Armstrong','maya.armstrong@aegis-demo.com',
     'SOC Analyst','Seattle','2022-04-18',1),

    ('EMP0053','Ethan Wallace','ethan.wallace@aegis-demo.com',
     'Security Engineer','Redmond','2021-10-04',1),

    ('EMP0054','Lena Crawford','lena.crawford@aegis-demo.com',
     'Incident Response Specialist','Seattle','2020-08-24',1),

    ('EMP0055','Victor Harrison','victor.harrison@aegis-demo.com',
     'Security Manager','Redmond','2018-06-11',1),


    /* ========================================================
       ADMINISTRATION
       ======================================================== */

    ('EMP0056','Taylor Dawson','taylor.dawson@aegis-demo.com',
     'Administrative Assistant','Seattle','2024-01-08',1),

    ('EMP0057','Morgan Fletcher','morgan.fletcher@aegis-demo.com',
     'Administrative Specialist','Redmond','2022-08-29',1),

    ('EMP0058','Jamie Cross','jamie.cross@aegis-demo.com',
     'Office Coordinator','Seattle','2023-06-19',1),

    ('EMP0059','Rory Chapman','rory.chapman@aegis-demo.com',
     'Administrative Supervisor','Redmond','2021-03-15',1),

    ('EMP0060','Cameron Marshall','cameron.marshall@aegis-demo.com',
     'Administration Manager','Seattle','2019-12-02',1)

) AS x
(
    employee_code,
    full_name,
    email,
    role_name,
    location,
    join_date,
    mfa_enabled
)
JOIN roles r
    ON r.role_name = x.role_name
JOIN departments d
    ON d.department_id = r.department_id
WHERE NOT EXISTS
(
    SELECT 1
    FROM users u
    WHERE u.employee_code = x.employee_code
);
GO


/* ============================================================
   ASSIGN DEPARTMENT MANAGERS
   Every non-manager gets the manager of their department.
   ============================================================ */

UPDATE u
SET manager_id = manager_user.user_id
FROM users u
JOIN roles employee_role
    ON u.role_id = employee_role.role_id
JOIN roles manager_role
    ON employee_role.department_id = manager_role.department_id
JOIN users manager_user
    ON manager_user.role_id = manager_role.role_id
WHERE manager_role.role_name IN
(
    'Engineering Manager',
    'Research Manager',
    'Group Product Manager',
    'Sales & Marketing Manager',
    'Customer Support Manager',
    'Operations Manager',
    'Finance Manager',
    'HR Manager',
    'Legal Manager',
    'IT Manager',
    'Security Manager',
    'Administration Manager'
)
AND employee_role.role_name NOT IN
(
    'Engineering Manager',
    'Research Manager',
    'Group Product Manager',
    'Sales & Marketing Manager',
    'Customer Support Manager',
    'Operations Manager',
    'Finance Manager',
    'HR Manager',
    'Legal Manager',
    'IT Manager',
    'Security Manager',
    'Administration Manager'
);
GO


/* ============================================================
   VALIDATION
   ============================================================ */

SELECT COUNT(*) AS Total_Users
FROM users;
GO

SELECT
    d.department_name,
    COUNT(u.user_id) AS User_Count
FROM departments d
LEFT JOIN roles r
    ON r.department_id = d.department_id
LEFT JOIN users u
    ON u.role_id = r.role_id
GROUP BY
    d.department_id,
    d.department_name
ORDER BY
    d.department_id;
GO


/* ============================================================
   SHOW USER HIERARCHY
   ============================================================ */

SELECT
    u.employee_code,
    u.full_name,
    d.department_name,
    r.role_name,
    manager.full_name AS Manager,
    u.status,
    u.mfa_enabled,
    u.risk_score
FROM users u
JOIN roles r
    ON u.role_id = r.role_id
JOIN departments d
    ON r.department_id = d.department_id
LEFT JOIN users manager
    ON u.manager_id = manager.user_id
ORDER BY
    d.department_id,
    u.employee_code;
GO