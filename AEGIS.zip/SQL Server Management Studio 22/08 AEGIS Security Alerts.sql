USE AEGIS_DB;
GO

/* =========================================================
   AEGIS - STEP 08
   SECURITY ALERTS
   Generates synthetic security alerts from access_events
   ========================================================= */


/* =========================================================
   1. ALERT: DENIED RESOURCE ACCESS
   ========================================================= */

INSERT INTO security_alerts
(
    event_id,
    user_id,
    alert_type,
    severity,
    risk_score,
    description,
    status,
    created_at
)
SELECT
    ae.event_id,
    ae.user_id,
    'UNAUTHORIZED_ACCESS_ATTEMPT',
    CASE
        WHEN COUNT(*) OVER (PARTITION BY ae.user_id) >= 2
            THEN 'HIGH'
        ELSE 'MEDIUM'
    END,
    CASE
        WHEN COUNT(*) OVER (PARTITION BY ae.user_id) >= 2
            THEN 75
        ELSE 55
    END,
    'User attempted to access a resource without sufficient permission.',
    'OPEN',
    ae.event_timestamp
FROM access_events ae
WHERE ae.result = 'DENY'
  AND ae.event_type = 'RESOURCE_ACCESS'
  AND NOT EXISTS
  (
      SELECT 1
      FROM security_alerts sa
      WHERE sa.event_id = ae.event_id
        AND sa.alert_type = 'UNAUTHORIZED_ACCESS_ATTEMPT'
  );
GO


/* =========================================================
   2. ALERT: HIGH-RISK ACCESS EVENT
   ========================================================= */

INSERT INTO security_alerts
(
    event_id,
    user_id,
    alert_type,
    severity,
    risk_score,
    description,
    status,
    created_at
)
SELECT
    ae.event_id,
    ae.user_id,
    'HIGH_RISK_ACCESS',
    'HIGH',
    ae.risk_score,
    'Access event was recorded with a high risk score.',
    'OPEN',
    ae.event_timestamp
FROM access_events ae
WHERE ae.risk_score >= 70
  AND NOT EXISTS
  (
      SELECT 1
      FROM security_alerts sa
      WHERE sa.event_id = ae.event_id
        AND sa.alert_type = 'HIGH_RISK_ACCESS'
  );
GO


/* =========================================================
   3. ALERT: UNMANAGED / NON-COMPLIANT DEVICE
   ========================================================= */

INSERT INTO security_alerts
(
    event_id,
    user_id,
    alert_type,
    severity,
    risk_score,
    description,
    status,
    created_at
)
SELECT
    ae.event_id,
    ae.user_id,
    'UNMANAGED_DEVICE_ACCESS',
    'HIGH',
    80,
    'Resource access was attempted from an unmanaged or non-compliant device.',
    'OPEN',
    ae.event_timestamp
FROM access_events ae
INNER JOIN user_devices ud
    ON ae.device_id = ud.device_id
WHERE ae.event_type = 'RESOURCE_ACCESS'
  AND (ud.managed = 0 OR ud.compliant = 0)
  AND NOT EXISTS
  (
      SELECT 1
      FROM security_alerts sa
      WHERE sa.event_id = ae.event_id
        AND sa.alert_type = 'UNMANAGED_DEVICE_ACCESS'
  );
GO


/* =========================================================
   4. ALERT: DENIED ACCESS FROM UNMANAGED DEVICE
   ========================================================= */

INSERT INTO security_alerts
(
    event_id,
    user_id,
    alert_type,
    severity,
    risk_score,
    description,
    status,
    created_at
)
SELECT
    ae.event_id,
    ae.user_id,
    'SUSPICIOUS_DEVICE_ACCESS',
    'CRITICAL',
    90,
    'A denied resource access attempt originated from an unmanaged or non-compliant device.',
    'OPEN',
    ae.event_timestamp
FROM access_events ae
INNER JOIN user_devices ud
    ON ae.device_id = ud.device_id
WHERE ae.event_type = 'RESOURCE_ACCESS'
  AND ae.result = 'DENY'
  AND (ud.managed = 0 OR ud.compliant = 0)
  AND NOT EXISTS
  (
      SELECT 1
      FROM security_alerts sa
      WHERE sa.event_id = ae.event_id
        AND sa.alert_type = 'SUSPICIOUS_DEVICE_ACCESS'
  );
GO


/* =========================================================
   5. ALERT: PRIVILEGED ADMIN ACTION
   ========================================================= */

INSERT INTO security_alerts
(
    event_id,
    user_id,
    alert_type,
    severity,
    risk_score,
    description,
    status,
    created_at
)
SELECT
    ae.event_id,
    ae.user_id,
    'PRIVILEGED_ACTION',
    'MEDIUM',
    50,
    'Administrative action was performed on a protected resource and requires audit visibility.',
    'OPEN',
    ae.event_timestamp
FROM access_events ae
WHERE ae.event_type = 'RESOURCE_ACCESS'
  AND ae.action = 'ADMIN'
  AND ae.result = 'ALLOW'
  AND NOT EXISTS
  (
      SELECT 1
      FROM security_alerts sa
      WHERE sa.event_id = ae.event_id
        AND sa.alert_type = 'PRIVILEGED_ACTION'
  );
GO


/* =========================================================
   6. UPDATE USER RISK SCORES
   Uses the highest alert risk score associated with
   each user.
   ========================================================= */

UPDATE u
SET u.risk_score =
(
    SELECT
        ISNULL(MAX(sa.risk_score), 0)
    FROM security_alerts sa
    WHERE sa.user_id = u.user_id
      AND sa.status IN ('OPEN', 'INVESTIGATING')
)
FROM users u;
GO


/* =========================================================
   7. VALIDATION
   ========================================================= */

SELECT
    alert_type,
    severity,
    COUNT(*) AS alert_count
FROM security_alerts
GROUP BY
    alert_type,
    severity
ORDER BY
    severity,
    alert_type;
GO


/* =========================================================
   8. TOTAL ALERT COUNT
   ========================================================= */

SELECT
    COUNT(*) AS total_security_alerts
FROM security_alerts;
GO


/* =========================================================
   9. VIEW ALERT DETAILS
   ========================================================= */

SELECT TOP 50
    sa.alert_id,
    u.employee_code,
    u.full_name,
    sa.alert_type,
    sa.severity,
    sa.risk_score,
    sa.description,
    sa.status,
    sa.created_at
FROM security_alerts sa
INNER JOIN users u
    ON sa.user_id = u.user_id
ORDER BY
    sa.created_at DESC;
GO