USE AEGIS_DB;
GO

/* ============================================================
   AEGIS - ADMIN PERMISSION MODEL
   ============================================================ */

/* Remove any existing Admin permissions first */
UPDATE permissions
SET can_admin = 0;
GO


/* ============================================================
   IT - SYSTEMS ADMINISTRATOR
   ============================================================ */

UPDATE p
SET can_admin = 1
FROM permissions p
JOIN roles r ON p.role_id = r.role_id
JOIN departments d ON r.department_id = d.department_id
JOIN resources res ON p.resource_id = res.resource_id
WHERE d.department_name = 'IT'
AND r.role_name = 'Systems Administrator'
AND res.resource_name IN
(
    'Devices',
    'Network Resources',
    'System Configurations'
);
GO


/* ============================================================
   IT - NETWORK ADMINISTRATOR
   ============================================================ */

UPDATE p
SET can_admin = 1
FROM permissions p
JOIN roles r ON p.role_id = r.role_id
JOIN departments d ON r.department_id = d.department_id
JOIN resources res ON p.resource_id = res.resource_id
WHERE d.department_name = 'IT'
AND r.role_name = 'Network Administrator'
AND res.resource_name IN
(
    'Network Resources',
    'System Configurations'
);
GO


/* ============================================================
   IT - IT SECURITY ADMINISTRATOR
   ============================================================ */

UPDATE p
SET can_admin = 1
FROM permissions p
JOIN roles r ON p.role_id = r.role_id
JOIN departments d ON r.department_id = d.department_id
JOIN resources res ON p.resource_id = res.resource_id
WHERE d.department_name = 'IT'
AND r.role_name = 'IT Security Administrator'
AND res.resource_name IN
(
    'User Accounts',
    'Devices',
    'Network Resources',
    'System Configurations'
);
GO


/* ============================================================
   SECURITY - SECURITY ENGINEER
   ============================================================ */

UPDATE p
SET can_admin = 1
FROM permissions p
JOIN roles r ON p.role_id = r.role_id
JOIN departments d ON r.department_id = d.department_id
JOIN resources res ON p.resource_id = res.resource_id
WHERE d.department_name = 'Security'
AND r.role_name = 'Security Engineer'
AND res.resource_name = 'Security Configuration';
GO


/* ============================================================
   SECURITY - SECURITY MANAGER
   ============================================================ */

UPDATE p
SET can_admin = 1
FROM permissions p
JOIN roles r ON p.role_id = r.role_id
JOIN departments d ON r.department_id = d.department_id
JOIN resources res ON p.resource_id = res.resource_id
WHERE d.department_name = 'Security'
AND r.role_name = 'Security Manager'
AND res.resource_name IN
(
    'Security Policies',
    'Security Configuration'
);
GO


/* ============================================================
   ADMINISTRATION - ADMINISTRATION MANAGER
   ============================================================ */

UPDATE p
SET can_admin = 1
FROM permissions p
JOIN roles r ON p.role_id = r.role_id
JOIN departments d ON r.department_id = d.department_id
JOIN resources res ON p.resource_id = res.resource_id
WHERE d.department_name = 'Administration'
AND r.role_name = 'Administration Manager'
AND res.resource_name = 'Administrative Configuration';
GO


/* ============================================================
   VALIDATION
   ============================================================ */

SELECT
    COUNT(*) AS Total_Permission_Rows,
    SUM(CASE WHEN can_view = 1 THEN 1 ELSE 0 END) AS View_Permissions,
    SUM(CASE WHEN can_create = 1 THEN 1 ELSE 0 END) AS Create_Permissions,
    SUM(CASE WHEN can_edit = 1 THEN 1 ELSE 0 END) AS Edit_Permissions,
    SUM(CASE WHEN can_delete = 1 THEN 1 ELSE 0 END) AS Delete_Permissions,
    SUM(CASE WHEN can_admin = 1 THEN 1 ELSE 0 END) AS Admin_Permissions
FROM permissions;
GO


/* Show all Admin permissions */

SELECT
    d.department_name,
    r.role_name,
    res.resource_name,
    'A' AS Permission
FROM permissions p
JOIN roles r
    ON p.role_id = r.role_id
JOIN departments d
    ON r.department_id = d.department_id
JOIN resources res
    ON p.resource_id = res.resource_id
WHERE p.can_admin = 1
ORDER BY
    d.department_id,
    r.role_id,
    res.resource_id;
GO