USE AEGIS_DB;
GO

/* ============================================================
   AEGIS - SYNTHETIC DEVICE DATA
   Creates 2 devices for every user.
   Total expected: 120 devices.
   ============================================================ */

INSERT INTO user_devices
(
    user_id,
    device_name,
    device_type,
    operating_system,
    ip_address,
    managed,
    compliant,
    last_seen
)
SELECT
    u.user_id,

    CONCAT(
        CASE
            WHEN x.device_no = 1 THEN 'LAP-'
            ELSE 'MOB-'
        END,
        u.employee_code
    ) AS device_name,

    CASE
        WHEN x.device_no = 1 THEN 'Laptop'
        ELSE 'Mobile'
    END AS device_type,

    CASE
        WHEN x.device_no = 1 THEN 'Windows 11'
        ELSE
            CASE
                WHEN u.user_id % 2 = 0 THEN 'Android'
                ELSE 'iOS'
            END
    END AS operating_system,

    CONCAT(
        '10.',
        10 + d.department_id,
        '.',
        CASE
            WHEN x.device_no = 1 THEN '10'
            ELSE '20'
        END,
        '.',
        u.user_id
    ) AS ip_address,

    CASE
        WHEN x.device_no = 1 THEN 1
        ELSE
            CASE
                WHEN u.user_id % 10 = 0 THEN 0
                ELSE 1
            END
    END AS managed,

    CASE
        WHEN x.device_no = 1 THEN 1
        ELSE
            CASE
                WHEN u.user_id % 10 = 0 THEN 0
                ELSE 1
            END
    END AS compliant,

    DATEADD(
        MINUTE,
        -(u.user_id * 3),
        CAST('2026-08-30 09:30:00' AS DATETIME2)
    ) AS last_seen

FROM users u
JOIN roles r
    ON u.role_id = r.role_id
JOIN departments d
    ON r.department_id = d.department_id

CROSS JOIN
(
    VALUES
        (1),
        (2)
) AS x(device_no)

WHERE NOT EXISTS
(
    SELECT 1
    FROM user_devices ud
    WHERE ud.device_name =
        CONCAT(
            CASE
                WHEN x.device_no = 1 THEN 'LAP-'
                ELSE 'MOB-'
            END,
            u.employee_code
        )
);
GO


/* ============================================================
   VALIDATION 1 - TOTAL DEVICES
   ============================================================ */

SELECT
    COUNT(*) AS Total_Devices
FROM user_devices;
GO


/* ============================================================
   VALIDATION 2 - DEVICES PER USER
   ============================================================ */

SELECT
    u.employee_code,
    u.full_name,
    COUNT(ud.device_id) AS Device_Count
FROM users u
LEFT JOIN user_devices ud
    ON u.user_id = ud.user_id
GROUP BY
    u.employee_code,
    u.full_name
ORDER BY
    u.employee_code;
GO


/* ============================================================
   VALIDATION 3 - MANAGED / COMPLIANT STATUS
   ============================================================ */

SELECT
    managed,
    compliant,
    COUNT(*) AS Device_Count
FROM user_devices
GROUP BY
    managed,
    compliant
ORDER BY
    managed DESC,
    compliant DESC;
GO