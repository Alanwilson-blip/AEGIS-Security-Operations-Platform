USE AEGIS_DB;
GO

/* =========================================================
   AEGIS - STEP 11
   ANALYSIS QUERIES
   SQL SERVER / SSMS 2022

   PURPOSE:
   Extract security intelligence from the existing
   AEGIS database.

   THIS SCRIPT IS READ-ONLY.
   NO DATA IS INSERTED / UPDATED / DELETED.
   ========================================================= */


/* =========================================================
   1. ORGANIZATION OVERVIEW
   ========================================================= */

SELECT
    (SELECT COUNT(*) FROM departments) AS total_departments,
    (SELECT COUNT(*) FROM roles) AS total_roles,
    (SELECT COUNT(*) FROM users) AS total_users,
    (SELECT COUNT(*) FROM user_devices) AS total_devices,
    (SELECT COUNT(*) FROM resources) AS total_resources,
    (SELECT COUNT(*) FROM permissions) AS total_permissions,
    (SELECT COUNT(*) FROM access_events) AS total_access_events,
    (SELECT COUNT(*) FROM security_alerts) AS total_security_alerts,
    (SELECT COUNT(*) FROM audit_logs) AS total_audit_logs;
GO


/* =========================================================
   2. DEPARTMENT OVERVIEW
   ========================================================= */

SELECT
    d.department_id,
    d.department_name,
    COUNT(DISTINCT r.role_id) AS total_roles,
    COUNT(DISTINCT u.user_id) AS total_users,
    COUNT(DISTINCT res.resource_id) AS total_resources
FROM departments d
LEFT JOIN roles r
    ON d.department_id = r.department_id
LEFT JOIN users u
    ON r.role_id = u.role_id
LEFT JOIN resources res
    ON d.department_id = res.department_id
GROUP BY
    d.department_id,
    d.department_name
ORDER BY
    d.department_id;
GO


/* =========================================================
   3. USER RISK RANKING
   ========================================================= */

SELECT TOP 20
    u.user_id,
    u.employee_code,
    u.full_name,
    d.department_name,
    r.role_name,
    u.risk_score,
    u.status
FROM users u
INNER JOIN roles r
    ON u.role_id = r.role_id
INNER JOIN departments d
    ON r.department_id = d.department_id
ORDER BY
    u.risk_score DESC,
    u.user_id;
GO


/* =========================================================
   4. HIGH-RISK USERS
   ========================================================= */

SELECT
    u.employee_code,
    u.full_name,
    d.department_name,
    r.role_name,
    u.risk_score,
    COUNT(sa.alert_id) AS alert_count
FROM users u
INNER JOIN roles r
    ON u.role_id = r.role_id
INNER JOIN departments d
    ON r.department_id = d.department_id
LEFT JOIN security_alerts sa
    ON u.user_id = sa.user_id
WHERE u.risk_score >= 70
GROUP BY
    u.employee_code,
    u.full_name,
    d.department_name,
    r.role_name,
    u.risk_score
ORDER BY
    u.risk_score DESC;
GO


/* =========================================================
   5. SECURITY ALERT SUMMARY
   ========================================================= */

SELECT
    severity,
    COUNT(*) AS alert_count
FROM security_alerts
GROUP BY
    severity
ORDER BY
    CASE severity
        WHEN 'CRITICAL' THEN 1
        WHEN 'HIGH' THEN 2
        WHEN 'MEDIUM' THEN 3
        WHEN 'LOW' THEN 4
    END;
GO


/* =========================================================
   6. ALERT TYPE ANALYSIS
   ========================================================= */

SELECT
    alert_type,
    COUNT(*) AS alert_count,
    AVG(CAST(risk_score AS DECIMAL(10,2))) AS average_risk_score,
    MAX(risk_score) AS highest_risk_score
FROM security_alerts
GROUP BY
    alert_type
ORDER BY
    alert_count DESC,
    highest_risk_score DESC;
GO


/* =========================================================
   7. ALERTS BY DEPARTMENT
   ========================================================= */

SELECT
    d.department_name,
    COUNT(sa.alert_id) AS total_alerts,
    SUM(
        CASE
            WHEN sa.severity = 'CRITICAL' THEN 1
            ELSE 0
        END
    ) AS critical_alerts,
    SUM(
        CASE
            WHEN sa.severity = 'HIGH' THEN 1
            ELSE 0
        END
    ) AS high_alerts,
    AVG(CAST(sa.risk_score AS DECIMAL(10,2))) AS average_risk
FROM security_alerts sa
INNER JOIN users u
    ON sa.user_id = u.user_id
INNER JOIN roles r
    ON u.role_id = r.role_id
INNER JOIN departments d
    ON r.department_id = d.department_id
GROUP BY
    d.department_name
ORDER BY
    total_alerts DESC;
GO


/* =========================================================
   8. DENIED ACCESS ANALYSIS
   ========================================================= */

SELECT
    COUNT(*) AS total_denied_access_attempts,
    COUNT(DISTINCT user_id) AS users_involved,
    COUNT(DISTINCT resource_id) AS resources_targeted
FROM access_events
WHERE result = 'DENY'
  AND event_type = 'RESOURCE_ACCESS';
GO


/* =========================================================
   9. USERS WITH MOST DENIED ACCESS ATTEMPTS
   ========================================================= */

SELECT TOP 20
    u.employee_code,
    u.full_name,
    d.department_name,
    r.role_name,
    COUNT(ae.event_id) AS denied_attempts,
    MAX(ae.risk_score) AS highest_risk
FROM access_events ae
INNER JOIN users u
    ON ae.user_id = u.user_id
INNER JOIN roles r
    ON u.role_id = r.role_id
INNER JOIN departments d
    ON r.department_id = d.department_id
WHERE ae.result = 'DENY'
  AND ae.event_type = 'RESOURCE_ACCESS'
GROUP BY
    u.employee_code,
    u.full_name,
    d.department_name,
    r.role_name
ORDER BY
    denied_attempts DESC,
    highest_risk DESC;
GO


/* =========================================================
   10. MOST TARGETED RESOURCES
   ========================================================= */

SELECT TOP 20
    res.resource_name,
    d.department_name,
    res.sensitivity,
    COUNT(ae.event_id) AS access_attempts,
    SUM(
        CASE
            WHEN ae.result = 'DENY' THEN 1
            ELSE 0
        END
    ) AS denied_attempts
FROM resources res
INNER JOIN departments d
    ON res.department_id = d.department_id
LEFT JOIN access_events ae
    ON res.resource_id = ae.resource_id
GROUP BY
    res.resource_name,
    d.department_name,
    res.sensitivity
ORDER BY
    denied_attempts DESC,
    access_attempts DESC;
GO


/* =========================================================
   11. RESOURCE ACCESS BY RESULT
   ========================================================= */

SELECT
    result,
    COUNT(*) AS access_count,
    AVG(CAST(risk_score AS DECIMAL(10,2))) AS average_risk
FROM access_events
WHERE event_type = 'RESOURCE_ACCESS'
GROUP BY
    result
ORDER BY
    access_count DESC;
GO


/* =========================================================
   12. ACCESS ACTIVITY BY EVENT TYPE
   ========================================================= */

SELECT
    event_type,
    COUNT(*) AS event_count
FROM access_events
GROUP BY
    event_type
ORDER BY
    event_count DESC;
GO


/* =========================================================
   13. LOGIN ANALYSIS
   ========================================================= */

SELECT
    result,
    COUNT(*) AS login_count,
    COUNT(DISTINCT user_id) AS unique_users,
    AVG(CAST(risk_score AS DECIMAL(10,2))) AS average_risk
FROM access_events
WHERE event_type = 'LOGIN'
GROUP BY
    result
ORDER BY
    login_count DESC;
GO


/* =========================================================
   14. MFA ANALYSIS
   ========================================================= */

SELECT
    result,
    COUNT(*) AS mfa_events,
    AVG(CAST(risk_score AS DECIMAL(10,2))) AS average_risk
FROM access_events
WHERE event_type = 'MFA_EVENT'
GROUP BY
    result;
GO


/* =========================================================
   15. DEVICE SECURITY ANALYSIS
   ========================================================= */

SELECT
    COUNT(*) AS total_devices,
    SUM(
        CASE
            WHEN managed = 1 THEN 1
            ELSE 0
        END
    ) AS managed_devices,
    SUM(
        CASE
            WHEN managed = 0 THEN 1
            ELSE 0
        END
    ) AS unmanaged_devices,
    SUM(
        CASE
            WHEN compliant = 1 THEN 1
            ELSE 0
        END
    ) AS compliant_devices,
    SUM(
        CASE
            WHEN compliant = 0 THEN 1
            ELSE 0
        END
    ) AS non_compliant_devices
FROM user_devices;
GO


/* =========================================================
   16. USERS WITH UNMANAGED / NON-COMPLIANT DEVICES
   ========================================================= */

SELECT
    u.employee_code,
    u.full_name,
    d.department_name,
    r.role_name,
    ud.device_name,
    ud.device_type,
    ud.operating_system,
    ud.managed,
    ud.compliant,
    ud.ip_address,
    ud.last_seen
FROM user_devices ud
INNER JOIN users u
    ON ud.user_id = u.user_id
INNER JOIN roles r
    ON u.role_id = r.role_id
INNER JOIN departments d
    ON r.department_id = d.department_id
WHERE ud.managed = 0
   OR ud.compliant = 0
ORDER BY
    d.department_name,
    u.full_name;
GO


/* =========================================================
   17. PRIVILEGED PERMISSION ANALYSIS
   ========================================================= */

SELECT
    d.department_name,
    r.role_name,
    res.resource_name,
    res.sensitivity,
    p.can_view,
    p.can_create,
    p.can_edit,
    p.can_delete,
    p.can_admin
FROM permissions p
INNER JOIN roles r
    ON p.role_id = r.role_id
INNER JOIN departments d
    ON r.department_id = d.department_id
INNER JOIN resources res
    ON p.resource_id = res.resource_id
WHERE p.can_admin = 1
ORDER BY
    d.department_name,
    r.role_name,
    res.resource_name;
GO


/* =========================================================
   18. DELETE PERMISSION ANALYSIS
   ========================================================= */

SELECT
    d.department_name,
    r.role_name,
    COUNT(*) AS delete_permissions
FROM permissions p
INNER JOIN roles r
    ON p.role_id = r.role_id
INNER JOIN departments d
    ON r.department_id = d.department_id
WHERE p.can_delete = 1
GROUP BY
    d.department_name,
    r.role_name
ORDER BY
    delete_permissions DESC;
GO


/* =========================================================
   19. SENSITIVE RESOURCE ACCESS
   ========================================================= */

SELECT TOP 50
    ae.event_id,
    u.employee_code,
    u.full_name,
    d.department_name,
    res.resource_name,
    res.sensitivity,
    ae.action,
    ae.result,
    ae.risk_score,
    ae.event_timestamp
FROM access_events ae
INNER JOIN users u
    ON ae.user_id = u.user_id
INNER JOIN roles r
    ON u.role_id = r.role_id
INNER JOIN departments d
    ON r.department_id = d.department_id
INNER JOIN resources res
    ON ae.resource_id = res.resource_id
WHERE res.sensitivity IN ('RESTRICTED', 'CRITICAL')
ORDER BY
    ae.risk_score DESC,
    ae.event_timestamp DESC;
GO


/* =========================================================
   20. CRITICAL / HIGH RISK ACCESS EVENTS
   ========================================================= */

SELECT TOP 50
    ae.event_id,
    u.employee_code,
    u.full_name,
    d.department_name,
    res.resource_name,
    ae.event_type,
    ae.action,
    ae.result,
    ae.risk_score,
    ae.reason,
    ae.event_timestamp
FROM access_events ae
INNER JOIN users u
    ON ae.user_id = u.user_id
INNER JOIN roles r
    ON u.role_id = r.role_id
INNER JOIN departments d
    ON r.department_id = d.department_id
LEFT JOIN resources res
    ON ae.resource_id = res.resource_id
WHERE ae.risk_score >= 70
ORDER BY
    ae.risk_score DESC,
    ae.event_timestamp DESC;
GO


/* =========================================================
   21. OPEN SECURITY ALERTS
   ========================================================= */

SELECT
    sa.alert_id,
    u.employee_code,
    u.full_name,
    d.department_name,
    sa.alert_type,
    sa.severity,
    sa.risk_score,
    sa.status,
    sa.description,
    sa.created_at
FROM security_alerts sa
INNER JOIN users u
    ON sa.user_id = u.user_id
INNER JOIN roles r
    ON u.role_id = r.role_id
INNER JOIN departments d
    ON r.department_id = d.department_id
WHERE sa.status IN ('OPEN', 'INVESTIGATING')
ORDER BY
    CASE sa.severity
        WHEN 'CRITICAL' THEN 1
        WHEN 'HIGH' THEN 2
        WHEN 'MEDIUM' THEN 3
        WHEN 'LOW' THEN 4
    END,
    sa.risk_score DESC;
GO


/* =========================================================
   22. SECURITY ALERT STATUS
   ========================================================= */

SELECT
    status,
    COUNT(*) AS alert_count
FROM security_alerts
GROUP BY
    status
ORDER BY
    alert_count DESC;
GO


/* =========================================================
   23. AUDIT ACTIVITY SUMMARY
   ========================================================= */

SELECT
    audit_action,
    COUNT(*) AS activity_count
FROM audit_logs
GROUP BY
    audit_action
ORDER BY
    activity_count DESC;
GO


/* =========================================================
   24. MOST ACTIVE AUDIT ACTORS
   ========================================================= */

SELECT TOP 20
    u.employee_code,
    u.full_name,
    COUNT(al.audit_id) AS audit_actions
FROM audit_logs al
INNER JOIN users u
    ON al.actor_user_id = u.user_id
GROUP BY
    u.employee_code,
    u.full_name
ORDER BY
    audit_actions DESC;
GO


/* =========================================================
   25. EXECUTIVE SECURITY SUMMARY
   ========================================================= */

SELECT
    (SELECT COUNT(*)
     FROM security_alerts
     WHERE severity = 'CRITICAL'
       AND status IN ('OPEN', 'INVESTIGATING'))
        AS critical_open_alerts,

    (SELECT COUNT(*)
     FROM security_alerts
     WHERE severity = 'HIGH'
       AND status IN ('OPEN', 'INVESTIGATING'))
        AS high_open_alerts,

    (SELECT COUNT(*)
     FROM access_events
     WHERE result = 'DENY'
       AND event_type = 'RESOURCE_ACCESS')
        AS denied_access_attempts,

    (SELECT COUNT(*)
     FROM user_devices
     WHERE managed = 0
        OR compliant = 0)
        AS device_security_issues,

    (SELECT COUNT(*)
     FROM users
     WHERE risk_score >= 70)
        AS high_risk_users,

    (SELECT COUNT(*)
     FROM security_alerts
     WHERE status = 'OPEN')
        AS open_alerts,

    (SELECT COUNT(*)
     FROM security_alerts)
        AS total_alerts;
GO


/* =========================================================
   26. TEST SCENARIO RESULTS
   ========================================================= */

SELECT
    alert_type,
    severity,
    COUNT(*) AS detected_count
FROM security_alerts
WHERE alert_type IN
(
    'REPEATED_UNAUTHORIZED_ACCESS',
    'UNMANAGED_DEVICE_ACCESS',
    'PRIVILEGED_ACTION',
    'IMPOSSIBLE_LOCATION_LOGIN',
    'AFTER_HOURS_CRITICAL_ACCESS',
    'CROSS_DEPARTMENT_ACCESS'
)
GROUP BY
    alert_type,
    severity
ORDER BY
    CASE severity
        WHEN 'CRITICAL' THEN 1
        WHEN 'HIGH' THEN 2
        WHEN 'MEDIUM' THEN 3
        WHEN 'LOW' THEN 4
    END,
    alert_type;
GO


/* =========================================================
   27. FINAL AEGIS HEALTH CHECK
   ========================================================= */

SELECT
    'Departments' AS component,
    COUNT(*) AS record_count
FROM departments

UNION ALL

SELECT
    'Roles',
    COUNT(*)
FROM roles

UNION ALL

SELECT
    'Users',
    COUNT(*)
FROM users

UNION ALL

SELECT
    'Devices',
    COUNT(*)
FROM user_devices

UNION ALL

SELECT
    'Resources',
    COUNT(*)
FROM resources

UNION ALL

SELECT
    'Permissions',
    COUNT(*)
FROM permissions

UNION ALL

SELECT
    'Access Events',
    COUNT(*)
FROM access_events

UNION ALL

SELECT
    'Security Alerts',
    COUNT(*)
FROM security_alerts

UNION ALL

SELECT
    'Audit Logs',
    COUNT(*)
FROM audit_logs;
GO