CREATE TABLE device_vpn_history
(
    vpn_history_id INT IDENTITY(1,1) PRIMARY KEY,

    device_id INT NOT NULL,
    user_id INT NOT NULL,
    event_id BIGINT NOT NULL,

    vpn_enabled BIT NOT NULL,

    observed_at DATETIME2 NOT NULL,

    CONSTRAINT FK_vpn_history_device
        FOREIGN KEY (device_id)
        REFERENCES user_devices(device_id),

    CONSTRAINT FK_vpn_history_user
        FOREIGN KEY (user_id)
        REFERENCES users(user_id),

    CONSTRAINT FK_vpn_history_event
        FOREIGN KEY (event_id)
        REFERENCES access_events(event_id)
);
