USE AEGIS_DB;
GO

/* ============================================================
   AEGIS - RESOURCE SEED DATA
   12 Departments × 6 Resources = 72 Resources
   Safe to rerun
   ============================================================ */

INSERT INTO resources
(
    resource_name,
    department_id,
    resource_type,
    sensitivity,
    description
)
SELECT
    v.resource_name,
    d.department_id,
    v.resource_type,
    v.sensitivity,
    v.description
FROM
(
    VALUES

    /* ========================================================
       1. ENGINEERING & DEVELOPMENT
       ======================================================== */

    ('Engineering & Development', 'Source Code',
     'Code Repository', 'RESTRICTED',
     'Source code repositories and software development code'),

    ('Engineering & Development', 'Development Projects',
     'Project Data', 'INTERNAL',
     'Engineering projects, tasks and development information'),

    ('Engineering & Development', 'Development Environments',
     'Development Environment', 'CONFIDENTIAL',
     'Development and testing environments used by engineers'),

    ('Engineering & Development', 'Cloud Development Resources',
     'Cloud Resource', 'RESTRICTED',
     'Cloud resources used for engineering and development'),

    ('Engineering & Development', 'CI/CD Pipelines',
     'Pipeline', 'RESTRICTED',
     'Continuous integration and deployment pipelines'),

    ('Engineering & Development', 'Technical Documentation',
     'Documentation', 'INTERNAL',
     'Engineering architecture, technical guides and documentation'),


    /* ========================================================
       2. RESEARCH & DATA SCIENCE
       ======================================================== */

    ('Research & Data Science', 'Research Datasets',
     'Dataset', 'RESTRICTED',
     'Research datasets used for analysis and experimentation'),

    ('Research & Data Science', 'Data Science Workspaces',
     'Workspace', 'CONFIDENTIAL',
     'Data science development and analysis workspaces'),

    ('Research & Data Science', 'ML Models',
     'Machine Learning', 'RESTRICTED',
     'Machine learning models and model artifacts'),

    ('Research & Data Science', 'Experiments',
     'Research Data', 'CONFIDENTIAL',
     'Research experiments and experimental results'),

    ('Research & Data Science', 'Research Documentation',
     'Documentation', 'INTERNAL',
     'Research methods, technical documentation and notes'),

    ('Research & Data Science', 'Research Reports',
     'Report', 'CONFIDENTIAL',
     'Research findings, reports and analytical results'),


    /* ========================================================
       3. PRODUCT & PROGRAM MANAGEMENT
       ======================================================== */

    ('Product & Program Management', 'Product Roadmaps',
     'Product Data', 'INTERNAL',
     'Product development roadmaps and strategic plans'),

    ('Product & Program Management', 'Product Requirements',
     'Requirements', 'CONFIDENTIAL',
     'Product requirements and feature specifications'),

    ('Product & Program Management', 'Project Plans',
     'Project Data', 'INTERNAL',
     'Project plans, milestones and delivery information'),

    ('Product & Program Management', 'Program Documentation',
     'Documentation', 'INTERNAL',
     'Program management documentation and records'),

    ('Product & Program Management', 'Product Analytics',
     'Analytics', 'CONFIDENTIAL',
     'Product usage and performance analytics'),

    ('Product & Program Management', 'Release Information',
     'Release Data', 'CONFIDENTIAL',
     'Product release schedules and release information'),


    /* ========================================================
       4. SALES & MARKETING
       ======================================================== */

    ('Sales & Marketing', 'Customer Accounts',
     'Customer Data', 'CONFIDENTIAL',
     'Customer account information used by sales teams'),

    ('Sales & Marketing', 'Sales Opportunities',
     'Sales Data', 'CONFIDENTIAL',
     'Sales opportunities, deals and pipeline information'),

    ('Sales & Marketing', 'Marketing Campaigns',
     'Marketing Data', 'INTERNAL',
     'Marketing campaigns and campaign management information'),

    ('Sales & Marketing', 'Customer Analytics',
     'Analytics', 'CONFIDENTIAL',
     'Customer and sales-related analytical information'),

    ('Sales & Marketing', 'Sales Reports',
     'Report', 'CONFIDENTIAL',
     'Sales performance and business reports'),

    ('Sales & Marketing', 'Marketing Content',
     'Content', 'INTERNAL',
     'Marketing materials, content and campaign assets'),


    /* ========================================================
       5. CUSTOMER SUPPORT
       ======================================================== */

    ('Customer Support', 'Support Tickets',
     'Support Data', 'CONFIDENTIAL',
     'Customer support tickets and service requests'),

    ('Customer Support', 'Customer Profiles',
     'Customer Data', 'RESTRICTED',
     'Customer profile and service-related information'),

    ('Customer Support', 'Knowledge Base',
     'Documentation', 'INTERNAL',
     'Support knowledge base and troubleshooting information'),

    ('Customer Support', 'Support Analytics',
     'Analytics', 'CONFIDENTIAL',
     'Support performance and service analytics'),

    ('Customer Support', 'Customer Feedback',
     'Customer Data', 'CONFIDENTIAL',
     'Customer feedback and service evaluations'),

    ('Customer Support', 'Escalation Records',
     'Support Data', 'RESTRICTED',
     'Escalated support cases and resolution information'),


    /* ========================================================
       6. OPERATIONS
       ======================================================== */

    ('Operations', 'Operational Records',
     'Operational Data', 'CONFIDENTIAL',
     'Operational records and business process information'),

    ('Operations', 'Process Documentation',
     'Documentation', 'INTERNAL',
     'Operational procedures and process documentation'),

    ('Operations', 'Workflow Data',
     'Operational Data', 'CONFIDENTIAL',
     'Business workflow and process execution data'),

    ('Operations', 'Vendor Information',
     'Vendor Data', 'CONFIDENTIAL',
     'Vendor records and operational vendor information'),

    ('Operations', 'Operations Reports',
     'Report', 'CONFIDENTIAL',
     'Operational performance and business reports'),

    ('Operations', 'Scheduling Data',
     'Scheduling Data', 'INTERNAL',
     'Operational schedules and resource allocation information'),


    /* ========================================================
       7. FINANCE
       ======================================================== */

    ('Finance', 'Financial Records',
     'Financial Data', 'RESTRICTED',
     'Financial transactions and accounting records'),

    ('Finance', 'Budgets',
     'Financial Data', 'CONFIDENTIAL',
     'Departmental and organizational budget information'),

    ('Finance', 'Expense Reports',
     'Financial Data', 'CONFIDENTIAL',
     'Employee and organizational expense records'),

    ('Finance', 'Revenue Reports',
     'Financial Report', 'RESTRICTED',
     'Revenue performance and financial reporting'),

    ('Finance', 'Financial Forecasts',
     'Financial Data', 'RESTRICTED',
     'Financial forecasts and planning information'),

    ('Finance', 'Payroll/Compensation Data',
     'Compensation Data', 'CRITICAL',
     'Highly sensitive payroll and compensation information'),


    /* ========================================================
       8. HUMAN RESOURCES
       ======================================================== */

    ('Human Resources', 'Employee Records',
     'Employee Data', 'RESTRICTED',
     'Employee personal, employment and organizational records'),

    ('Human Resources', 'Recruitment Records',
     'Recruitment Data', 'CONFIDENTIAL',
     'Recruitment candidates and hiring information'),

    ('Human Resources', 'Performance Records',
     'Employee Data', 'RESTRICTED',
     'Employee performance and evaluation information'),

    ('Human Resources', 'Benefits Information',
     'Employee Data', 'RESTRICTED',
     'Employee benefits and related information'),

    ('Human Resources', 'HR Reports',
     'Report', 'CONFIDENTIAL',
     'Human resources reports and workforce analytics'),

    ('Human Resources', 'Compensation Data',
     'Compensation Data', 'CRITICAL',
     'Highly sensitive employee compensation information'),


    /* ========================================================
       9. LEGAL
       ======================================================== */

    ('Legal', 'Legal Documents',
     'Legal Data', 'CONFIDENTIAL',
     'Legal documents and organizational legal records'),

    ('Legal', 'Contracts',
     'Legal Data', 'RESTRICTED',
     'Business contracts and contractual agreements'),

    ('Legal', 'Compliance Records',
     'Compliance Data', 'RESTRICTED',
     'Compliance records and regulatory documentation'),

    ('Legal', 'Case Files',
     'Legal Case Data', 'CRITICAL',
     'Sensitive legal cases and investigation records'),

    ('Legal', 'Legal Reports',
     'Report', 'CONFIDENTIAL',
     'Legal analysis and reporting information'),

    ('Legal', 'Regulatory Information',
     'Compliance Data', 'CONFIDENTIAL',
     'Regulatory requirements and related information'),


    /* ========================================================
       10. IT
       ======================================================== */

    ('IT', 'IT Tickets',
     'IT Support Data', 'INTERNAL',
     'IT support tickets and technical service requests'),

    ('IT', 'User Accounts',
     'Identity Data', 'RESTRICTED',
     'Organizational user accounts and account information'),

    ('IT', 'Devices',
     'Device Data', 'CONFIDENTIAL',
     'Managed organizational devices and device information'),

    ('IT', 'Network Resources',
     'Network Data', 'RESTRICTED',
     'Network infrastructure and network resource information'),

    ('IT', 'System Configurations',
     'Configuration Data', 'RESTRICTED',
     'System and infrastructure configuration information'),

    ('IT', 'IT Documentation',
     'Documentation', 'INTERNAL',
     'IT procedures, technical documentation and guides'),


    /* ========================================================
       11. SECURITY
       ======================================================== */

    ('Security', 'Security Events',
     'Security Data', 'RESTRICTED',
     'Security-related authentication and activity events'),

    ('Security', 'Security Incidents',
     'Incident Data', 'CRITICAL',
     'Security incidents and incident management records'),

    ('Security', 'Threat Intelligence',
     'Security Data', 'RESTRICTED',
     'Threat intelligence and threat analysis information'),

    ('Security', 'Security Investigations',
     'Investigation Data', 'CRITICAL',
     'Security investigation records and evidence'),

    ('Security', 'Security Policies',
     'Security Policy', 'RESTRICTED',
     'Organizational security policies and standards'),

    ('Security', 'Security Configuration',
     'Security Configuration', 'CRITICAL',
     'Security infrastructure and security configuration data'),


    /* ========================================================
       12. ADMINISTRATION
       ======================================================== */

    ('Administration', 'Administrative Records',
     'Administrative Data', 'INTERNAL',
     'General administrative records and organizational information'),

    ('Administration', 'Office Information',
     'Administrative Data', 'INTERNAL',
     'Office and workplace information'),

    ('Administration', 'Internal Requests',
     'Request Data', 'INTERNAL',
     'Internal administrative requests and service records'),

    ('Administration', 'Organization Records',
     'Organization Data', 'CONFIDENTIAL',
     'Organizational structure and administrative records'),

    ('Administration', 'Administrative Reports',
     'Report', 'CONFIDENTIAL',
     'Administrative reports and organizational summaries'),

    ('Administration', 'Administrative Configuration',
     'Configuration Data', 'RESTRICTED',
     'Administrative system configuration and controls')

) AS v
(
    department_name,
    resource_name,
    resource_type,
    sensitivity,
    description
)
INNER JOIN departments d
    ON d.department_name = v.department_name
WHERE NOT EXISTS
(
    SELECT 1
    FROM resources r
    WHERE r.department_id = d.department_id
      AND r.resource_name = v.resource_name
);

GO


/* ============================================================
   VALIDATION
   ============================================================ */

SELECT COUNT(*) AS Total_Resources
FROM resources;
GO

SELECT
    d.department_id,
    d.department_name,
    COUNT(r.resource_id) AS Resource_Count
FROM departments d
LEFT JOIN resources r
    ON d.department_id = r.department_id
GROUP BY
    d.department_id,
    d.department_name
ORDER BY
    d.department_id;
GO