USE AEGIS_DB;
GO

/* =========================================================
   AEGIS - STEP 10
   TEST ATTACK / SECURITY SCENARIOS
   SQL SERVER / SSMS 2022

   Purpose:
   Create controlled suspicious activity so AEGIS can
   demonstrate detection and investigation capabilities.

   Existing schema is NOT changed.
   ========================================================= */


/* =========================================================
   SCENARIO 1
   REPEATED UNAUTHORIZED ACCESS

   A Sales Specialist repeatedly attempts to access
   restricted Finance information.
   ========================================================= */

DECLARE
    @User1 INT,
    @Role1 INT,
    @Device1 INT,
    @Resource1 INT;

SELECT TOP 1
    @User1 = u.user_id,
    @Role1 = u.role_id
FROM users u
INNER JOIN roles r
    ON u.role_id = r.role_id
INNER JOIN departments d
    ON r.department_id = d.department_id
WHERE r.role_name = 'Sales Specialist'
  AND d.department_name = 'Sales & Marketing'
  AND u.status = 'ACTIVE'
ORDER BY u.user_id;

SELECT TOP 1
    @Device1 = device_id
FROM user_devices
WHERE user_id = @User1
ORDER BY device_id;

SELECT TOP 1
    @Resource1 = res.resource_id
FROM resources res
INNER JOIN departments d
    ON res.department_id = d.department_id
WHERE d.department_name = 'Finance'
  AND res.resource_name = 'Financial Records';


INSERT INTO access_events
(
    user_id,
    device_id,
    role_id,
    resource_id,
    event_type,
    [action],
    event_timestamp,
    result,
    source_ip,
    location,
    auth_method,
    user_agent,
    risk_score,
    reason
)
SELECT
    @User1,
    @Device1,
    @Role1,
    @Resource1,
    'RESOURCE_ACCESS',
    'VIEW',
    DATEADD(MINUTE, -20, SYSDATETIME()),
    'DENY',
    '10.99.10.50',
    'Seattle',
    'MFA',
    'AEGIS-Test-Client',
    85,
    'TEST_SCENARIO_01_REPEATED_UNAUTHORIZED_ACCESS_1'
WHERE NOT EXISTS
(
    SELECT 1
    FROM access_events
    WHERE reason = 'TEST_SCENARIO_01_REPEATED_UNAUTHORIZED_ACCESS_1'
);


INSERT INTO access_events
(
    user_id,
    device_id,
    role_id,
    resource_id,
    event_type,
    [action],
    event_timestamp,
    result,
    source_ip,
    location,
    auth_method,
    user_agent,
    risk_score,
    reason
)
SELECT
    @User1,
    @Device1,
    @Role1,
    @Resource1,
    'RESOURCE_ACCESS',
    'VIEW',
    DATEADD(MINUTE, -15, SYSDATETIME()),
    'DENY',
    '10.99.10.50',
    'Seattle',
    'MFA',
    'AEGIS-Test-Client',
    90,
    'TEST_SCENARIO_01_REPEATED_UNAUTHORIZED_ACCESS_2'
WHERE NOT EXISTS
(
    SELECT 1
    FROM access_events
    WHERE reason = 'TEST_SCENARIO_01_REPEATED_UNAUTHORIZED_ACCESS_2'
);


INSERT INTO access_events
(
    user_id,
    device_id,
    role_id,
    resource_id,
    event_type,
    [action],
    event_timestamp,
    result,
    source_ip,
    location,
    auth_method,
    user_agent,
    risk_score,
    reason
)
SELECT
    @User1,
    @Device1,
    @Role1,
    @Resource1,
    'RESOURCE_ACCESS',
    'VIEW',
    DATEADD(MINUTE, -10, SYSDATETIME()),
    'DENY',
    '10.99.10.50',
    'Seattle',
    'MFA',
    'AEGIS-Test-Client',
    95,
    'TEST_SCENARIO_01_REPEATED_UNAUTHORIZED_ACCESS_3'
WHERE NOT EXISTS
(
    SELECT 1
    FROM access_events
    WHERE reason = 'TEST_SCENARIO_01_REPEATED_UNAUTHORIZED_ACCESS_3'
);
GO


/* =========================================================
   SCENARIO 2
   UNMANAGED DEVICE ACCESS

   A user attempts to access restricted information
   from a non-compliant device.
   ========================================================= */

DECLARE
    @User2 INT,
    @Role2 INT,
    @Device2 INT,
    @Resource2 INT;

SELECT TOP 1
    @Device2 = ud.device_id,
    @User2 = ud.user_id
FROM user_devices ud
WHERE ud.managed = 0
   OR ud.compliant = 0
ORDER BY ud.device_id;

SELECT
    @Role2 = role_id
FROM users
WHERE user_id = @User2;

SELECT TOP 1
    @Resource2 = res.resource_id
FROM resources res
WHERE res.sensitivity IN ('RESTRICTED', 'CRITICAL')
ORDER BY
    CASE
        WHEN res.sensitivity = 'CRITICAL' THEN 1
        ELSE 2
    END,
    res.resource_id;


INSERT INTO access_events
(
    user_id,
    device_id,
    role_id,
    resource_id,
    event_type,
    [action],
    event_timestamp,
    result,
    source_ip,
    location,
    auth_method,
    user_agent,
    risk_score,
    reason
)
SELECT
    @User2,
    @Device2,
    @Role2,
    @Resource2,
    'RESOURCE_ACCESS',
    'VIEW',
    DATEADD(MINUTE, -8, SYSDATETIME()),
    'ALLOW',
    '10.88.20.77',
    'Unknown',
    'PASSWORD',
    'AEGIS-Test-Client',
    82,
    'TEST_SCENARIO_02_UNMANAGED_DEVICE_ACCESS'
WHERE NOT EXISTS
(
    SELECT 1
    FROM access_events
    WHERE reason = 'TEST_SCENARIO_02_UNMANAGED_DEVICE_ACCESS'
);
GO


/* =========================================================
   SCENARIO 3
   PRIVILEGED SECURITY ACTION

   A Security Manager performs an administrative action
   against security configuration.
   ========================================================= */

DECLARE
    @User3 INT,
    @Role3 INT,
    @Device3 INT,
    @Resource3 INT;

SELECT TOP 1
    @User3 = u.user_id,
    @Role3 = u.role_id
FROM users u
INNER JOIN roles r
    ON u.role_id = r.role_id
INNER JOIN departments d
    ON r.department_id = d.department_id
WHERE r.role_name = 'Security Manager'
  AND d.department_name = 'Security'
  AND u.status = 'ACTIVE'
ORDER BY u.user_id;

SELECT TOP 1
    @Device3 = device_id
FROM user_devices
WHERE user_id = @User3
ORDER BY device_id;

SELECT TOP 1
    @Resource3 = resource_id
FROM resources
WHERE resource_name = 'Security Configuration';


INSERT INTO access_events
(
    user_id,
    device_id,
    role_id,
    resource_id,
    event_type,
    [action],
    event_timestamp,
    result,
    source_ip,
    location,
    auth_method,
    user_agent,
    risk_score,
    reason
)
SELECT
    @User3,
    @Device3,
    @Role3,
    @Resource3,
    'RESOURCE_ACCESS',
    'ADMIN',
    DATEADD(MINUTE, -6, SYSDATETIME()),
    'ALLOW',
    '10.50.10.25',
    'Redmond',
    'MFA',
    'AEGIS-Admin-Console',
    70,
    'TEST_SCENARIO_03_PRIVILEGED_SECURITY_ACTION'
WHERE NOT EXISTS
(
    SELECT 1
    FROM access_events
    WHERE reason = 'TEST_SCENARIO_03_PRIVILEGED_SECURITY_ACTION'
);
GO


/* =========================================================
   SCENARIO 4
   SUSPICIOUS LOGIN

   Same account logs in from two different IP locations
   within a short period.
   ========================================================= */

DECLARE
    @User4 INT,
    @Role4 INT,
    @Device4 INT;

SELECT TOP 1
    @User4 = u.user_id,
    @Role4 = u.role_id
FROM users u
INNER JOIN roles r
    ON u.role_id = r.role_id
WHERE u.status = 'ACTIVE'
ORDER BY u.user_id DESC;

SELECT TOP 1
    @Device4 = device_id
FROM user_devices
WHERE user_id = @User4
ORDER BY device_id;


INSERT INTO access_events
(
    user_id,
    device_id,
    role_id,
    resource_id,
    event_type,
    [action],
    event_timestamp,
    result,
    source_ip,
    location,
    auth_method,
    user_agent,
    risk_score,
    reason
)
SELECT
    @User4,
    @Device4,
    @Role4,
    NULL,
    'LOGIN',
    'LOGIN',
    DATEADD(MINUTE, -4, SYSDATETIME()),
    'ALLOW',
    '172.20.44.18',
    'London',
    'PASSWORD',
    'AEGIS-Test-Client',
    78,
    'TEST_SCENARIO_04_SUSPICIOUS_LOGIN_LOCATION_A'
WHERE NOT EXISTS
(
    SELECT 1
    FROM access_events
    WHERE reason = 'TEST_SCENARIO_04_SUSPICIOUS_LOGIN_LOCATION_A'
);


INSERT INTO access_events
(
    user_id,
    device_id,
    role_id,
    resource_id,
    event_type,
    [action],
    event_timestamp,
    result,
    source_ip,
    location,
    auth_method,
    user_agent,
    risk_score,
    reason
)
SELECT
    @User4,
    @Device4,
    @Role4,
    NULL,
    'LOGIN',
    'LOGIN',
    DATEADD(MINUTE, -2, SYSDATETIME()),
    'ALLOW',
    '203.0.113.88',
    'Singapore',
    'PASSWORD',
    'AEGIS-Test-Client',
    92,
    'TEST_SCENARIO_04_SUSPICIOUS_LOGIN_LOCATION_B'
WHERE NOT EXISTS
(
    SELECT 1
    FROM access_events
    WHERE reason = 'TEST_SCENARIO_04_SUSPICIOUS_LOGIN_LOCATION_B'
);
GO


/* =========================================================
   SCENARIO 5
   AFTER-HOURS RESTRICTED RESOURCE ACCESS

   Simulates access to a critical resource during an
   unusual time window.
   ========================================================= */

DECLARE
    @User5 INT,
    @Role5 INT,
    @Device5 INT,
    @Resource5 INT;

SELECT TOP 1
    @User5 = u.user_id,
    @Role5 = u.role_id
FROM users u
INNER JOIN roles r
    ON u.role_id = r.role_id
WHERE u.status = 'ACTIVE'
ORDER BY u.user_id;

SELECT TOP 1
    @Device5 = device_id
FROM user_devices
WHERE user_id = @User5
ORDER BY device_id;

SELECT TOP 1
    @Resource5 = resource_id
FROM resources
WHERE sensitivity = 'CRITICAL'
ORDER BY resource_id;


INSERT INTO access_events
(
    user_id,
    device_id,
    role_id,
    resource_id,
    event_type,
    [action],
    event_timestamp,
    result,
    source_ip,
    location,
    auth_method,
    user_agent,
    risk_score,
    reason
)
SELECT
    @User5,
    @Device5,
    @Role5,
    @Resource5,
    'RESOURCE_ACCESS',
    'VIEW',
    DATEADD(HOUR, -12, SYSDATETIME()),
    'ALLOW',
    '10.77.40.19',
    'Redmond',
    'MFA',
    'AEGIS-Test-Client',
    88,
    'TEST_SCENARIO_05_AFTER_HOURS_CRITICAL_ACCESS'
WHERE NOT EXISTS
(
    SELECT 1
    FROM access_events
    WHERE reason = 'TEST_SCENARIO_05_AFTER_HOURS_CRITICAL_ACCESS'
);
GO


/* =========================================================
   SCENARIO 6
   CROSS-DEPARTMENT RESTRICTED ACCESS

   A normal employee attempts to access sensitive
   information belonging to another department.
   ========================================================= */

DECLARE
    @User6 INT,
    @Role6 INT,
    @Device6 INT,
    @Resource6 INT;

SELECT TOP 1
    @User6 = u.user_id,
    @Role6 = u.role_id
FROM users u
INNER JOIN roles r
    ON u.role_id = r.role_id
INNER JOIN departments d
    ON r.department_id = d.department_id
WHERE d.department_name = 'Customer Support'
  AND r.role_name = 'Support Representative'
  AND u.status = 'ACTIVE'
ORDER BY u.user_id;

SELECT TOP 1
    @Device6 = device_id
FROM user_devices
WHERE user_id = @User6
ORDER BY device_id;

SELECT TOP 1
    @Resource6 = resource_id
FROM resources
WHERE resource_name = 'Payroll/Compensation Data';


INSERT INTO access_events
(
    user_id,
    device_id,
    role_id,
    resource_id,
    event_type,
    [action],
    event_timestamp,
    result,
    source_ip,
    location,
    auth_method,
    user_agent,
    risk_score,
    reason
)
SELECT
    @User6,
    @Device6,
    @Role6,
    @Resource6,
    'RESOURCE_ACCESS',
    'VIEW',
    DATEADD(MINUTE, -3, SYSDATETIME()),
    'DENY',
    '10.66.30.91',
    'Seattle',
    'MFA',
    'AEGIS-Test-Client',
    94,
    'TEST_SCENARIO_06_CROSS_DEPARTMENT_RESTRICTED_ACCESS'
WHERE NOT EXISTS
(
    SELECT 1
    FROM access_events
    WHERE reason = 'TEST_SCENARIO_06_CROSS_DEPARTMENT_RESTRICTED_ACCESS'
);
GO


/* =========================================================
   GENERATE SECURITY ALERTS FOR TEST SCENARIOS
   ========================================================= */


/* Scenario 1 */

INSERT INTO security_alerts
(
    event_id,
    user_id,
    alert_type,
    severity,
    risk_score,
    description,
    status,
    created_at
)
SELECT
    ae.event_id,
    ae.user_id,
    'REPEATED_UNAUTHORIZED_ACCESS',
    'CRITICAL',
    ae.risk_score,
    'Multiple unauthorized attempts were detected against a protected resource.',
    'OPEN',
    ae.event_timestamp
FROM access_events ae
WHERE ae.reason LIKE 'TEST_SCENARIO_01_REPEATED_UNAUTHORIZED_ACCESS%'
  AND NOT EXISTS
(
    SELECT 1
    FROM security_alerts sa
    WHERE sa.event_id = ae.event_id
      AND sa.alert_type = 'REPEATED_UNAUTHORIZED_ACCESS'
);
GO


/* Scenario 2 */

INSERT INTO security_alerts
(
    event_id,
    user_id,
    alert_type,
    severity,
    risk_score,
    description,
    status,
    created_at
)
SELECT
    ae.event_id,
    ae.user_id,
    'UNMANAGED_DEVICE_ACCESS',
    'HIGH',
    ae.risk_score,
    'Protected resource access was detected from an unmanaged or non-compliant device.',
    'OPEN',
    ae.event_timestamp
FROM access_events ae
INNER JOIN user_devices ud
    ON ae.device_id = ud.device_id
WHERE ae.reason = 'TEST_SCENARIO_02_UNMANAGED_DEVICE_ACCESS'
  AND (ud.managed = 0 OR ud.compliant = 0)
  AND NOT EXISTS
(
    SELECT 1
    FROM security_alerts sa
    WHERE sa.event_id = ae.event_id
      AND sa.alert_type = 'UNMANAGED_DEVICE_ACCESS'
);
GO


/* Scenario 3 */

INSERT INTO security_alerts
(
    event_id,
    user_id,
    alert_type,
    severity,
    risk_score,
    description,
    status,
    created_at
)
SELECT
    ae.event_id,
    ae.user_id,
    'PRIVILEGED_ACTION',
    'HIGH',
    ae.risk_score,
    'A privileged administrative action was performed against security configuration.',
    'OPEN',
    ae.event_timestamp
FROM access_events ae
WHERE ae.reason = 'TEST_SCENARIO_03_PRIVILEGED_SECURITY_ACTION'
  AND NOT EXISTS
(
    SELECT 1
    FROM security_alerts sa
    WHERE sa.event_id = ae.event_id
      AND sa.alert_type = 'PRIVILEGED_ACTION'
);
GO


/* Scenario 4 */

INSERT INTO security_alerts
(
    event_id,
    user_id,
    alert_type,
    severity,
    risk_score,
    description,
    status,
    created_at
)
SELECT
    ae.event_id,
    ae.user_id,
    'IMPOSSIBLE_LOCATION_LOGIN',
    'CRITICAL',
    ae.risk_score,
    'The same account authenticated from geographically inconsistent locations within a short time period.',
    'OPEN',
    ae.event_timestamp
FROM access_events ae
WHERE ae.reason LIKE 'TEST_SCENARIO_04_SUSPICIOUS_LOGIN_LOCATION%'
  AND NOT EXISTS
(
    SELECT 1
    FROM security_alerts sa
    WHERE sa.event_id = ae.event_id
      AND sa.alert_type = 'IMPOSSIBLE_LOCATION_LOGIN'
);
GO


/* Scenario 5 */

INSERT INTO security_alerts
(
    event_id,
    user_id,
    alert_type,
    severity,
    risk_score,
    description,
    status,
    created_at
)
SELECT
    ae.event_id,
    ae.user_id,
    'AFTER_HOURS_CRITICAL_ACCESS',
    'HIGH',
    ae.risk_score,
    'Access to a critical resource occurred during an unusual time window.',
    'OPEN',
    ae.event_timestamp
FROM access_events ae
WHERE ae.reason = 'TEST_SCENARIO_05_AFTER_HOURS_CRITICAL_ACCESS'
  AND NOT EXISTS
(
    SELECT 1
    FROM security_alerts sa
    WHERE sa.event_id = ae.event_id
      AND sa.alert_type = 'AFTER_HOURS_CRITICAL_ACCESS'
);
GO


/* Scenario 6 */

INSERT INTO security_alerts
(
    event_id,
    user_id,
    alert_type,
    severity,
    risk_score,
    description,
    status,
    created_at
)
SELECT
    ae.event_id,
    ae.user_id,
    'CROSS_DEPARTMENT_ACCESS',
    'CRITICAL',
    ae.risk_score,
    'A user attempted to access sensitive information belonging to another department.',
    'OPEN',
    ae.event_timestamp
FROM access_events ae
WHERE ae.reason = 'TEST_SCENARIO_06_CROSS_DEPARTMENT_RESTRICTED_ACCESS'
  AND NOT EXISTS
(
    SELECT 1
    FROM security_alerts sa
    WHERE sa.event_id = ae.event_id
      AND sa.alert_type = 'CROSS_DEPARTMENT_ACCESS'
);
GO


/* =========================================================
   UPDATE USER RISK SCORES
   ========================================================= */

UPDATE u
SET risk_score =
(
    SELECT ISNULL(MAX(sa.risk_score), 0)
    FROM security_alerts sa
    WHERE sa.user_id = u.user_id
      AND sa.status IN ('OPEN', 'INVESTIGATING')
)
FROM users u;
GO


/* =========================================================
   VALIDATION 1
   TEST EVENTS
   ========================================================= */

SELECT
    COUNT(*) AS test_scenario_events
FROM access_events
WHERE reason LIKE 'TEST_SCENARIO_%';
GO


/* =========================================================
   VALIDATION 2
   TEST SCENARIO DISTRIBUTION
   ========================================================= */

SELECT
    CASE
        WHEN reason LIKE 'TEST_SCENARIO_01%' THEN 'Scenario 01 - Repeated Unauthorized Access'
        WHEN reason LIKE 'TEST_SCENARIO_02%' THEN 'Scenario 02 - Unmanaged Device'
        WHEN reason LIKE 'TEST_SCENARIO_03%' THEN 'Scenario 03 - Privileged Action'
        WHEN reason LIKE 'TEST_SCENARIO_04%' THEN 'Scenario 04 - Suspicious Login'
        WHEN reason LIKE 'TEST_SCENARIO_05%' THEN 'Scenario 05 - After Hours Access'
        WHEN reason LIKE 'TEST_SCENARIO_06%' THEN 'Scenario 06 - Cross Department Access'
        ELSE 'Other'
    END AS scenario,
    COUNT(*) AS event_count
FROM access_events
WHERE reason LIKE 'TEST_SCENARIO_%'
GROUP BY
    CASE
        WHEN reason LIKE 'TEST_SCENARIO_01%' THEN 'Scenario 01 - Repeated Unauthorized Access'
        WHEN reason LIKE 'TEST_SCENARIO_02%' THEN 'Scenario 02 - Unmanaged Device'
        WHEN reason LIKE 'TEST_SCENARIO_03%' THEN 'Scenario 03 - Privileged Action'
        WHEN reason LIKE 'TEST_SCENARIO_04%' THEN 'Scenario 04 - Suspicious Login'
        WHEN reason LIKE 'TEST_SCENARIO_05%' THEN 'Scenario 05 - After Hours Access'
        WHEN reason LIKE 'TEST_SCENARIO_06%' THEN 'Scenario 06 - Cross Department Access'
        ELSE 'Other'
    END
ORDER BY scenario;
GO


/* =========================================================
   VALIDATION 3
   TEST ALERTS
   ========================================================= */

SELECT
    alert_type,
    severity,
    COUNT(*) AS alert_count
FROM security_alerts
WHERE alert_type IN
(
    'REPEATED_UNAUTHORIZED_ACCESS',
    'UNMANAGED_DEVICE_ACCESS',
    'PRIVILEGED_ACTION',
    'IMPOSSIBLE_LOCATION_LOGIN',
    'AFTER_HOURS_CRITICAL_ACCESS',
    'CROSS_DEPARTMENT_ACCESS'
)
GROUP BY
    alert_type,
    severity
ORDER BY
    severity,
    alert_type;
GO


/* =========================================================
   VALIDATION 4
   SHOW TEST ALERT DETAILS
   ========================================================= */

SELECT
    sa.alert_id,
    u.employee_code,
    u.full_name,
    sa.alert_type,
    sa.severity,
    sa.risk_score,
    sa.status,
    sa.description,
    sa.created_at
FROM security_alerts sa
INNER JOIN users u
    ON sa.user_id = u.user_id
WHERE sa.alert_type IN
(
    'REPEATED_UNAUTHORIZED_ACCESS',
    'UNMANAGED_DEVICE_ACCESS',
    'PRIVILEGED_ACTION',
    'IMPOSSIBLE_LOCATION_LOGIN',
    'AFTER_HOURS_CRITICAL_ACCESS',
    'CROSS_DEPARTMENT_ACCESS'
)
ORDER BY
    sa.created_at DESC;
GO