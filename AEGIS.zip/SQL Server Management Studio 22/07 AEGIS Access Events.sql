USE AEGIS_DB;
GO

/* ============================================================
   AEGIS - 07 ACCESS EVENTS
   ============================================================
   Synthetic security activity for AEGIS.

   60 users
   2 devices per user
   8 events per user
   Expected total = 480 events

   Event types used:
   LOGIN
   LOGOUT
   RESOURCE_ACCESS
   PASSWORD_CHANGE
   MFA_EVENT

   Results:
   ALLOW
   DENY
   ============================================================ */


/* ============================================================
   INSERT EVENTS
   ============================================================ */

;WITH UserBase AS
(
    SELECT
        u.user_id,
        u.employee_code,
        u.role_id,
        r.department_id,
        d.department_name
    FROM users u
    INNER JOIN roles r
        ON u.role_id = r.role_id
    INNER JOIN departments d
        ON r.department_id = d.department_id
),
UserDevices AS
(
    SELECT
        ub.user_id,
        ub.employee_code,
        ub.role_id,
        ub.department_id,
        ub.department_name,

        ud.device_id,
        ud.ip_address,
        ud.managed,
        ud.compliant,

        ROW_NUMBER() OVER
        (
            PARTITION BY ub.user_id
            ORDER BY ud.device_id
        ) AS device_no

    FROM UserBase ub
    INNER JOIN user_devices ud
        ON ub.user_id = ud.user_id
),
PrimaryDevice AS
(
    SELECT
        user_id,
        employee_code,
        role_id,
        department_id,
        department_name,
        device_id,
        ip_address,
        managed,
        compliant
    FROM UserDevices
    WHERE device_no = 1
),
AllowedResources AS
(
    SELECT
        pd.user_id,
        p.resource_id,

        p.can_view,
        p.can_create,
        p.can_edit,
        p.can_delete,
        p.can_admin,

        ROW_NUMBER() OVER
        (
            PARTITION BY pd.user_id
            ORDER BY p.resource_id
        ) AS rn

    FROM PrimaryDevice pd

    INNER JOIN permissions p
        ON pd.role_id = p.role_id

    WHERE
        p.can_view = 1
        OR p.can_create = 1
        OR p.can_edit = 1
        OR p.can_delete = 1
        OR p.can_admin = 1
),
DeniedResources AS
(
    SELECT
        pd.user_id,
        res.resource_id,

        ROW_NUMBER() OVER
        (
            PARTITION BY pd.user_id
            ORDER BY res.resource_id
        ) AS rn

    FROM PrimaryDevice pd

    INNER JOIN resources res
        ON res.department_id <> pd.department_id

    LEFT JOIN permissions p
        ON p.role_id = pd.role_id
        AND p.resource_id = res.resource_id

    WHERE p.permission_id IS NULL
),
EventsToInsert AS
(

    /* ========================================================
       EVENT 1 - LOGIN
       ======================================================== */

    SELECT
        pd.user_id,
        pd.device_id,
        pd.role_id,
        CAST(NULL AS INT) AS resource_id,

        'LOGIN' AS event_type,
        'LOGIN' AS [action],

        DATEADD
        (
            MINUTE,
            pd.user_id * 2,
            CAST('2026-08-30 08:00:00' AS DATETIME2)
        ) AS event_timestamp,

        'ALLOW' AS result,

        pd.ip_address AS source_ip,
        pd.department_name AS location,

        CASE
            WHEN pd.user_id % 7 = 0
                THEN 'PASSWORD'
            ELSE 'PASSWORD+MFA'
        END AS auth_method,

        'Mozilla/5.0 Windows NT 10.0' AS user_agent,

        CASE
            WHEN pd.user_id % 7 = 0 THEN 35
            WHEN pd.managed = 0 OR pd.compliant = 0 THEN 55
            ELSE 5
        END AS risk_score,

        'Normal user authentication' AS reason

    FROM PrimaryDevice pd


    UNION ALL


    /* ========================================================
       EVENT 2 - MFA
       ======================================================== */

    SELECT
        pd.user_id,
        pd.device_id,
        pd.role_id,
        CAST(NULL AS INT) AS resource_id,

        'MFA_EVENT' AS event_type,
        CAST(NULL AS VARCHAR(20)) AS [action],

        DATEADD
        (
            MINUTE,
            (pd.user_id * 2) + 1,
            CAST('2026-08-30 08:00:00' AS DATETIME2)
        ) AS event_timestamp,

        'ALLOW' AS result,

        pd.ip_address AS source_ip,
        pd.department_name AS location,

        'MFA' AS auth_method,

        'Mozilla/5.0 Windows NT 10.0' AS user_agent,

        CASE
            WHEN pd.user_id % 7 = 0 THEN 25
            ELSE 0
        END AS risk_score,

        'MFA authentication event' AS reason

    FROM PrimaryDevice pd


    UNION ALL


    /* ========================================================
       EVENT 3 - ALLOWED RESOURCE ACCESS
       ======================================================== */

    SELECT
        pd.user_id,
        pd.device_id,
        pd.role_id,
        ar.resource_id,

        'RESOURCE_ACCESS' AS event_type,

        CASE
            WHEN ar.can_delete = 1 THEN 'DELETE'
            WHEN ar.can_edit = 1 THEN 'EDIT'
            WHEN ar.can_create = 1 THEN 'CREATE'
            WHEN ar.can_admin = 1 THEN 'ADMIN'
            ELSE 'VIEW'
        END AS [action],

        DATEADD
        (
            MINUTE,
            (pd.user_id * 2) + 10,
            CAST('2026-08-30 08:00:00' AS DATETIME2)
        ) AS event_timestamp,

        'ALLOW' AS result,

        pd.ip_address AS source_ip,
        pd.department_name AS location,

        'SESSION' AS auth_method,

        'Mozilla/5.0 Windows NT 10.0' AS user_agent,

        CASE
            WHEN pd.managed = 0 OR pd.compliant = 0 THEN 45
            ELSE 5
        END AS risk_score,

        'Access permitted by assigned role' AS reason

    FROM PrimaryDevice pd

    INNER JOIN AllowedResources ar
        ON pd.user_id = ar.user_id
        AND ar.rn = 1


    UNION ALL


    /* ========================================================
       EVENT 4 - SECOND ALLOWED RESOURCE ACCESS
       ======================================================== */

    SELECT
        pd.user_id,
        pd.device_id,
        pd.role_id,
        ar.resource_id,

        'RESOURCE_ACCESS' AS event_type,

        CASE
            WHEN ar.can_delete = 1 THEN 'DELETE'
            WHEN ar.can_edit = 1 THEN 'EDIT'
            WHEN ar.can_create = 1 THEN 'CREATE'
            WHEN ar.can_admin = 1 THEN 'ADMIN'
            ELSE 'VIEW'
        END AS [action],

        DATEADD
        (
            MINUTE,
            (pd.user_id * 2) + 20,
            CAST('2026-08-30 08:00:00' AS DATETIME2)
        ) AS event_timestamp,

        'ALLOW' AS result,

        pd.ip_address AS source_ip,
        pd.department_name AS location,

        'SESSION' AS auth_method,

        'Mozilla/5.0 Windows NT 10.0' AS user_agent,

        CASE
            WHEN pd.managed = 0 OR pd.compliant = 0 THEN 50
            ELSE 5
        END AS risk_score,

        'Access permitted by assigned role' AS reason

    FROM PrimaryDevice pd

    INNER JOIN AllowedResources ar
        ON pd.user_id = ar.user_id
        AND ar.rn = 2


    UNION ALL


    /* ========================================================
       EVENT 5 - DENIED RESOURCE ACCESS
       ======================================================== */

    SELECT
        pd.user_id,
        pd.device_id,
        pd.role_id,
        dr.resource_id,

        'RESOURCE_ACCESS' AS event_type,
        'VIEW' AS [action],

        DATEADD
        (
            MINUTE,
            (pd.user_id * 2) + 30,
            CAST('2026-08-30 08:00:00' AS DATETIME2)
        ) AS event_timestamp,

        'DENY' AS result,

        pd.ip_address AS source_ip,
        pd.department_name AS location,

        'SESSION' AS auth_method,

        'Mozilla/5.0 Windows NT 10.0' AS user_agent,

        CASE
            WHEN pd.user_id % 5 = 0 THEN 75
            ELSE 60
        END AS risk_score,

        'Access denied: role has no permission for resource' AS reason

    FROM PrimaryDevice pd

    INNER JOIN DeniedResources dr
        ON pd.user_id = dr.user_id
        AND dr.rn = 1


    UNION ALL


    /* ========================================================
       EVENT 6 - SECOND DENIED RESOURCE ACCESS
       ======================================================== */

    SELECT
        pd.user_id,
        pd.device_id,
        pd.role_id,
        dr.resource_id,

        'RESOURCE_ACCESS' AS event_type,
        'VIEW' AS [action],

        DATEADD
        (
            MINUTE,
            (pd.user_id * 2) + 35,
            CAST('2026-08-30 08:00:00' AS DATETIME2)
        ) AS event_timestamp,

        'DENY' AS result,

        pd.ip_address AS source_ip,
        pd.department_name AS location,

        'SESSION' AS auth_method,

        'Mozilla/5.0 Windows NT 10.0' AS user_agent,

        CASE
            WHEN pd.user_id % 5 = 0 THEN 85
            ELSE 65
        END AS risk_score,

        'Repeated cross-department access attempt denied' AS reason

    FROM PrimaryDevice pd

    INNER JOIN DeniedResources dr
        ON pd.user_id = dr.user_id
        AND dr.rn = 2


    UNION ALL


    /* ========================================================
       EVENT 7 - PASSWORD CHANGE
       ======================================================== */

    SELECT
        pd.user_id,
        pd.device_id,
        pd.role_id,
        CAST(NULL AS INT) AS resource_id,

        'PASSWORD_CHANGE' AS event_type,
        CAST(NULL AS VARCHAR(20)) AS [action],

        DATEADD
        (
            MINUTE,
            (pd.user_id * 2) + 40,
            CAST('2026-08-30 08:00:00' AS DATETIME2)
        ) AS event_timestamp,

        'ALLOW' AS result,

        pd.ip_address AS source_ip,
        pd.department_name AS location,

        'AUTHENTICATED_SESSION' AS auth_method,

        'Mozilla/5.0 Windows NT 10.0' AS user_agent,

        5 AS risk_score,

        'User password changed successfully' AS reason

    FROM PrimaryDevice pd


    UNION ALL


    /* ========================================================
       EVENT 8 - LOGOUT
       ======================================================== */

    SELECT
        pd.user_id,
        pd.device_id,
        pd.role_id,
        CAST(NULL AS INT) AS resource_id,

        'LOGOUT' AS event_type,
        'LOGOUT' AS [action],

        DATEADD
        (
            MINUTE,
            (pd.user_id * 2) + 60,
            CAST('2026-08-30 08:00:00' AS DATETIME2)
        ) AS event_timestamp,

        'ALLOW' AS result,

        pd.ip_address AS source_ip,
        pd.department_name AS location,

        'SESSION' AS auth_method,

        'Mozilla/5.0 Windows NT 10.0' AS user_agent,

        0 AS risk_score,

        'Normal user logout' AS reason

    FROM PrimaryDevice pd
)


/* ============================================================
   INSERT INTO ACCESS_EVENTS
   ============================================================ */

INSERT INTO access_events
(
    user_id,
    device_id,
    role_id,
    resource_id,
    event_type,
    [action],
    event_timestamp,
    result,
    source_ip,
    location,
    auth_method,
    user_agent,
    risk_score,
    reason
)
SELECT
    e.user_id,
    e.device_id,
    e.role_id,
    e.resource_id,
    e.event_type,
    e.[action],
    e.event_timestamp,
    e.result,
    e.source_ip,
    e.location,
    e.auth_method,
    e.user_agent,
    e.risk_score,
    e.reason

FROM EventsToInsert e

WHERE NOT EXISTS
(
    SELECT 1
    FROM access_events ae
    WHERE ae.user_id = e.user_id
      AND ae.event_timestamp = e.event_timestamp
      AND ae.event_type = e.event_type
);
GO


/* ============================================================
   VALIDATION 1 - TOTAL EVENTS
   ============================================================ */

SELECT
    COUNT(*) AS Total_Access_Events
FROM access_events;
GO


/* ============================================================
   VALIDATION 2 - EVENTS BY TYPE
   ============================================================ */

SELECT
    event_type,
    COUNT(*) AS Event_Count
FROM access_events
GROUP BY event_type
ORDER BY event_type;
GO


/* ============================================================
   VALIDATION 3 - ALLOW VS DENY
   ============================================================ */

SELECT
    result,
    COUNT(*) AS Event_Count
FROM access_events
GROUP BY result
ORDER BY result;
GO


/* ============================================================
   VALIDATION 4 - HIGH RISK EVENTS
   ============================================================ */

SELECT
    ae.event_id,
    u.employee_code,
    u.full_name,
    r.role_name,
    ae.event_type,
    ae.[action],
    ae.result,
    ae.risk_score,
    ae.source_ip,
    ae.reason,
    ae.event_timestamp
FROM access_events ae

INNER JOIN users u
    ON ae.user_id = u.user_id

INNER JOIN roles r
    ON ae.role_id = r.role_id

WHERE ae.risk_score >= 60

ORDER BY
    ae.risk_score DESC,
    ae.event_timestamp;
GO