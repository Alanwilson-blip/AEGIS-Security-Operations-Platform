USE AEGIS_DB;
GO

-- STEP 1: Add 9 synthetic events for Elliot Ward (user_id = 24)
INSERT INTO access_events
(
    user_id,
    device_id,
    role_id,
    resource_id,
    event_type,
    [action],
    event_timestamp,
    result,
    source_ip,
    location,
    auth_method,
    user_agent,
    risk_score,
    reason
)
SELECT
    ae.user_id,
    ae.device_id,
    ae.role_id,
    ae.resource_id,
    ae.event_type,
    ae.[action],
    DATEADD(
        MINUTE,
        ROW_NUMBER() OVER (ORDER BY ae.event_id) * 5,
        CAST(CAST(GETDATE() AS DATE) AS DATETIME2)
    ),
    ae.result,
    ae.source_ip,
    ae.location,
    ae.auth_method,
    ae.user_agent,
    0,
    'Synthetic current-day activity for AEGIS testing'
FROM
(
    SELECT TOP (9)
        *
    FROM access_events
    WHERE user_id = 24
    ORDER BY event_id
) ae;

PRINT 'STEP 1 COMPLETE - Today''s events inserted.';
GO


-- STEP 2: Verify today's events
SELECT
    event_id,
    user_id,
    event_timestamp,
    result,
    [action],
    risk_score,
    reason
FROM access_events
WHERE user_id = 24
  AND event_timestamp >= CAST(GETDATE() AS DATE)
ORDER BY event_timestamp;
GO