USE AEGIS_DB;
GO

/* =========================================================
   AEGIS - 60 ROLES
   Departments already inserted
   SQL Server / SSMS 2022
   ========================================================= */

INSERT INTO roles
(
    department_id,
    role_name,
    description
)
SELECT
    d.department_id,
    v.role_name,
    v.description
FROM departments d
INNER JOIN
(
    VALUES

    -- Engineering & Development
    ('Engineering & Development', 'Software Engineer',
     'Develops and maintains software applications and engineering systems.'),
    ('Engineering & Development', 'Senior Software Engineer',
     'Senior engineering role responsible for complex development and technical contributions.'),
    ('Engineering & Development', 'Cloud Engineer',
     'Designs and manages cloud development infrastructure and services.'),
    ('Engineering & Development', 'DevOps Engineer',
     'Manages development operations, CI/CD pipelines, environments, and deployment workflows.'),
    ('Engineering & Development', 'Engineering Manager',
     'Leads engineering teams, projects, technical planning, and engineering operations.'),

    -- Research & Data Science
    ('Research & Data Science', 'Data Scientist',
     'Analyzes data and develops data-driven models, experiments, and insights.'),
    ('Research & Data Science', 'Research Scientist',
     'Conducts research, experiments, and scientific analysis.'),
    ('Research & Data Science', 'Machine Learning Engineer',
     'Develops, manages, and deploys machine learning systems and models.'),
    ('Research & Data Science', 'Data Engineer',
     'Builds and maintains data pipelines, processing systems, and data infrastructure.'),
    ('Research & Data Science', 'Research Manager',
     'Leads research teams, projects, experiments, and research operations.'),

    -- Product & Program Management
    ('Product & Program Management', 'Product Manager',
     'Manages product strategy, requirements, roadmaps, and product priorities.'),
    ('Product & Program Management', 'Program Manager',
     'Coordinates programs, project plans, schedules, and cross-functional delivery.'),
    ('Product & Program Management', 'Technical Program Manager',
     'Manages technically complex programs and coordinates engineering and product activities.'),
    ('Product & Program Management', 'Product Operations Specialist',
     'Supports product operations, analytics, planning, and release coordination.'),
    ('Product & Program Management', 'Group Product Manager',
     'Leads multiple product areas and provides broader product strategy and management.'),

    -- Sales & Marketing
    ('Sales & Marketing', 'Sales Specialist',
     'Handles sales activities, opportunities, and customer-facing commercial tasks.'),
    ('Sales & Marketing', 'Account Manager',
     'Manages customer accounts, sales opportunities, and customer relationships.'),
    ('Sales & Marketing', 'Marketing Specialist',
     'Manages marketing campaigns, content, and marketing activities.'),
    ('Sales & Marketing', 'Sales Operations Analyst',
     'Analyzes sales operations, customer analytics, and sales reporting.'),
    ('Sales & Marketing', 'Sales & Marketing Manager',
     'Manages sales and marketing teams, activities, reporting, and strategy.'),

    -- Customer Support
    ('Customer Support', 'Support Representative',
     'Handles customer support requests, tickets, feedback, and escalations.'),
    ('Customer Support', 'Technical Support Engineer',
     'Provides technical troubleshooting and advanced customer support.'),
    ('Customer Support', 'Customer Success Specialist',
     'Supports customer relationships, success activities, and customer feedback.'),
    ('Customer Support', 'Support Operations Analyst',
     'Analyzes support operations, support metrics, and operational data.'),
    ('Customer Support', 'Customer Support Manager',
     'Leads customer support teams, escalations, analytics, and support operations.'),

    -- Operations
    ('Operations', 'Operations Specialist',
     'Performs operational activities and manages operational records and workflows.'),
    ('Operations', 'Operations Analyst',
     'Analyzes operational processes, workflows, reports, and performance data.'),
    ('Operations', 'Process Coordinator',
     'Coordinates business processes, workflows, vendors, and operational activities.'),
    ('Operations', 'Operations Supervisor',
     'Supervises operational teams, workflows, records, and processes.'),
    ('Operations', 'Operations Manager',
     'Manages organizational operations, processes, workflows, vendors, and reporting.'),

    -- Finance
    ('Finance', 'Finance Analyst',
     'Analyzes financial records, budgets, expenses, and financial information.'),
    ('Finance', 'Accountant',
     'Maintains accounting records, expenses, financial transactions, and reporting.'),
    ('Finance', 'Financial Planning Analyst',
     'Handles financial planning, forecasting, budgeting, and financial analysis.'),
    ('Finance', 'Finance Supervisor',
     'Supervises finance operations, accounting, budgets, expenses, and reporting.'),
    ('Finance', 'Finance Manager',
     'Manages financial operations, budgets, forecasts, reporting, and financial controls.'),

    -- Human Resources
    ('Human Resources', 'HR Specialist',
     'Handles employee records, HR operations, performance, and HR reporting.'),
    ('Human Resources', 'Recruiter',
     'Manages recruitment activities, candidate records, and hiring processes.'),
    ('Human Resources', 'Employee Relations Specialist',
     'Handles employee relations, performance matters, and related HR activities.'),
    ('Human Resources', 'HR Supervisor',
     'Supervises HR operations, employee records, recruitment, and HR processes.'),
    ('Human Resources', 'HR Manager',
     'Manages HR operations, employee records, recruitment, performance, and compensation.'),

    -- Legal
    ('Legal', 'Legal Assistant',
     'Supports legal teams with documents, contracts, compliance, and assigned case records.'),
    ('Legal', 'Legal Analyst',
     'Analyzes legal documents, contracts, compliance information, and assigned cases.'),
    ('Legal', 'Corporate Counsel',
     'Provides corporate legal advice and manages legal matters and cases.'),
    ('Legal', 'Legal Operations Specialist',
     'Supports legal operations, compliance, contracts, reporting, and legal processes.'),
    ('Legal', 'Legal Manager',
     'Manages legal operations, legal matters, compliance, contracts, and reporting.'),

    -- IT
    ('IT', 'IT Support Specialist',
     'Provides technical support for users, devices, tickets, and IT documentation.'),
    ('IT', 'Systems Administrator',
     'Administers systems, devices, user accounts, configurations, and IT infrastructure.'),
    ('IT', 'Network Administrator',
     'Manages network resources, network configurations, and connectivity.'),
    ('IT', 'IT Security Administrator',
     'Manages technical IT security controls, user access, devices, and configurations.'),
    ('IT', 'IT Manager',
     'Manages IT operations, infrastructure, devices, systems, and IT teams.'),

    -- Security
    ('Security', 'Security Analyst',
     'Analyzes security events, incidents, investigations, policies, and security activity.'),
    ('Security', 'SOC Analyst',
     'Monitors security operations, events, incidents, and threat intelligence.'),
    ('Security', 'Security Engineer',
     'Designs and manages security technologies, configurations, and security infrastructure.'),
    ('Security', 'Incident Response Specialist',
     'Investigates and responds to security incidents and security investigations.'),
    ('Security', 'Security Manager',
     'Manages security operations, incidents, investigations, policies, and security controls.'),

    -- Administration
    ('Administration', 'Administrative Assistant',
     'Supports administrative activities, records, requests, and office operations.'),
    ('Administration', 'Administrative Specialist',
     'Performs administrative operations, records management, reporting, and internal requests.'),
    ('Administration', 'Office Coordinator',
     'Coordinates office information, administrative requests, and office operations.'),
    ('Administration', 'Administrative Supervisor',
     'Supervises administrative operations, office activities, records, and requests.'),
    ('Administration', 'Administration Manager',
     'Manages administrative operations, organizational records, reporting, and configuration.')

) AS v(department_name, role_name, description)
ON d.department_name = v.department_name
WHERE NOT EXISTS
(
    SELECT 1
    FROM roles r
    WHERE r.department_id = d.department_id
      AND r.role_name = v.role_name
);
GO


/* =========================================================
   VALIDATION
   ========================================================= */

SELECT COUNT(*) AS Total_Departments
FROM departments;
GO

SELECT COUNT(*) AS Total_Roles
FROM roles;
GO

SELECT
    d.department_id,
    d.department_name,
    COUNT(r.role_id) AS Role_Count
FROM departments d
LEFT JOIN roles r
    ON d.department_id = r.department_id
GROUP BY
    d.department_id,
    d.department_name
ORDER BY
    d.department_id;
GO