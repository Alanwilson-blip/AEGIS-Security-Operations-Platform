USE AEGIS_DB;
GO

/* =========================================================
   AEGIS - STEP 09
   AUDIT LOGS
   SQL SERVER / SSMS 2022
   =========================================================

   Purpose:
   Creates realistic synthetic audit records for:
   - User administration
   - Role changes
   - Permission changes
   - Device management
   - Security alert handling
   - Resource/configuration changes

   No tables are created or altered.
   ========================================================= */


/* =========================================================
   1. USER ACCOUNT AUDIT EVENTS
   ========================================================= */

INSERT INTO audit_logs
(
    actor_user_id,
    audit_action,
    target_type,
    target_id,
    old_value,
    new_value,
    event_timestamp
)
SELECT
    u.user_id,
    'USER_ACCOUNT_REVIEWED',
    'USER',
    u.user_id,
    'Status=' + u.status,
    'Account reviewed by administrator',
    DATEADD(DAY, -((u.user_id % 15)), SYSDATETIME())
FROM users u
WHERE NOT EXISTS
(
    SELECT 1
    FROM audit_logs al
    WHERE al.audit_action = 'USER_ACCOUNT_REVIEWED'
      AND al.target_type = 'USER'
      AND al.target_id = u.user_id
);
GO


/* =========================================================
   2. ROLE ASSIGNMENT AUDIT EVENTS
   ========================================================= */

INSERT INTO audit_logs
(
    actor_user_id,
    audit_action,
    target_type,
    target_id,
    old_value,
    new_value,
    event_timestamp
)
SELECT
    u.user_id,
    'ROLE_ASSIGNMENT_REVIEWED',
    'USER',
    u.user_id,
    'Previous role assignment',
    'Role ID=' + CAST(u.role_id AS VARCHAR(20)),
    DATEADD(DAY, -((u.user_id % 20)), SYSDATETIME())
FROM users u
WHERE NOT EXISTS
(
    SELECT 1
    FROM audit_logs al
    WHERE al.audit_action = 'ROLE_ASSIGNMENT_REVIEWED'
      AND al.target_type = 'USER'
      AND al.target_id = u.user_id
);
GO


/* =========================================================
   3. DEVICE MANAGEMENT AUDIT EVENTS
   ========================================================= */

INSERT INTO audit_logs
(
    actor_user_id,
    audit_action,
    target_type,
    target_id,
    old_value,
    new_value,
    event_timestamp
)
SELECT
    ud.user_id,
    'DEVICE_REVIEWED',
    'DEVICE',
    ud.device_id,
    'Managed=' + CAST(ud.managed AS VARCHAR(1))
        + ', Compliant=' + CAST(ud.compliant AS VARCHAR(1)),
    'Device security status reviewed',
    DATEADD(DAY, -((ud.device_id % 10)), SYSDATETIME())
FROM user_devices ud
WHERE NOT EXISTS
(
    SELECT 1
    FROM audit_logs al
    WHERE al.audit_action = 'DEVICE_REVIEWED'
      AND al.target_type = 'DEVICE'
      AND al.target_id = ud.device_id
);
GO


/* =========================================================
   4. PERMISSION REVIEW AUDIT EVENTS
   ========================================================= */

INSERT INTO audit_logs
(
    actor_user_id,
    audit_action,
    target_type,
    target_id,
    old_value,
    new_value,
    event_timestamp
)
SELECT
    r_user.user_id,
    'PERMISSION_REVIEWED',
    'PERMISSION',
    p.permission_id,

    'V=' + CAST(p.can_view AS VARCHAR(1))
    + ', C=' + CAST(p.can_create AS VARCHAR(1))
    + ', E=' + CAST(p.can_edit AS VARCHAR(1))
    + ', D=' + CAST(p.can_delete AS VARCHAR(1))
    + ', A=' + CAST(p.can_admin AS VARCHAR(1)),

    'Permission reviewed according to least-privilege policy',

    DATEADD(DAY, -((p.permission_id % 25)), SYSDATETIME())

FROM permissions p

CROSS APPLY
(
    SELECT TOP 1
        u.user_id
    FROM users u
    INNER JOIN roles r
        ON u.role_id = r.role_id
    WHERE r.role_id = p.role_id
    ORDER BY u.user_id
) r_user

WHERE NOT EXISTS
(
    SELECT 1
    FROM audit_logs al
    WHERE al.audit_action = 'PERMISSION_REVIEWED'
      AND al.target_type = 'PERMISSION'
      AND al.target_id = p.permission_id
);
GO


/* =========================================================
   5. SECURITY ALERT REVIEW EVENTS
   ========================================================= */

INSERT INTO audit_logs
(
    actor_user_id,
    audit_action,
    target_type,
    target_id,
    old_value,
    new_value,
    event_timestamp
)
SELECT
    sa.user_id,
    'SECURITY_ALERT_REVIEWED',
    'SECURITY_ALERT',
    sa.alert_id,
    'Status=' + sa.status,
    'Alert reviewed by security personnel',
    DATEADD(HOUR, 1, sa.created_at)
FROM security_alerts sa
WHERE NOT EXISTS
(
    SELECT 1
    FROM audit_logs al
    WHERE al.audit_action = 'SECURITY_ALERT_REVIEWED'
      AND al.target_type = 'SECURITY_ALERT'
      AND al.target_id = sa.alert_id
);
GO


/* =========================================================
   6. HIGH-RISK ALERT INVESTIGATION EVENTS
   ========================================================= */

INSERT INTO audit_logs
(
    actor_user_id,
    audit_action,
    target_type,
    target_id,
    old_value,
    new_value,
    event_timestamp
)
SELECT
    sa.user_id,
    'HIGH_RISK_ALERT_FLAGGED',
    'SECURITY_ALERT',
    sa.alert_id,
    'Risk score=' + CAST(sa.risk_score AS VARCHAR(10)),
    'Escalated for security investigation',
    DATEADD(HOUR, 2, sa.created_at)
FROM security_alerts sa
WHERE sa.severity IN ('HIGH', 'CRITICAL')
  AND NOT EXISTS
(
    SELECT 1
    FROM audit_logs al
    WHERE al.audit_action = 'HIGH_RISK_ALERT_FLAGGED'
      AND al.target_type = 'SECURITY_ALERT'
      AND al.target_id = sa.alert_id
);
GO


/* =========================================================
   7. ACCESS CONTROL REVIEW EVENTS
   ========================================================= */

INSERT INTO audit_logs
(
    actor_user_id,
    audit_action,
    target_type,
    target_id,
    old_value,
    new_value,
    event_timestamp
)
SELECT TOP 60
    u.user_id,
    'ACCESS_CONTROL_REVIEW',
    'ROLE',
    r.role_id,
    'Existing role permissions',
    'Role access reviewed for least privilege',
    DATEADD(DAY, -((r.role_id % 30)), SYSDATETIME())
FROM roles r
INNER JOIN users u
    ON u.role_id = r.role_id
WHERE NOT EXISTS
(
    SELECT 1
    FROM audit_logs al
    WHERE al.audit_action = 'ACCESS_CONTROL_REVIEW'
      AND al.target_type = 'ROLE'
      AND al.target_id = r.role_id
)
ORDER BY r.role_id;
GO


/* =========================================================
   8. RESOURCE SECURITY REVIEW EVENTS
   ========================================================= */

INSERT INTO audit_logs
(
    actor_user_id,
    audit_action,
    target_type,
    target_id,
    old_value,
    new_value,
    event_timestamp
)
SELECT
    u.user_id,
    'RESOURCE_SECURITY_REVIEW',
    'RESOURCE',
    res.resource_id,
    'Sensitivity=' + res.sensitivity,
    'Resource security classification reviewed',
    DATEADD(DAY, -((res.resource_id % 30)), SYSDATETIME())
FROM resources res
CROSS APPLY
(
    SELECT TOP 1
        u2.user_id
    FROM users u2
    INNER JOIN roles r2
        ON u2.role_id = r2.role_id
    WHERE r2.department_id = res.department_id
    ORDER BY u2.user_id
) u
WHERE NOT EXISTS
(
    SELECT 1
    FROM audit_logs al
    WHERE al.audit_action = 'RESOURCE_SECURITY_REVIEW'
      AND al.target_type = 'RESOURCE'
      AND al.target_id = res.resource_id
);
GO


/* =========================================================
   9. PRIVILEGED ACCESS REVIEW EVENTS
   ========================================================= */

INSERT INTO audit_logs
(
    actor_user_id,
    audit_action,
    target_type,
    target_id,
    old_value,
    new_value,
    event_timestamp
)
SELECT
    u.user_id,
    'PRIVILEGED_ACCESS_REVIEW',
    'PERMISSION',
    p.permission_id,
    'Admin=' + CAST(p.can_admin AS VARCHAR(1)),
    'Privileged permission reviewed and audited',
    DATEADD(DAY, -((p.permission_id % 14)), SYSDATETIME())
FROM permissions p
INNER JOIN roles r
    ON p.role_id = r.role_id
CROSS APPLY
(
    SELECT TOP 1
        u2.user_id
    FROM users u2
    WHERE u2.role_id = r.role_id
    ORDER BY u2.user_id
) u
WHERE p.can_admin = 1
  AND NOT EXISTS
(
    SELECT 1
    FROM audit_logs al
    WHERE al.audit_action = 'PRIVILEGED_ACCESS_REVIEW'
      AND al.target_type = 'PERMISSION'
      AND al.target_id = p.permission_id
);
GO


/* =========================================================
   10. VALIDATION - TOTAL AUDIT LOGS
   ========================================================= */

SELECT
    COUNT(*) AS total_audit_logs
FROM audit_logs;
GO


/* =========================================================
   11. VALIDATION - AUDIT ACTION DISTRIBUTION
   ========================================================= */

SELECT
    audit_action,
    COUNT(*) AS log_count
FROM audit_logs
GROUP BY audit_action
ORDER BY log_count DESC;
GO


/* =========================================================
   12. RECENT AUDIT ACTIVITY
   ========================================================= */

SELECT TOP 50
    al.audit_id,
    u.employee_code,
    u.full_name,
    al.audit_action,
    al.target_type,
    al.target_id,
    al.old_value,
    al.new_value,
    al.event_timestamp
FROM audit_logs al
LEFT JOIN users u
    ON al.actor_user_id = u.user_id
ORDER BY al.event_timestamp DESC;
GO