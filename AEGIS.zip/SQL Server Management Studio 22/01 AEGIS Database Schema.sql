USE AEGIS_DB;
GO

/* =========================================================
   AEGIS DATABASE SCHEMA
   SQL Server Version
   ========================================================= */


/* =========================================================
   1. DEPARTMENTS
   ========================================================= */

CREATE TABLE departments (
    department_id INT IDENTITY(1,1) PRIMARY KEY,
    department_name VARCHAR(100) NOT NULL UNIQUE,
    description VARCHAR(500) NULL
);
GO


/* =========================================================
   2. ROLES
   ========================================================= */

CREATE TABLE roles (
    role_id INT IDENTITY(1,1) PRIMARY KEY,
    department_id INT NOT NULL,
    role_name VARCHAR(100) NOT NULL,
    description VARCHAR(500) NULL,

    CONSTRAINT FK_roles_departments
        FOREIGN KEY (department_id)
        REFERENCES departments(department_id),

    CONSTRAINT UQ_roles_department_role
        UNIQUE (department_id, role_name)
);
GO


/* =========================================================
   3. USERS
   ========================================================= */

CREATE TABLE users (
    user_id INT IDENTITY(1,1) PRIMARY KEY,

    employee_code VARCHAR(30) NOT NULL UNIQUE,

    full_name VARCHAR(150) NOT NULL,

    email VARCHAR(200) NOT NULL UNIQUE,

    role_id INT NOT NULL,

    manager_id INT NULL,

    status VARCHAR(20) NOT NULL
        CONSTRAINT CK_users_status
        CHECK (status IN ('ACTIVE', 'INACTIVE', 'SUSPENDED')),

    location VARCHAR(100) NULL,

    join_date DATE NULL,

    mfa_enabled BIT NOT NULL DEFAULT 0,

    risk_score INT NOT NULL DEFAULT 0
        CONSTRAINT CK_users_risk_score
        CHECK (risk_score BETWEEN 0 AND 100),

    CONSTRAINT FK_users_roles
        FOREIGN KEY (role_id)
        REFERENCES roles(role_id),

    CONSTRAINT FK_users_manager
        FOREIGN KEY (manager_id)
        REFERENCES users(user_id)
);
GO


/* =========================================================
   4. USER DEVICES
   ========================================================= */

CREATE TABLE user_devices (
    device_id INT IDENTITY(1,1) PRIMARY KEY,

    user_id INT NOT NULL,

    device_name VARCHAR(100) NOT NULL,

    device_type VARCHAR(50) NULL,

    operating_system VARCHAR(100) NULL,

    ip_address VARCHAR(45) NULL,

    managed BIT NOT NULL DEFAULT 0,

    compliant BIT NOT NULL DEFAULT 0,

    last_seen DATETIME2 NULL,

    CONSTRAINT FK_user_devices_users
        FOREIGN KEY (user_id)
        REFERENCES users(user_id)
);
GO


/* =========================================================
   5. RESOURCES
   ========================================================= */

CREATE TABLE resources (
    resource_id INT IDENTITY(1,1) PRIMARY KEY,

    resource_name VARCHAR(150) NOT NULL,

    department_id INT NOT NULL,

    resource_type VARCHAR(50) NULL,

    sensitivity VARCHAR(20) NOT NULL
        CONSTRAINT CK_resources_sensitivity
        CHECK (
            sensitivity IN
            ('PUBLIC',
             'INTERNAL',
             'CONFIDENTIAL',
             'RESTRICTED',
             'CRITICAL')
        ),

    description VARCHAR(500) NULL,

    CONSTRAINT FK_resources_departments
        FOREIGN KEY (department_id)
        REFERENCES departments(department_id),

    CONSTRAINT UQ_resources_department_resource
        UNIQUE (department_id, resource_name)
);
GO


/* =========================================================
   6. PERMISSIONS
   ========================================================= */

CREATE TABLE permissions (
    permission_id INT IDENTITY(1,1) PRIMARY KEY,

    role_id INT NOT NULL,

    resource_id INT NOT NULL,

    can_view BIT NOT NULL DEFAULT 0,

    can_create BIT NOT NULL DEFAULT 0,

    can_edit BIT NOT NULL DEFAULT 0,

    can_delete BIT NOT NULL DEFAULT 0,

    can_admin BIT NOT NULL DEFAULT 0,

    CONSTRAINT FK_permissions_roles
        FOREIGN KEY (role_id)
        REFERENCES roles(role_id),

    CONSTRAINT FK_permissions_resources
        FOREIGN KEY (resource_id)
        REFERENCES resources(resource_id),

    CONSTRAINT UQ_permissions_role_resource
        UNIQUE (role_id, resource_id)
);
GO


/* =========================================================
   7. ACCESS EVENTS
   ========================================================= */

CREATE TABLE access_events (
    event_id BIGINT IDENTITY(1,1) PRIMARY KEY,

    user_id INT NOT NULL,

    device_id INT NULL,

    role_id INT NOT NULL,

    resource_id INT NULL,

    event_type VARCHAR(30) NOT NULL
        CONSTRAINT CK_access_events_event_type
        CHECK (
            event_type IN
            ('LOGIN',
             'LOGOUT',
             'RESOURCE_ACCESS',
             'PASSWORD_CHANGE',
             'MFA_EVENT')
        ),

    [action] VARCHAR(20) NULL
        CONSTRAINT CK_access_events_action
        CHECK (
            [action] IN
            ('VIEW',
             'CREATE',
             'EDIT',
             'DELETE',
             'ADMIN',
             'LOGIN',
             'LOGOUT')
        ),

    event_timestamp DATETIME2 NOT NULL DEFAULT SYSDATETIME(),

    result VARCHAR(10) NOT NULL
        CONSTRAINT CK_access_events_result
        CHECK (result IN ('ALLOW', 'DENY')),

    source_ip VARCHAR(45) NULL,

    location VARCHAR(100) NULL,

    auth_method VARCHAR(50) NULL,

    user_agent VARCHAR(500) NULL,

    risk_score INT NOT NULL DEFAULT 0
        CONSTRAINT CK_access_events_risk_score
        CHECK (risk_score BETWEEN 0 AND 100),

    reason VARCHAR(500) NULL,

    CONSTRAINT FK_access_events_users
        FOREIGN KEY (user_id)
        REFERENCES users(user_id),

    CONSTRAINT FK_access_events_devices
        FOREIGN KEY (device_id)
        REFERENCES user_devices(device_id),

    CONSTRAINT FK_access_events_roles
        FOREIGN KEY (role_id)
        REFERENCES roles(role_id),

    CONSTRAINT FK_access_events_resources
        FOREIGN KEY (resource_id)
        REFERENCES resources(resource_id)
);
GO


/* =========================================================
   8. SECURITY ALERTS
   ========================================================= */

CREATE TABLE security_alerts (
    alert_id BIGINT IDENTITY(1,1) PRIMARY KEY,

    event_id BIGINT NULL,

    user_id INT NOT NULL,

    alert_type VARCHAR(100) NOT NULL,

    severity VARCHAR(20) NOT NULL
        CONSTRAINT CK_security_alerts_severity
        CHECK (
            severity IN
            ('LOW',
             'MEDIUM',
             'HIGH',
             'CRITICAL')
        ),

    risk_score INT NOT NULL DEFAULT 0
        CONSTRAINT CK_security_alerts_risk_score
        CHECK (risk_score BETWEEN 0 AND 100),

    description VARCHAR(1000) NULL,

    status VARCHAR(30) NOT NULL DEFAULT 'OPEN'
        CONSTRAINT CK_security_alerts_status
        CHECK (
            status IN
            ('OPEN',
             'INVESTIGATING',
             'RESOLVED',
             'FALSE_POSITIVE')
        ),

    created_at DATETIME2 NOT NULL DEFAULT SYSDATETIME(),

    resolved_at DATETIME2 NULL,

    CONSTRAINT FK_security_alerts_events
        FOREIGN KEY (event_id)
        REFERENCES access_events(event_id),

    CONSTRAINT FK_security_alerts_users
        FOREIGN KEY (user_id)
        REFERENCES users(user_id)
);
GO


/* =========================================================
   9. AUDIT LOGS
   ========================================================= */

CREATE TABLE audit_logs (
    audit_id BIGINT IDENTITY(1,1) PRIMARY KEY,

    actor_user_id INT NULL,

    audit_action VARCHAR(100) NOT NULL,

    target_type VARCHAR(100) NULL,

    target_id VARCHAR(100) NULL,

    old_value VARCHAR(MAX) NULL,

    new_value VARCHAR(MAX) NULL,

    event_timestamp DATETIME2 NOT NULL DEFAULT SYSDATETIME(),

    reason VARCHAR(500) NULL,

    CONSTRAINT FK_audit_logs_users
        FOREIGN KEY (actor_user_id)
        REFERENCES users(user_id)
);
GO


/* =========================================================
   INDEXES
   ========================================================= */

CREATE INDEX IX_roles_department
ON roles(department_id);
GO

CREATE INDEX IX_users_role
ON users(role_id);
GO

CREATE INDEX IX_users_manager
ON users(manager_id);
GO

CREATE INDEX IX_user_devices_user
ON user_devices(user_id);
GO

CREATE INDEX IX_resources_department
ON resources(department_id);
GO

CREATE INDEX IX_permissions_role
ON permissions(role_id);
GO

CREATE INDEX IX_permissions_resource
ON permissions(resource_id);
GO

CREATE INDEX IX_access_events_user
ON access_events(user_id);
GO

CREATE INDEX IX_access_events_resource
ON access_events(resource_id);
GO

CREATE INDEX IX_access_events_timestamp
ON access_events(event_timestamp);
GO

CREATE INDEX IX_access_events_result
ON access_events(result);
GO

CREATE INDEX IX_access_events_type
ON access_events(event_type);
GO

CREATE INDEX IX_security_alerts_user
ON security_alerts(user_id);
GO

CREATE INDEX IX_security_alerts_status
ON security_alerts(status);
GO

CREATE INDEX IX_security_alerts_severity
ON security_alerts(severity);
GO

CREATE INDEX IX_audit_logs_timestamp
ON audit_logs(event_timestamp);
GO


/* =========================================================
   VERIFICATION
   ========================================================= */

SELECT
    TABLE_NAME
FROM INFORMATION_SCHEMA.TABLES
WHERE TABLE_TYPE = 'BASE TABLE'
ORDER BY TABLE_NAME;
GO

