CREATE TABLE user_work_schedules (
    schedule_id INT IDENTITY(1,1) PRIMARY KEY,
    user_id INT NOT NULL,
    work_start TIME NOT NULL,
    work_end TIME NOT NULL,
    night_shift BIT NOT NULL DEFAULT 0,

    CONSTRAINT FK_work_schedule_user
        FOREIGN KEY (user_id)
        REFERENCES users(user_id)
);

CREATE TABLE user_work_authorizations (
    authorization_id INT IDENTITY(1,1) PRIMARY KEY,
    user_id INT NOT NULL,
    authorization_type VARCHAR(30) NOT NULL,
    start_time DATETIME2 NOT NULL,
    end_time DATETIME2 NOT NULL,
    location VARCHAR(100) NULL,
    reason VARCHAR(255) NULL,

    CONSTRAINT FK_work_authorization_user
        FOREIGN KEY (user_id)
        REFERENCES users(user_id)
);