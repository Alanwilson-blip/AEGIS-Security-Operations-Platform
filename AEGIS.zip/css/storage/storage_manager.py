import sqlite3
import os
import json
from datetime import datetime

STORAGE_FOLDER = "storage"
DATABASE_FILE = os.path.join(
    STORAGE_FOLDER,
    "security_log.db"
)

ACCOUNTS_FILE = os.path.join(
    STORAGE_FOLDER,
    "accounts.json"
)

INCIDENTS_FILE = os.path.join(
    STORAGE_FOLDER,
    "incidents.json"
)

INVESTIGATION_HISTORY_FILE = os.path.join(
    STORAGE_FOLDER,
    "investigation_history.json"
)

DECISION_LOG_FILE = os.path.join(
    STORAGE_FOLDER,
    "decision_log.json"
)
def get_connection():


    return sqlite3.connect(DATABASE_FILE)
    
def initialize_storage():
    if not os.path.exists(STORAGE_FOLDER):
        os.makedirs(STORAGE_FOLDER)

    connection = get_connection()
    cursor = connection.cursor()

    cursor.execute("""
    
    CREATE TABLE IF NOT EXISTS accounts (
    username TEXT PRIMARY KEY,
    failed_attempts INTEGER DEFAULT 0,
    login_history TEXT,
    known_devices TEXT,
    pending_devices TEXT,
    blocked_devices TEXT,
    known_countries TEXT

)
""")
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS incidents (

    incident_id TEXT PRIMARY KEY,

    username TEXT,

    event TEXT,

    timestamp TEXT,

    ip_address TEXT,

    country TEXT,

    device TEXT,

    browser TEXT,

    vpn TEXT,

    risk_score INTEGER,

    severity TEXT,

    recommended_actions TEXT,

    status TEXT,

    resolution_notes TEXT

)
""")
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS investigation_history (

          history_id INTEGER PRIMARY KEY AUTOINCREMENT,

          incident_id TEXT,

          username TEXT,

          device TEXT,

          administrator TEXT,

          decision TEXT,

          decision_time TEXT,

          risk_score INTEGER,

          severity TEXT,

          countries TEXT,

          browsers TEXT,

          vpn_history TEXT,

          recommended_actions TEXT

)
""")
    cursor.execute("""
CREATE TABLE IF NOT EXISTS decision_log (

    decision_id INTEGER PRIMARY KEY AUTOINCREMENT,

    incident_id TEXT,

    username TEXT,

    device TEXT,

    decision TEXT,

    administrator TEXT,

    decision_time TEXT

)
""")

    connection.commit()
    connection.close()
def load_data(file_name, default_data):

    if not os.path.exists(file_name):

        return default_data

    with open(file_name, "r") as file:

        return json.load(file)
def save_data(file_name, data):

    with open(file_name, "w") as file:

        json.dump(
            data,
            file,
            indent=4,
            default=str
        )
def save_accounts(accounts):
    

    connection = get_connection()

    cursor = connection.cursor()

    cursor.execute("DELETE FROM accounts")

    for username, data in accounts.items():

        cursor.execute("""
       INSERT INTO accounts (
              username,
             failed_attempts,
             login_history,
             known_devices,
             pending_devices,
             blocked_devices,
             known_countries
)
        VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (

            username,

            data["failed_attempts"],

            json.dumps(
            data["login_history"],
            default=str
        ),

            json.dumps(
            data["known_devices"],
            default=str
        ),
            json.dumps(
            data["pending_devices"], 
            default=str 
        ),

            json.dumps(
            data["blocked_devices"], 
            default=str 
        ),

            json.dumps(
            list(data["known_countries"])
        ),

        ))

    connection.commit()

    connection.close()
def save_incidents(incidents):
    
    connection = get_connection()

    cursor = connection.cursor()

    cursor.execute("DELETE FROM incidents")
    
    for incident in incidents:

     cursor.execute("""
        INSERT INTO incidents (

           incident_id,
           username,
            event,
           timestamp,
           ip_address,
           country,
           device,
            browser,
            vpn,
           risk_score,
           severity,
           recommended_actions,
           status,
            resolution_notes

         )
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
         """,(
                     
        incident["incident_id"],

        incident["username"],

        incident["event"],

        incident["timestamp"],

        incident["ip_address"],

        incident["country"],

        incident["device"],

        incident["browser"],

        incident["vpn"],

        incident["risk_score"],

        incident["severity"],

        json.dumps(
            incident["recommended_actions"]
        ),

        incident["status"],

        incident["resolution_notes"]

    ))
    connection.commit()

    connection.close()
def save_investigation_history(investigation_history):

    connection = get_connection()

    cursor = connection.cursor()

    cursor.execute("DELETE FROM investigation_history")

    for investigation in investigation_history:

        cursor.execute("""
        INSERT INTO investigation_history (

            incident_id,
            username,
            device,
            administrator,
            decision,
            decision_time,
            risk_score,
            severity,
            countries,
            browsers,
            vpn_history,
            recommended_actions

        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (

            investigation["incident_id"],

            investigation["username"],

            investigation["device"],

            investigation["administrator"],

            investigation["decision"],

            investigation["decision_time"],

            investigation["risk_score"],

            investigation["severity"],

            json.dumps(investigation["countries"]),

            json.dumps(investigation["browsers"]),

            json.dumps(investigation["vpn_history"]),

            json.dumps(investigation["recommended_actions"])

        ))

    connection.commit()

    connection.close()

def save_decision_log(decision_log):

    connection = get_connection()

    cursor = connection.cursor()

    cursor.execute("DELETE FROM decision_log")

    for decision in decision_log:

        cursor.execute("""
        INSERT INTO decision_log (

            incident_id,
            username,
            device,
            decision,
            administrator,
            decision_time

        )
        VALUES (?, ?, ?, ?, ?, ?)
        """, (

            decision["incident_id"],
            decision["username"],
            decision["device"],
            decision["decision"],
            decision["administrator"],
            decision["decision_time"]

        ))

    connection.commit()

    connection.close()
def save_all(
    accounts,
    incidents,
    investigation_history,
    decision_log
):
    
    save_accounts(accounts)

    save_incidents(incidents)

    save_investigation_history(
       investigation_history
)

    save_decision_log(decision_log)

def load_accounts():

    connection = get_connection()

    cursor = connection.cursor()
    

    cursor.execute("""
    SELECT
     username,
    failed_attempts,
    login_history,
    known_devices,
    pending_devices,
    blocked_devices,
    known_countries
FROM accounts
""")

    rows = cursor.fetchall()

    connection.close()

    accounts = {}

    for row in rows:

        username = row[0]
        login_history = json.loads(row[2]) if row[2] else []

        for login in login_history:
          login["timestamp"] = datetime.strptime(
          login["timestamp"],
          "%Y-%m-%d %H:%M:%S"
    )

        accounts[username] = {

             "failed_attempts": row[1],

             "login_history": login_history,

             "known_devices": json.loads(row[3]) if row[3] else {},

             "pending_devices": json.loads(row[4]) if row[4] else {},

             "blocked_devices": json.loads(row[5]) if row[5] else {},

             "known_countries": set(
             json.loads(row[6]) if row[6] else []
             )
        }
    return accounts  

def load_incidents():

    connection = get_connection()

    cursor = connection.cursor()

    cursor.execute("""
    SELECT

        incident_id,
        username,
        event,
        timestamp,
        ip_address,
        country,
        device,
        browser,
        vpn,
        risk_score,
        severity,
        recommended_actions,
        status,
        resolution_notes

    FROM incidents
    """)
    rows = cursor.fetchall()

    connection.close()

    incidents = [] 

    for row in rows:

       incidents.append({

        "incident_id": row[0],

        "username": row[1],

        "event": row[2],

        "timestamp": row[3],

        "ip_address": row[4],

        "country": row[5],

        "device": row[6],

        "browser": row[7],

        "vpn": row[8],

        "risk_score": row[9],

        "severity": row[10],

        "recommended_actions": json.loads(row[11]),

        "status": row[12],

        "resolution_notes": row[13]

    })

    return incidents

def load_investigation_history():

    connection = get_connection()

    cursor = connection.cursor()

    cursor.execute("""
        SELECT
            incident_id,
            username,
            device,
            administrator,
            decision,
            decision_time,
            risk_score,
            severity,
            countries,
            browsers,
            vpn_history,
            recommended_actions
        FROM investigation_history
    """)

    rows = cursor.fetchall()

    connection.close()

    investigation_history = []

    for row in rows:

        investigation_history.append({

            "incident_id": row[0],
            "username": row[1],
            "device": row[2],
            "administrator": row[3],
            "decision": row[4],
            "decision_time": row[5],
            "risk_score": row[6],
            "severity": row[7],
            "countries": json.loads(row[8]),
            "browsers": json.loads(row[9]),
            "vpn_history": json.loads(row[10]),
            "recommended_actions": json.loads(row[11])

        })

    return investigation_history
    
def load_all():

   accounts = load_accounts()

   incidents = load_incidents()

   investigation_history = load_investigation_history()

   decision_log = load_decision_log()

   return accounts, incidents, investigation_history, decision_log

def load_decision_log():

    connection = get_connection()

    cursor = connection.cursor()

    cursor.execute("""
        SELECT
            incident_id,
            username,
            device,
            decision,
            administrator,
            decision_time
        FROM decision_log
    """)

    rows = cursor.fetchall()

    connection.close()

    decision_log = []

    for row in rows:

        decision_log.append({

            "incident_id": row[0],
            "username": row[1],
            "device": row[2],
            "decision": row[3],
            "administrator": row[4],
            "decision_time": row[5]

        })

    return decision_log