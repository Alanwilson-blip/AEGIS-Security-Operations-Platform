
from concurrent.futures import ThreadPoolExecutor

from database import get_connection
from notification_service import send_security_alert_email
from storage.storage_manager import get_setting


# =========================================================
# AEGIS BACKGROUND EMAIL WORKER
# =========================================================

_email_executor = ThreadPoolExecutor(
    max_workers=2,
    thread_name_prefix="aegis-email"
)


def _send_security_alert_email_background(
    recipient_email,
    employee_name,
    alert_id,
    severity,
    risk_score,
    description
):
    """Send an alert email without blocking event processing."""

    try:
        send_security_alert_email(
            recipient_email=recipient_email,
            employee_name=employee_name,
            alert_id=alert_id,
            severity=severity,
            risk_score=risk_score,
            description=description
        )

        print(
            f"Security alert email sent for alert #{alert_id}."
        )

    except Exception as email_error:
        print(
            f"Security alert email failed for alert #{alert_id}:",
            str(email_error)
        )

# =========================================================
# AEGIS DETECTION ENGINE
# D01 - D14
# =========================================================

BRUTE_FORCE_WINDOW = 120

D01_POINTS = 40


def detect_d01_brute_force(user_id, event_timestamp):

    connection = get_connection()
    cursor = connection.cursor()

    try:

        cursor.execute("""
            SELECT COUNT(*)
            FROM access_events
            WHERE user_id = ?
              AND event_type = 'LOGIN'
              AND result = 'DENY'
              AND event_timestamp >= DATEADD(
                    SECOND,
                    -?,
                    ?
              )
              AND event_timestamp <= ?
        """, (
            user_id,
            BRUTE_FORCE_WINDOW,
            event_timestamp,
            event_timestamp
        ))

        failed_count = cursor.fetchone()[0]

        detected = failed_count >= 4

        return {
            "detected": detected,
            "points": D01_POINTS if detected else 0,
            "failed_count": failed_count,
            "detection": "BRUTE_FORCE"
        }

    finally:

        cursor.close()
        connection.close()

#D2

D02_POINTS = 20


def detect_d02_unknown_device(user_id, device_id):
    connection = get_connection()
    cursor = connection.cursor()

    try:
        cursor.execute("""
            SELECT COUNT(*)
            FROM user_devices
            WHERE user_id = ?
              AND device_id = ?
        """, (
            user_id,
            device_id
        ))

        device_count = cursor.fetchone()[0]

        detected = device_count == 0

        return {
            "detected": detected,
            "points": D02_POINTS if detected else 0,
            "device_known": not detected,
            "detection": "UNKNOWN_DEVICE"
        }

    finally:
        cursor.close()
        connection.close()


#D3
D03_POINTS = 30


def detect_d03_unknown_country(user_id, event_location):
    connection = get_connection()
    cursor = connection.cursor()

    try:
        cursor.execute("""
            SELECT location
            FROM users
            WHERE user_id = ?
        """, (user_id,))

        row = cursor.fetchone()

        if not row:
            return {
                "detected": False,
                "points": 0,
                "detection": "UNKNOWN_COUNTRY",
                "reason": "USER_NOT_FOUND"
            }

        authorized_location = row.location

        if not event_location:
            detected = True
        elif event_location.strip().lower() == "unknown":
            detected = True
        else:
            event_city = event_location.split(",")[0].strip().lower()
            authorized_city = authorized_location.strip().lower()

            detected = event_city != authorized_city

        return {
            "detected": detected,
            "points": D03_POINTS if detected else 0,
            "detection": "UNKNOWN_COUNTRY",
            "authorized_location": authorized_location,
            "event_location": event_location
        }

    finally:
        cursor.close()
        connection.close()
#D4

IMPOSSIBLE_TRAVEL_WINDOW = 7200
D04_POINTS = 50


def detect_d04_impossible_travel(user_id, event_timestamp, current_location):
    connection = get_connection()
    cursor = connection.cursor()

    try:
        cursor.execute("""
            SELECT TOP 1
                event_timestamp,
                location
            FROM access_events
            WHERE user_id = ?
              AND event_type = 'LOGIN'
              AND result IN ('SUCCESS', 'ALLOW')
              AND event_timestamp < ?
            ORDER BY event_timestamp DESC
        """, (
            user_id,
            event_timestamp
        ))

        previous = cursor.fetchone()

        if not previous:
            return {
                "detected": False,
                "points": 0,
                "detection": "IMPOSSIBLE_LOCATION_LOGIN",
                "reason": "NO_PREVIOUS_SUCCESSFUL_LOGIN"
            }

        previous_timestamp = previous.event_timestamp
        previous_location = previous.location

        elapsed_seconds = (
            event_timestamp - previous_timestamp
        ).total_seconds()

        if elapsed_seconds > IMPOSSIBLE_TRAVEL_WINDOW:
            return {
                "detected": False,
                "points": 0,
                "detection": "IMPOSSIBLE_LOCATION_LOGIN",
                "reason": "OUTSIDE_TIME_WINDOW"
            }

        if not previous_location or not current_location:
            return {
                "detected": False,
                "points": 0,
                "detection": "IMPOSSIBLE_LOCATION_LOGIN",
                "reason": "LOCATION_UNKNOWN"
            }

        previous_city = previous_location.split(",")[0].strip().lower()
        current_city = current_location.split(",")[0].strip().lower()

        detected = (
            previous_city != current_city
            and previous_city != "unknown"
            and current_city != "unknown"
        )

        return {
            "detected": detected,
            "points": D04_POINTS if detected else 0,
            "detection": "IMPOSSIBLE_LOCATION_LOGIN",
            "previous_location": previous_location,
            "current_location": current_location,
            "elapsed_seconds": elapsed_seconds
        }

    finally:
        cursor.close()
        connection.close()

#D5

D05_POINTS = 25


def detect_d05_vpn_anomaly(device_id, current_vpn_state):
    connection = get_connection()
    cursor = connection.cursor()

    try:
        cursor.execute("""
            SELECT TOP 1
                vpn_enabled,
                observed_at
            FROM device_vpn_history
            WHERE device_id = ?
            ORDER BY observed_at DESC
        """, (device_id,))

        row = cursor.fetchone()

        if not row:
            return {
                "detected": False,
                "points": 0,
                "previous_vpn": None,
                "current_vpn": bool(current_vpn_state),
                "detection": "VPN_ANOMALY"
            }

        previous_vpn = bool(row.vpn_enabled)
        current_vpn = bool(current_vpn_state)

        detected = previous_vpn != current_vpn

        return {
            "detected": detected,
            "points": D05_POINTS if detected else 0,
            "previous_vpn": previous_vpn,
            "current_vpn": current_vpn,
            "detection": "VPN_ANOMALY"
        }

    finally:
        cursor.close()
        connection.close()

#D6
D06_POINTS = 30


def detect_d06_unauthorized_access(
    user_id,
    role_id,
    resource_id,
    action
):
    connection = get_connection()
    cursor = connection.cursor()

    try:
        cursor.execute("""
            SELECT
                can_view,
                can_create,
                can_edit,
                can_delete,
                can_admin
            FROM permissions
            WHERE role_id = ?
              AND resource_id = ?
        """, (
            role_id,
            resource_id
        ))

        row = cursor.fetchone()

        # No permission record = unauthorized
        if not row:
            return {
                "detected": True,
                "points": D06_POINTS,
                "authorized": False,
                "action": action,
                "detection": "UNAUTHORIZED_ACCESS"
            }

        action_permission = {
            "VIEW": row.can_view,
            "CREATE": row.can_create,
            "EDIT": row.can_edit,
            "DELETE": row.can_delete,
            "ADMIN": row.can_admin
        }

        allowed = action_permission.get(
            str(action).strip().upper(),
            False
        )

        detected = not bool(allowed)

        return {
            "detected": detected,
            "points": D06_POINTS if detected else 0,
            "authorized": not detected,
            "action": action,
            "detection": "UNAUTHORIZED_ACCESS"
        }

    finally:
        cursor.close()
        connection.close()

#D7
D07_POINTS = 40
D07_WINDOW = 86400
D07_THRESHOLD = 4


def detect_d07_repeated_unauthorized_access(
    
    user_id,
    current_timestamp

):
    connection = get_connection()
    cursor = connection.cursor()

    try:
        cursor.execute("""
    SELECT
        event_id,
        event_timestamp
    FROM access_events
    WHERE user_id = ?
        AND result = 'DENY'
        AND event_type = 'RESOURCE_ACCESS'
        AND event_timestamp <= ?
    ORDER BY event_timestamp DESC
""", (
    user_id,
    current_timestamp
))

        rows = cursor.fetchall()

        repeated_count = 0

        for row in rows:
            elapsed_seconds = abs(
               (current_timestamp - row.event_timestamp).total_seconds()
    )

            if elapsed_seconds <= D07_WINDOW:
              repeated_count += 1
            else:
             break

        detected = repeated_count >= D07_THRESHOLD

        return {
            "detected": detected,
            "points": D07_POINTS if detected else 0,
            "repeated_count": repeated_count,
            "threshold": D07_THRESHOLD,
            "window_seconds": D07_WINDOW,
            "detection": "REPEATED_UNAUTHORIZED_ACCESS"
        }

    finally:
        cursor.close()
        connection.close()

# D08 — CROSS-DEPARTMENT ACCESS

D08_POINTS = 20


def detect_d08_cross_department_access(
    user_id,
    resource_id,
    action,
    result
):
    connection = get_connection()
    cursor = connection.cursor()

    try:
        cursor.execute("""
            SELECT
                d1.department_id AS employee_department_id,
                d1.department_name AS employee_department,
                d2.department_id AS resource_department_id,
                d2.department_name AS resource_department
            FROM users u
            JOIN roles ro
                ON u.role_id = ro.role_id
            JOIN departments d1
                ON ro.department_id = d1.department_id
            JOIN resources r
                ON r.resource_id = ?
            JOIN departments d2
                ON r.department_id = d2.department_id
            WHERE u.user_id = ?
        """, (
            resource_id,
            user_id
        ))

        row = cursor.fetchone()

        if not row:
            return {
                "detected": False,
                "points": 0,
                "cross_department": False,
                "detection": "CROSS_DEPARTMENT_ACCESS"
            }

        cross_department = (
            row.employee_department_id
            != row.resource_department_id
        )

        unauthorized = (
            str(result).strip().upper() == "DENY"
        )

        detected = cross_department and unauthorized

        return {
            "detected": detected,
            "points": D08_POINTS if detected else 0,
            "cross_department": cross_department,
            "employee_department": row.employee_department,
            "resource_department": row.resource_department,
            "action": action,
            "result": result,
            "detection": "CROSS_DEPARTMENT_ACCESS"
        }

    finally:
        cursor.close()
        connection.close()


# D09 — SENSITIVE RESOURCE ACCESS

D09_POINTS = 20


def detect_d09_sensitive_resource_access(
    resource_id,
    action,
    result
):
    connection = get_connection()
    cursor = connection.cursor()

    try:
        cursor.execute("""
            SELECT
                resource_name,
                sensitivity
            FROM resources
            WHERE resource_id = ?
        """, (
            resource_id
        ))

        row = cursor.fetchone()

        if not row:
            return {
                "detected": False,
                "points": 0,
                "sensitive": False,
                "resource_name": None,
                "sensitivity": None,
                "detection": "SENSITIVE_RESOURCE_ACCESS"
            }

        sensitivity = (
            str(row.sensitivity).strip().upper()
            if row.sensitivity is not None
            else ""
        )

        sensitive = sensitivity in (
            "RESTRICTED",
            "CONFIDENTIAL",
            "HIGH",
            "CRITICAL"
        )

        detected = sensitive

        return {
            "detected": detected,
            "points": D09_POINTS if detected else 0,
            "sensitive": sensitive,
            "resource_name": row.resource_name,
            "sensitivity": row.sensitivity,
            "action": action,
            "result": result,
            "detection": "SENSITIVE_RESOURCE_ACCESS"
        }

    finally:
        cursor.close()
        connection.close()
# D10 — PRIVILEGED ACTION

D10_POINTS = 25


def detect_d10_privileged_action(
    action,
    resource_id
):
    connection = get_connection()
    cursor = connection.cursor()

    try:
        cursor.execute("""
            SELECT
                resource_name
            FROM resources
            WHERE resource_id = ?
        """, (
            resource_id
        ))

        row = cursor.fetchone()

        if not row:
            return {
                "detected": False,
                "points": 0,
                "privileged": False,
                "resource_name": None,
                "detection": "PRIVILEGED_ACTION"
            }

        normalized_action = str(action).strip().upper()

        privileged = (
            normalized_action == "ADMIN"
        )

        detected = privileged

        return {
            "detected": detected,
            "points": D10_POINTS if detected else 0,
            "privileged": privileged,
            "resource_name": row.resource_name,
            "action": action,
            "detection": "PRIVILEGED_ACTION"
        }

    finally:
        cursor.close()
        connection.close()

# D11 — AFTER-HOURS ACCESS

D11_POINTS = 15


def detect_d11_after_hours_access(
    user_id,
    event_timestamp
):
    connection = get_connection()
    cursor = connection.cursor()

    try:
        cursor.execute("""
            SELECT
                work_start,
                work_end,
                night_shift
            FROM user_work_schedules
            WHERE user_id = ?
        """, (
            user_id
        ))

        row = cursor.fetchone()

        if not row:
            return {
                "detected": False,
                "points": 0,
                "after_hours": False,
                "reason": "NO_WORK_SCHEDULE",
                "detection": "AFTER_HOURS_ACCESS"
            }

        event_time = event_timestamp.time()
        work_start = row.work_start
        work_end = row.work_end
        night_shift = bool(row.night_shift)

        if night_shift:
            if work_start <= work_end:
                within_schedule = (
                    work_start <= event_time <= work_end
                )
            else:
                within_schedule = (
                    event_time >= work_start
                    or event_time <= work_end
                )
        else:
            within_schedule = (
                work_start <= event_time <= work_end
            )

        after_hours = not within_schedule

        return {
            "detected": after_hours,
            "points": D11_POINTS if after_hours else 0,
            "after_hours": after_hours,
            "work_start": str(work_start),
            "work_end": str(work_end),
            "night_shift": night_shift,
            "event_time": str(event_time),
            "detection": "AFTER_HOURS_ACCESS"
        }

    finally:
        cursor.close()
        connection.close()

# D12 — NON-COMPLIANT DEVICE

D12_POINTS = 20


def detect_d12_non_compliant_device(
    device_id
):
    connection = get_connection()
    cursor = connection.cursor()

    try:
        cursor.execute("""
            SELECT
                device_name,
                managed,
                compliant
            FROM user_devices
            WHERE device_id = ?
        """, (
            device_id
        ))

        row = cursor.fetchone()

        if not row:
            return {
                "detected": False,
                "points": 0,
                "non_compliant": False,
                "device_name": None,
                "managed": None,
                "compliant": None,
                "detection": "NON_COMPLIANT_DEVICE"
            }

        non_compliant = not bool(row.compliant)

        return {
            "detected": non_compliant,
            "points": D12_POINTS if non_compliant else 0,
            "non_compliant": non_compliant,
            "device_name": row.device_name,
            "managed": bool(row.managed),
            "compliant": bool(row.compliant),
            "detection": "NON_COMPLIANT_DEVICE"
        }

    finally:
        cursor.close()
        connection.close()


# D13 — UNMANAGED / EXPIRED DEVICE AUTHORIZATION

D13_POINTS = 15


def detect_d13_device_authorization(
    user_id,
    device_id,
    event_timestamp
):
    connection = get_connection()
    cursor = connection.cursor()

    try:
        # Check whether the device is currently managed
        cursor.execute("""
            SELECT
                device_name,
                managed
            FROM user_devices
            WHERE device_id = ?
              AND user_id = ?
        """, (
            device_id,
            user_id
        ))

        device_row = cursor.fetchone()

        if not device_row:
            return {
                "detected": False,
                "points": 0,
                "authorized": False,
                "reason": "DEVICE_NOT_FOUND",
                "detection": "UNMANAGED_DEVICE"
            }

        # Managed company device does not require temporary authorization
        if bool(device_row.managed):
            return {
                "detected": False,
                "points": 0,
                "authorized": True,
                "reason": "MANAGED_DEVICE",
                "device_name": device_row.device_name,
                "detection": "UNMANAGED_DEVICE"
            }

        # Check for an active authorization at the event timestamp
        cursor.execute("""
            SELECT TOP 1
                authorization_type,
                start_time,
                end_time,
                location,
                reason
            FROM user_work_authorizations
            WHERE user_id = ?
  AND device_id = ?
  AND start_time <= ?
  AND end_time >= ?
            ORDER BY end_time DESC
        """, (
             user_id,
             device_id,
             event_timestamp,
             event_timestamp
))

        authorization = cursor.fetchone()

        if authorization:
            return {
                "detected": False,
                "points": 0,
                "authorized": True,
                "reason": "ACTIVE_AUTHORIZATION",
                "authorization_type": authorization.authorization_type,
                "start_time": authorization.start_time,
                "end_time": authorization.end_time,
                "detection": "UNMANAGED_DEVICE"
            }

        return {
            "detected": True,
            "points": D13_POINTS,
            "authorized": False,
            "reason": "NO_ACTIVE_AUTHORIZATION",
            "device_name": device_row.device_name,
            "detection": "UNMANAGED_DEVICE"
        }

    finally:
        cursor.close()
        connection.close()

# D14 — HIGH-RISK ACCESS

D14_HIGH_RISK_THRESHOLD = 60


def detect_d14_high_risk_access(risk_score):
    risk_score = max(0, min(int(risk_score), 100))

    if risk_score >= D14_HIGH_RISK_THRESHOLD:
        return {
            "detected": True,
            "risk_score": risk_score,
            "threshold": D14_HIGH_RISK_THRESHOLD,
            "account_action": "LOCK_ACCOUNT",
            "reason": "HIGH_RISK_ACCESS",
            "detection": "HIGH_RISK_ACCESS"
        }

    return {
        "detected": False,
        "risk_score": risk_score,
        "threshold": D14_HIGH_RISK_THRESHOLD,
        "account_action": "NO_ACTION",
        "reason": "RISK_BELOW_THRESHOLD",
        "detection": "HIGH_RISK_ACCESS"
    }

def determine_risk_response(risk_score):
    risk_score = max(0, min(int(risk_score), 100))

    if risk_score <= 29:
        return {
            "risk_score": risk_score,
            "severity": "LOW",
            "response": "RECORD_AND_MONITOR"
        }

    elif risk_score <= 59:
        return {
            "risk_score": risk_score,
            "severity": "MEDIUM",
            "response": "ALERT_AND_VERIFY"
        }

    elif risk_score <= 89:
        return {
            "risk_score": risk_score,
            "severity": "HIGH",
            "response": "ALERT_INCIDENT_AND_CONTAIN"
        }

    else:
        return {
            "risk_score": risk_score,
            "severity": "CRITICAL",
            "response": "ALERT_INCIDENT_AND_IMMEDIATE_CONTAINMENT"
        }

#Risk Score Aggregator
def aggregate_risk_score(detection_results):
    total_points = 0
    detections = []

    for result in detection_results:
        if result.get("detected") and result.get("points", 0) > 0:
            points = int(result["points"])
            total_points += points

            detections.append({
                "detection": result.get("detection"),
                "points": points
            })

    risk_score = min(total_points, 100)

    response = determine_risk_response(risk_score)

    return {
        "risk_score": risk_score,
        "severity": response["severity"],
        "response": response["response"],
        "detections": detections
    }

def run_d01_d13_detections(
    user_id,
    device_id,
    role_id,
    resource_id,
    event_type,
    action,
    event_timestamp,
    result,
    location,
    current_vpn_state
):
    detection_results = []

    # D01 — Brute Force
    detection_results.append(
        detect_d01_brute_force(
            user_id,
            event_timestamp
        )
    )

    # D02 — Unknown Device
    detection_results.append(
        detect_d02_unknown_device(
            user_id,
            device_id
        )
    )

    # D03 — Unknown Country
    detection_results.append(
        detect_d03_unknown_country(
            user_id,
            location
        )
    )

    # D04 — Impossible Location / Travel
    detection_results.append(
        detect_d04_impossible_travel(
            user_id,
            event_timestamp,
            location
        )
    )

    # D05 — VPN Anomaly
    detection_results.append(
        detect_d05_vpn_anomaly(
            device_id,
            current_vpn_state
        )
    )

    # D06 — Unauthorized Resource Access
    detection_results.append(
        detect_d06_unauthorized_access(
            user_id,
            role_id,
            resource_id,
            action
        )
    )

    # D07 — Repeated Unauthorized Access
    detection_results.append(
        detect_d07_repeated_unauthorized_access(
            user_id,
            event_timestamp
        )
    )

    # D08 — Cross-Department Access
    detection_results.append(
        detect_d08_cross_department_access(
            user_id,
            resource_id,
            action,
            result
        )
    )

    # D09 — Sensitive Resource Access
    detection_results.append(
        detect_d09_sensitive_resource_access(
            resource_id,
            action,
            result
        )
    )

    # D10 — Privileged Action
    detection_results.append(
        detect_d10_privileged_action(
            action,
            resource_id
        )
    )

    # D11 — After-Hours Access
    detection_results.append(
        detect_d11_after_hours_access(
            user_id,
            event_timestamp
        )
    )

    # D12 — Non-Compliant Device
    detection_results.append(
        detect_d12_non_compliant_device(
            device_id
        )
    )

    # D13 — Unmanaged / Expired Device Authorization
    detection_results.append(
        detect_d13_device_authorization(
            user_id,
            device_id,
            event_timestamp
        )
    )

    return detection_results

# =========================================================
# SECURITY ALERT CREATION
# =========================================================

def create_security_alert(
    event_id,
    user_id,
    aggregated_result,
    d14_result,
    notification_email=None
):
    risk_score = int(aggregated_result["risk_score"])
    severity = aggregated_result["severity"]

    # LOW risk is only recorded and monitored.
    if risk_score < 30:
        return {
            "created": False,
            "reason": "RISK_BELOW_ALERT_THRESHOLD",
            "alert_id": None,
            "notification_queued": False,
            "notification_error": None
        }

    connection = get_connection()
    cursor = connection.cursor()

    try:
        # -----------------------------------------
        # Get employee details
        # -----------------------------------------
        cursor.execute("""
            SELECT
                full_name,
                email
            FROM users
            WHERE user_id = ?
        """, (user_id,))

        user_row = cursor.fetchone()

        if not user_row:
            raise ValueError(
                f"User {user_id} not found."
            )

        employee_name = user_row.full_name
        employee_email = (
            notification_email
            or user_row.email
        )

        # -----------------------------------------
        # Detection details
        # -----------------------------------------
        detection_details = list(
            aggregated_result.get("detections", [])
        )

        # D14 is a threshold/enforcement detection.
        # It does NOT contribute points.
        if d14_result.get("detected"):
            detection_details.append({
                "detection": d14_result["detection"],
                "points": 0
            })

        detection_names = [
            item["detection"]
            for item in detection_details
        ]

        description = (
            "Security event detected. "
            "Triggered detections: "
            + ", ".join(detection_names)
            + "."
        )

        # -----------------------------------------
        # Create security alert
        # -----------------------------------------
        cursor.execute("""
            INSERT INTO security_alerts (
                event_id,
                user_id,
                alert_type,
                severity,
                risk_score,
                description,
                status,
                created_at
            )
            OUTPUT INSERTED.alert_id
            VALUES (?, ?, ?, ?, ?, ?, ?, GETDATE())
        """, (
            event_id,
            user_id,
            "SECURITY_EVENT",
            severity,
            risk_score,
            description,
            "OPEN"
        ))

        alert_id = cursor.fetchone()[0]

        # -----------------------------------------
        # Save detection details
        # -----------------------------------------
        for detection in detection_details:
            cursor.execute("""
                INSERT INTO security_alert_detections (
                    alert_id,
                    detection_type,
                    points
                )
                VALUES (?, ?, ?)
            """, (
                alert_id,
                detection["detection"],
                int(detection["points"])
            ))

        # -----------------------------------------
        # Commit the security alert first
        # -----------------------------------------
        connection.commit()

        # -----------------------------------------
        # Send employee notification
        # -----------------------------------------
        
        # -----------------------------------------
        # Queue employee notification in background
        # -----------------------------------------
        notification_queued = False
        notification_error = None

        security_alerts_enabled = (
           str(get_setting("security_alerts", "true"))
           .strip()
           .lower()
            in ("true", "1", "yes", "on")
        )

        if not security_alerts_enabled:
           notification_error = "SECURITY_ALERTS_DISABLED"

        elif employee_email:
            try:
                _email_executor.submit(
                    _send_security_alert_email_background,
                    recipient_email=employee_email,
                    employee_name=employee_name,
                    alert_id=alert_id,
                    severity=severity,
                    risk_score=risk_score,
                    description=description
                )

                notification_queued = True

            except Exception as email_error:
                notification_error = str(email_error)

                print(
                    "Security alert email queue failed:",
                    notification_error
                )

        else:
            notification_error = "EMPLOYEE_EMAIL_MISSING"

        # -----------------------------------------
        # Return result
        # -----------------------------------------
        return {
            "created": True,
            "alert_id": alert_id,
            "event_id": event_id,
            "user_id": user_id,
            "risk_score": risk_score,
            "severity": severity,
            "detection_count": len(detection_details),
            "notification_queued": notification_queued,
            "notification_error": notification_error
        }

    except Exception:
        connection.rollback()
        raise

    finally:
        cursor.close()
        connection.close()

def create_incident_from_alert(alert_id):
    connection = get_connection()
    cursor = connection.cursor()

    try:
        cursor.execute("""
            SELECT
                alert_id,
                user_id,
                alert_type,
                severity,
                risk_score,
                description
            FROM security_alerts
            WHERE alert_id = ?
        """, (alert_id,))

        alert = cursor.fetchone()

        if not alert:
            return {
                "created": False,
                "reason": "ALERT_NOT_FOUND",
                "incident_id": None
            }

        if int(alert.risk_score) < 60:
            return {
                "created": False,
                "reason": "RISK_BELOW_INCIDENT_THRESHOLD",
                "incident_id": None
            }

        cursor.execute("""
            SELECT incident_id
            FROM incidents
            WHERE source_alert_id = ?
        """, (alert.alert_id,))

        existing_incident = cursor.fetchone()

        if existing_incident:
            return {
                "created": False,
                "reason": "INCIDENT_ALREADY_EXISTS",
                "incident_id": existing_incident.incident_id
            }

        incident_type = "SECURITY_EVENT"

        title = (
            f"Security Incident — Alert #{alert.alert_id}"
        )

        description = (
            alert.description
            or "Security incident created from security alert."
        )

        cursor.execute("""
            INSERT INTO incidents (
                source_alert_id,
                user_id,
                incident_type,
                title,
                description,
                severity,
                risk_score,
                status,
                created_at,
                updated_at
            )
            OUTPUT INSERTED.incident_id
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, GETDATE(), GETDATE())
        """, (
            alert.alert_id,
            alert.user_id,
            incident_type,
            title,
            description,
            alert.severity,
            alert.risk_score,
            "INVESTIGATING"
        ))

        incident_id = cursor.fetchone()[0]

        connection.commit()

        return {
            "created": True,
            "incident_id": incident_id,
            "source_alert_id": alert.alert_id,
            "user_id": alert.user_id,
            "severity": alert.severity,
            "risk_score": alert.risk_score,
            "status": "INVESTIGATING"
        }

    except Exception:
        connection.rollback()
        raise

    finally:
        cursor.close()
        connection.close()

def create_investigation_from_incident(incident_id, actor_user_id=None):

    connection = get_connection()
    cursor = connection.cursor()

    try:
        # --------------------------------------------------------
        # Verify incident exists
        # --------------------------------------------------------
        cursor.execute("""
            SELECT
                incident_id,
                status
            FROM incidents
            WHERE incident_id = ?
        """, (incident_id,))

        incident = cursor.fetchone()

        if not incident:
            return {
                "created": False,
                "reason": "INCIDENT_NOT_FOUND",
                "investigation_id": None
            }

        # --------------------------------------------------------
        # Prevent duplicate investigation
        # --------------------------------------------------------
        cursor.execute("""
            SELECT
                investigation_id,
                status
            FROM investigations
            WHERE incident_id = ?
        """, (incident_id,))

        existing = cursor.fetchone()

        if existing:
            return {
                "created": False,
                "reason": "INVESTIGATION_ALREADY_EXISTS",
                "investigation_id": existing.investigation_id,
                "incident_id": incident_id,
                "assigned_to": None,
                "status": existing.status
            }

        # --------------------------------------------------------
        # Create investigation
        # --------------------------------------------------------
        cursor.execute("""
            INSERT INTO investigations (
                incident_id,
                assigned_to,
                status,
                decision,
                findings,
                started_at,
                updated_at,
                created_at
            )
            OUTPUT INSERTED.investigation_id
            VALUES (?, ?, ?, ?, ?, GETDATE(), GETDATE(), GETDATE())
        """, (
            incident_id,
            actor_user_id,
            "IN_PROGRESS",
            None,
            None
        ))

        investigation_id = cursor.fetchone()[0]

        # --------------------------------------------------------
        # Audit investigation creation
        # --------------------------------------------------------
        cursor.execute("""
            INSERT INTO audit_logs (
                actor_user_id,
                audit_action,
                target_type,
                target_id,
                old_value,
                new_value,
                event_timestamp,
                reason
            )
            VALUES (?, ?, ?, ?, ?, ?, GETDATE(), ?)
        """, (
            actor_user_id,
            "INVESTIGATION_STARTED",
            "INVESTIGATION",
            str(investigation_id),
            None,
            "IN_PROGRESS",
            "Investigation created from incident."
        ))

        connection.commit()

        return {
            "created": True,
            "investigation_id": investigation_id,
            "incident_id": incident_id,
            "assigned_to": actor_user_id,
            "status": "IN_PROGRESS"
        }

    except Exception:
        connection.rollback()
        raise

    finally:
        cursor.close()
        connection.close()

def record_investigation_action(
    investigation_id,
    actor_user_id,
    action_type,
    action_reason=None
):
    allowed_actions = {
        "BLOCK_CONTAIN",
        "CONFIRM_SUSPICIOUS_ACTIVITY",
        "FALSE_POSITIVE",
        "ALLOW_BENIGN_ACTIVITY",
        "CONTINUE_INVESTIGATION"
    }

    action_type = str(action_type).strip().upper()
    action_reason = (
        str(action_reason).strip()
        if action_reason is not None
        else ""
    )

    if action_type not in allowed_actions:
        return {
            "success": False,
            "reason": "INVALID_ACTION",
            "action_type": action_type
        }

    if action_type == "BLOCK_CONTAIN":
        return {
            "success": False,
            "reason": "CONTAINMENT_NOT_CONFIGURED",
            "message": (
                "Containment requires verified authorization "
                "and actual account-access enforcement."
            )
        }

    actions_requiring_reason = {
        "FALSE_POSITIVE",
        "ALLOW_BENIGN_ACTIVITY"
    }

    if (
        action_type in actions_requiring_reason
        and not action_reason
    ):
        return {
            "success": False,
            "reason": "ACTION_REASON_REQUIRED",
            "action_type": action_type
        }

    connection = get_connection()
    cursor = connection.cursor()

    try:
        # 1. Lock and retrieve the investigation.
        cursor.execute("""
            SELECT
                investigation_id,
                incident_id,
                status,
                decision
            FROM investigations WITH (UPDLOCK, HOLDLOCK)
            WHERE investigation_id = ?
        """, (investigation_id,))

        investigation = cursor.fetchone()

        if investigation is None:
            connection.rollback()
            return {
                "success": False,
                "reason": "INVESTIGATION_NOT_FOUND",
                "investigation_id": investigation_id
            }

        # 2. Reject ordinary actions on completed investigations.
        if investigation.status == "COMPLETED":
            connection.rollback()
            return {
                "success": False,
                "reason": "INVESTIGATION_ALREADY_COMPLETED",
                "investigation_id": investigation_id
            }

        # 3. Verify the actor exists and is active.
        cursor.execute("""
            SELECT user_id, status
            FROM users
            WHERE user_id = ?
        """, (actor_user_id,))

        actor = cursor.fetchone()

        if actor is None:
            connection.rollback()
            return {
                "success": False,
                "reason": "ACTOR_NOT_FOUND",
                "actor_user_id": actor_user_id
            }

        if actor.status != "ACTIVE":
            connection.rollback()
            return {
                "success": False,
                "reason": "ACTOR_NOT_ACTIVE",
                "actor_user_id": actor_user_id
            }

        # 4. Lock and retrieve the associated incident.
        cursor.execute("""
            SELECT incident_id, status
            FROM incidents WITH (UPDLOCK, HOLDLOCK)
            WHERE incident_id = ?
        """, (investigation.incident_id,))

        incident = cursor.fetchone()

        if incident is None:
            connection.rollback()
            return {
                "success": False,
                "reason": "INCIDENT_NOT_FOUND",
                "incident_id": investigation.incident_id
            }

        old_incident_status = incident.status

        # Do not silently reopen a resolved incident.
        if old_incident_status not in (
            "OPEN",
            "INVESTIGATING"
        ):
            connection.rollback()
            return {
                "success": False,
                "reason": "INCIDENT_NOT_ELIGIBLE",
                "incident_id": incident.incident_id,
                "incident_status": old_incident_status
            }

        # 5. Determine the new investigation and incident states.
        if action_type in (
            "FALSE_POSITIVE",
            "ALLOW_BENIGN_ACTIVITY"
        ):
            new_investigation_status = "COMPLETED"
            new_incident_status = "RESOLVED"
        else:
            new_investigation_status = "IN_PROGRESS"
            new_incident_status = "INVESTIGATING"

        # 6. Record the analyst's action.
        cursor.execute("""
            INSERT INTO investigation_actions (
                investigation_id,
                actor_user_id,
                action_type,
                action_reason,
                created_at
            )
            VALUES (?, ?, ?, ?, SYSDATETIME())
        """, (
            investigation_id,
            actor_user_id,
            action_type,
            action_reason or None
        ))

        # 7. Update the investigation.
        # Preserve the reason as findings when closing it.
        cursor.execute("""
            UPDATE investigations
            SET
                decision = ?,
                status = ?,
                findings = CASE
                    WHEN ? = 'COMPLETED' THEN ?
                    ELSE findings
                END,
                updated_at = SYSDATETIME(),
                completed_at = CASE
                    WHEN ? = 'COMPLETED'
                        THEN SYSDATETIME()
                    ELSE completed_at
                END
            WHERE investigation_id = ?
              AND status <> 'COMPLETED'
        """, (
            action_type,
            new_investigation_status,
            new_investigation_status,
            action_reason or None,
            new_investigation_status,
            investigation_id
        ))

        if cursor.rowcount != 1:
            raise RuntimeError(
                "Investigation status changed unexpectedly."
            )

        # 8. Update the incident status.
        if old_incident_status != new_incident_status:
            cursor.execute("""
                UPDATE incidents
                SET
                    status = ?,
                    updated_at = SYSDATETIME(),
                    resolved_at = CASE
                        WHEN ? = 'RESOLVED'
                            THEN SYSDATETIME()
                        ELSE NULL
                    END,
                    resolution_notes = CASE
                        WHEN ? = 'RESOLVED'
                            THEN ?
                        ELSE NULL
                    END
                WHERE incident_id = ?
                  AND status = ?
            """, (
                new_incident_status,
                new_incident_status,
                new_incident_status,
                action_reason or None,
                incident.incident_id,
                old_incident_status
            ))

            if cursor.rowcount != 1:
                raise RuntimeError(
                    "Incident status changed unexpectedly."
                )

            if cursor.rowcount != 1:
                raise RuntimeError(
                    "Incident status changed unexpectedly."
                )

            # Audit the incident status transition.
            cursor.execute("""
                INSERT INTO audit_logs (
                    actor_user_id,
                    audit_action,
                    target_type,
                    target_id,
                    old_value,
                    new_value,
                    event_timestamp,
                    reason
                )
                VALUES (
                    ?, ?, ?, ?, ?, ?, SYSDATETIME(), ?
                )
            """, (
                actor_user_id,
                "INCIDENT_STATUS_CHANGED",
                "INCIDENT",
                str(incident.incident_id),
                old_incident_status,
                new_incident_status,
                action_reason or None
            ))
                # 9. Resolve the linked security alert when the
        # investigation is closed as benign / false positive.
        if new_investigation_status == "COMPLETED":
            cursor.execute("""
                SELECT
                    alert_id,
                    status
                FROM security_alerts WITH (UPDLOCK, HOLDLOCK)
                WHERE alert_id = (
                    SELECT source_alert_id
                    FROM incidents
                    WHERE incident_id = ?
                )
            """, (incident.incident_id,))

            alert = cursor.fetchone()

            if alert is None:
                raise RuntimeError(
                    "Linked security alert not found."
                )

            old_alert_status = alert.status

            if old_alert_status not in (
                "OPEN",
                "UNDER_REVIEW"
            ):
                raise RuntimeError(
                    "Linked security alert is not eligible for resolution."
                )

            new_alert_status = (
                "FALSE_POSITIVE"
                if action_type == "FALSE_POSITIVE"
                else "RESOLVED"
            )

            cursor.execute("""
                UPDATE security_alerts
                SET
                    status = ?,
                    resolved_at = SYSDATETIME()
                WHERE alert_id = ?
                  AND status = ?
            """, (
                new_alert_status,
                alert.alert_id,
                old_alert_status
            ))

            if cursor.rowcount != 1:
                raise RuntimeError(
                    "Security alert status changed unexpectedly."
                )

            # Audit the alert transition.
            cursor.execute("""
                INSERT INTO audit_logs (
                    actor_user_id,
                    audit_action,
                    target_type,
                    target_id,
                    old_value,
                    new_value,
                    event_timestamp,
                    reason
                )
                VALUES (
                    ?, ?, ?, ?, ?, ?, SYSDATETIME(), ?
                )
            """, (
                actor_user_id,
                "ALERT_STATUS_CHANGED",
                "SECURITY_ALERT",
                str(alert.alert_id),
                old_alert_status,
                new_alert_status,
                action_reason or None
            ))

        # 10. Audit the analyst's investigation action.
        cursor.execute("""
            INSERT INTO audit_logs (
                actor_user_id,
                audit_action,
                target_type,
                target_id,
                old_value,
                new_value,
                event_timestamp,
                reason
            )
            VALUES (
                ?, ?, ?, ?, ?, ?, SYSDATETIME(), ?
            )
        """, (
            actor_user_id,
            "INVESTIGATION_ACTION",
            "INVESTIGATION",
            str(investigation_id),
            investigation.decision,
            action_type,
            action_reason or None
        ))

        # 11. Commit all changes together.
        connection.commit()

        return {
            "success": True,
            "investigation_id": investigation_id,
            "actor_user_id": actor_user_id,
            "action_type": action_type,
            "status": new_investigation_status,
            "decision": action_type,
            "reason": action_reason or None
        }

    except Exception:
        connection.rollback()
        raise

    finally:
        cursor.close()
        connection.close()

# =========================================================
# ACCESS ENFORCEMENT
# Authorization decision → access_events
# =========================================================

def enforce_access(
    user_id,
    resource_id,
    action,
    device_id=None,
    source_ip=None,
    location=None,
    auth_method=None,
    user_agent=None
):
    connection = get_connection()
    cursor = connection.cursor()

    try:
        # -------------------------------------------------
        # 1. Get user's role
        # -------------------------------------------------

        cursor.execute("""
            SELECT role_id
            FROM users
            WHERE user_id = ?
        """, (user_id,))

        user = cursor.fetchone()

        if not user:
            return {
                "event_id": None,
                "result": "DENY",
                "reason": "USER_NOT_FOUND"
            }

        role_id = user.role_id

        # -------------------------------------------------
        # 2. Check permission for requested resource/action
        # -------------------------------------------------

        cursor.execute("""
            SELECT
                can_view,
                can_create,
                can_edit,
                can_delete,
                can_admin
            FROM permissions
            WHERE role_id = ?
              AND resource_id = ?
        """, (
            role_id,
            resource_id
        ))

        permission = cursor.fetchone()

        action_permission = {
            "VIEW": "can_view",
            "CREATE": "can_create",
            "EDIT": "can_edit",
            "DELETE": "can_delete",
            "ADMIN": "can_admin"
        }

        normalized_action = str(
            action
        ).strip().upper()

        permission_column = action_permission.get(
            normalized_action
        )

        if not permission:
            allowed = False
        elif not permission_column:
            allowed = False
        else:
            allowed = bool(
                getattr(
                    permission,
                    permission_column
                )
            )

        # -------------------------------------------------
        # 3. Enforcement decision
        # -------------------------------------------------

        result = "ALLOW" if allowed else "DENY"

        reason = (
            "ACCESS_GRANTED"
            if allowed
            else "ACCESS_DENIED"
        )

        # -------------------------------------------------
        # 4. Create the authoritative access event
        # -------------------------------------------------

        cursor.execute("""
            INSERT INTO access_events (
                user_id,
                device_id,
                role_id,
                resource_id,
                event_type,
                action,
                event_timestamp,
                result,
                source_ip,
                location,
                auth_method,
                user_agent,
                risk_score,
                reason
            )
            OUTPUT INSERTED.event_id
            VALUES (
                ?, ?, ?, ?, ?,
                ?, SYSDATETIME(), ?,
                ?, ?, ?, ?, 0, ?
            )
        """, (
            user_id,
            device_id,
            role_id,
            resource_id,
            "RESOURCE_ACCESS",
            normalized_action,
            result,
            source_ip,
            location,
            auth_method,
            user_agent,
            reason
        ))

        event_id = cursor.fetchone()[0]

        connection.commit()

        return {
            "event_id": event_id,
            "user_id": user_id,
            "role_id": role_id,
            "resource_id": resource_id,
            "action": normalized_action,
            "result": result,
            "allowed": allowed,
            "reason": reason
        }

    except Exception:
        connection.rollback()
        raise

    finally:
        cursor.close()
        connection.close()

