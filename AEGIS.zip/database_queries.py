from database import get_connection


# =========================================================
# AEGIS DATABASE QUERIES
# SQL SERVER DATA ACCESS LAYER
# =========================================================


def get_dashboard_summary():
    """
    Returns the main AEGIS dashboard statistics
    directly from SQL Server.
    """

    connection = get_connection()
    cursor = connection.cursor()

    try:

        cursor.execute("""
            SELECT
                (SELECT COUNT(*) FROM departments),
                (SELECT COUNT(*) FROM roles),
                (SELECT COUNT(*) FROM users),
                (SELECT COUNT(*) FROM user_devices),
                (SELECT COUNT(*) FROM resources),
                (SELECT COUNT(*) FROM permissions),
                (SELECT COUNT(*) FROM access_events),
                (SELECT COUNT(*) FROM security_alerts),
                (SELECT COUNT(*) FROM audit_logs)
        """)

        row = cursor.fetchone()

        return {
            "departments": row[0],
            "roles": row[1],
            "users": row[2],
            "devices": row[3],
            "resources": row[4],
            "permissions": row[5],
            "access_events": row[6],
            "security_alerts": row[7],
            "audit_logs": row[8]
        }

    finally:

        cursor.close()
        connection.close()


# =========================================================
# SECURITY ALERT SUMMARY
# =========================================================

def get_alert_summary():

    connection = get_connection()
    cursor = connection.cursor()

    try:

        cursor.execute("""
            SELECT
                severity,
                COUNT(*) AS alert_count
            FROM security_alerts
            GROUP BY severity
        """)

        rows = cursor.fetchall()

        return {
            row[0]: row[1]
            for row in rows
        }

    finally:

        cursor.close()
        connection.close()


# =========================================================
# OPEN ALERTS
# =========================================================

def get_open_alert_count():

    connection = get_connection()
    cursor = connection.cursor()

    try:

        cursor.execute("""
            SELECT COUNT(*)
            FROM security_alerts
            WHERE status IN ('OPEN', 'INVESTIGATING')
        """)

        return cursor.fetchone()[0]

    finally:

        cursor.close()
        connection.close()


# =========================================================
# HIGH-RISK USERS
# =========================================================

def get_high_risk_users():

    connection = get_connection()
    cursor = connection.cursor()

    try:

        cursor.execute("""
            SELECT TOP 20
                u.employee_code,
                u.full_name,
                d.department_name,
                r.role_name,
                u.risk_score,
                COUNT(sa.alert_id) AS alert_count

            FROM users u

            INNER JOIN roles r
                ON u.role_id = r.role_id

            INNER JOIN departments d
                ON r.department_id = d.department_id

            LEFT JOIN security_alerts sa
                ON u.user_id = sa.user_id

            WHERE u.risk_score >= 70

            GROUP BY
                u.employee_code,
                u.full_name,
                d.department_name,
                r.role_name,
                u.risk_score

            ORDER BY
                u.risk_score DESC
        """)

        rows = cursor.fetchall()

        return [
            {
                "employee_code": row[0],
                "full_name": row[1],
                "department": row[2],
                "role": row[3],
                "risk_score": row[4],
                "alert_count": row[5]
            }
            for row in rows
        ]

    finally:

        cursor.close()
        connection.close()

# =========================================================
# USER DETAILS
# =========================================================

def get_user_details(user_id):

    connection = get_connection()
    cursor = connection.cursor()

    try:

        cursor.execute("""
            SELECT
                u.user_id,
                u.employee_code,
                u.full_name,
                u.email,
                u.status,
                u.location,
                u.join_date,
                u.mfa_enabled,
                u.risk_score,
                r.role_name,
                d.department_name
            FROM users u
            LEFT JOIN roles r
                ON u.role_id = r.role_id
            LEFT JOIN departments d
                ON r.department_id = d.department_id
            WHERE u.user_id = ?
        """, (user_id,))

        row = cursor.fetchone()

        if not row:
            return None

        return {
            "user_id": row[0],
            "employee_code": row[1],
            "full_name": row[2],
            "email": row[3],
            "status": row[4],
            "location": row[5],
            "join_date": row[6],
            "mfa_enabled": row[7],
            "risk_score": row[8],
            "role": row[9],
            "department": row[10]
        }

    finally:

        cursor.close()
        connection.close()
# =========================================================
# RECENT SECURITY ALERTS
# =========================================================

def get_recent_alerts(limit=10):

    connection = get_connection()
    cursor = connection.cursor()

    try:

        cursor.execute("""
            SELECT TOP (?)
                sa.alert_id,
                u.employee_code,
                u.full_name,
                d.department_name,
                sa.alert_type,
                sa.severity,
                sa.risk_score,
                sa.description,
                sa.status,
                sa.created_at

            FROM security_alerts sa

            INNER JOIN users u
                ON sa.user_id = u.user_id

            INNER JOIN roles r
                ON u.role_id = r.role_id

            INNER JOIN departments d
                ON r.department_id = d.department_id

            ORDER BY
                sa.created_at DESC
        """, limit)

        rows = cursor.fetchall()

        return [
            {
                "alert_id": row[0],
                "employee_code": row[1],
                "full_name": row[2],
                "department": row[3],
                "alert_type": row[4],
                "severity": row[5],
                "risk_score": row[6],
                "description": row[7],
                "status": row[8],
                "created_at": row[9]
            }
            for row in rows
        ]

    finally:

        cursor.close()
        connection.close()


# =========================================================
# DENIED ACCESS COUNT
# =========================================================

def get_denied_access_count():

    connection = get_connection()
    cursor = connection.cursor()

    try:

        cursor.execute("""
            SELECT COUNT(*)
            FROM access_events
            WHERE result = 'DENY'
              AND event_type = 'RESOURCE_ACCESS'
        """)

        return cursor.fetchone()[0]

    finally:

        cursor.close()
        connection.close()


# =========================================================
# DEVICE SECURITY SUMMARY
# =========================================================

def get_device_security_summary():

    connection = get_connection()
    cursor = connection.cursor()

    try:

        cursor.execute("""
            SELECT
                COUNT(*) AS total_devices,

                SUM(
                    CASE
                        WHEN managed = 1 THEN 1
                        ELSE 0
                    END
                ) AS managed_devices,

                SUM(
                    CASE
                        WHEN managed = 0 THEN 1
                        ELSE 0
                    END
                ) AS unmanaged_devices,

                SUM(
                    CASE
                        WHEN compliant = 1 THEN 1
                        ELSE 0
                    END
                ) AS compliant_devices,

                SUM(
                    CASE
                        WHEN compliant = 0 THEN 1
                        ELSE 0
                    END
                ) AS non_compliant_devices

            FROM user_devices
        """)

        row = cursor.fetchone()

        return {
            "total_devices": row[0],
            "managed_devices": row[1],
            "unmanaged_devices": row[2],
            "compliant_devices": row[3],
            "non_compliant_devices": row[4]
        }

    finally:

        cursor.close()
        connection.close()

# =========================================================
# EMPLOYEE WORK STATUS
# SQL SERVER SOURCE OF TRUTH
# =========================================================

def get_employee_work_status():

    connection = None
    cursor = None

    try:

        connection = get_connection()
        cursor = connection.cursor()

        # -------------------------------------------------
        # DEVICE SECURITY STATUS
        # -------------------------------------------------

        cursor.execute("""
            SELECT
                COUNT(*) AS total_devices,

                SUM(
                    CASE
                        WHEN managed = 1
                        THEN 1
                        ELSE 0
                    END
                ) AS managed_devices,

                SUM(
                    CASE
                        WHEN managed = 0
                        THEN 1
                        ELSE 0
                    END
                ) AS unmanaged_devices,

                SUM(
                    CASE
                        WHEN compliant = 1
                        THEN 1
                        ELSE 0
                    END
                ) AS compliant_devices,

                SUM(
                    CASE
                        WHEN compliant = 0
                        THEN 1
                        ELSE 0
                    END
                ) AS non_compliant_devices

            FROM user_devices
        """)

        device_row = cursor.fetchone()

        # -------------------------------------------------
        # NIGHT SHIFT
        # -------------------------------------------------

        cursor.execute("""
            SELECT COUNT(DISTINCT user_id)
            FROM user_work_schedules
            WHERE night_shift = 1
        """)

        night_shift = cursor.fetchone()[0] or 0

        # -------------------------------------------------
        # REMOTE WORKING
        # -------------------------------------------------

        cursor.execute("""
            SELECT COUNT(DISTINCT user_id)
            FROM user_work_authorizations
            WHERE UPPER(LTRIM(RTRIM(authorization_type)))
                  LIKE '%REMOTE%'
        """)

        remote_working = cursor.fetchone()[0] or 0

        # -------------------------------------------------
        # BUSINESS TRIP
        # -------------------------------------------------

        cursor.execute("""
            SELECT COUNT(DISTINCT user_id)
            FROM user_work_authorizations
            WHERE UPPER(LTRIM(RTRIM(authorization_type)))
                  LIKE '%BUSINESS%'
               OR UPPER(LTRIM(RTRIM(authorization_type)))
                  LIKE '%TRIP%'
        """)

        business_trip = cursor.fetchone()[0] or 0

        # -------------------------------------------------
        # RETURN COMPLETE WORK STATUS
        # -------------------------------------------------

        return {

            "total_devices":
                device_row[0] or 0,

            "managed":
                device_row[1] or 0,

            "unmanaged":
                device_row[2] or 0,

            "compliant":
                device_row[3] or 0,

            "non_compliant":
                device_row[4] or 0,

            "night_shift":
                night_shift,

            "remote_working":
                remote_working,

            "business_trip":
                business_trip

        }

    except Exception as e:

        print(
            f"Error getting employee work status: {e}"
        )

        return {

            "total_devices": 0,
            "managed": 0,
            "unmanaged": 0,
            "compliant": 0,
            "non_compliant": 0,
            "night_shift": 0,
            "remote_working": 0,
            "business_trip": 0

        }

    finally:

        if cursor:
            cursor.close()

        if connection:
            connection.close()



# =========================================================
# DEVICE INVENTORY
# SQL SERVER SOURCE OF TRUTH
# =========================================================

def get_device_inventory(
    search=None,
    posture=None
):

    connection = None
    cursor = None

    try:

        connection = get_connection()
        cursor = connection.cursor()

        query = """
            SELECT

                ud.device_id,
                ud.device_name,
                ud.device_type,
                ud.operating_system,
                ud.managed,
                ud.compliant,
                ud.last_seen,

                u.employee_code,
                u.full_name,
                d.department_name,

                latest.event_timestamp AS last_event_time,
                latest.result AS last_event_result,
                latest.source_ip AS last_ip,
                latest.location AS last_location,
                latest.risk_score AS latest_risk,

                (
                    SELECT COUNT(*)
                    FROM access_events ae_count
                    WHERE ae_count.device_id = ud.device_id
                ) AS event_count,

                (
                    SELECT COUNT(*)
                    FROM security_alerts sa_count
                    INNER JOIN access_events ae_count
                        ON sa_count.event_id = ae_count.event_id
                    WHERE ae_count.device_id = ud.device_id
                ) AS alert_count

            FROM user_devices ud

            OUTER APPLY (

                SELECT TOP (1)

                    ae.event_timestamp,
                    ae.result,
                    ae.source_ip,
                    ae.location,
                    ae.risk_score,
                    ae.user_id

                FROM access_events ae

                WHERE ae.device_id = ud.device_id

                ORDER BY
                    ae.event_timestamp DESC,
                    ae.event_id DESC

            ) latest

            LEFT JOIN users u
                ON latest.user_id = u.user_id

            LEFT JOIN roles r
                ON u.role_id = r.role_id

            LEFT JOIN departments d
                ON r.department_id = d.department_id

            WHERE 1 = 1
        """

        params = []


        # -----------------------------------------
        # SEARCH
        # -----------------------------------------

        if search:

            search_value = f"%{search}%"

            query += """
                AND (
                    ud.device_name LIKE ?
                    OR ud.device_type LIKE ?
                    OR ud.operating_system LIKE ?

                    OR u.full_name LIKE ?
                    OR u.employee_code LIKE ?

                    OR d.department_name LIKE ?

                    OR latest.source_ip LIKE ?
                    OR latest.location LIKE ?
                )
            """

            params.extend([
                search_value,
                search_value,
                search_value,
                search_value,
                search_value,
                search_value,
                search_value,
                search_value
            ])


        # -----------------------------------------
        # POSTURE FILTER
        # -----------------------------------------

        if posture == "MANAGED":

            query += """
                AND ud.managed = 1
            """

        elif posture == "UNMANAGED":

            query += """
                AND ud.managed = 0
            """

        elif posture == "COMPLIANT":

            query += """
                AND ud.compliant = 1
            """

        elif posture == "NON_COMPLIANT":

            query += """
                AND ud.compliant = 0
            """


        # -----------------------------------------
        # ORDER
        # -----------------------------------------

        query += """

            ORDER BY

                CASE
                    WHEN ud.compliant = 0 THEN 1
                    WHEN ud.managed = 0 THEN 2
                    ELSE 3
                END,

                ud.last_seen DESC

        """


        cursor.execute(
            query,
            params
        )

        rows = cursor.fetchall()

        columns = [
            column[0]
            for column in cursor.description
        ]

        return [
            dict(
                zip(
                    columns,
                    row
                )
            )
            for row in rows
        ]


    except Exception as e:

        print(
            f"Error getting device inventory: {e}"
        )

        return []


    finally:

        if cursor:
            cursor.close()

        if connection:
            connection.close()

# =========================================================
# DEVICE DETAILS
# SQL SERVER SOURCE OF TRUTH
# =========================================================

def get_device_details(
    device_id
):

    connection = None
    cursor = None

    try:

        connection = get_connection()
        cursor = connection.cursor()


        # -----------------------------------------
        # DEVICE + CURRENT OWNER
        # -----------------------------------------

        cursor.execute("""
            SELECT TOP (1)

                ud.device_id,
                ud.device_name,
                ud.device_type,
                ud.operating_system,
                ud.managed,
                ud.compliant,
                ud.last_seen,

                u.user_id,
                u.employee_code,
                u.full_name,
                u.email,
                u.status AS account_status,
                u.mfa_enabled,
                u.risk_score AS user_risk_score,

                r.role_name,
                d.department_name,

                latest.event_timestamp AS last_event_time,
                latest.result AS last_event_result,
                latest.source_ip AS last_ip,
                latest.location AS last_location,
                latest.auth_method AS last_auth_method,
                latest.user_agent AS last_user_agent,
                latest.risk_score AS latest_event_risk

            FROM user_devices ud

            OUTER APPLY (

                SELECT TOP (1)

                    ae.user_id,
                    ae.event_timestamp,
                    ae.result,
                    ae.source_ip,
                    ae.location,
                    ae.auth_method,
                    ae.user_agent,
                    ae.risk_score

                FROM access_events ae

                WHERE ae.device_id = ud.device_id

                ORDER BY
                    ae.event_timestamp DESC,
                    ae.event_id DESC

            ) latest

            LEFT JOIN users u
                ON latest.user_id = u.user_id

            LEFT JOIN roles r
                ON u.role_id = r.role_id

            LEFT JOIN departments d
                ON r.department_id = d.department_id

            WHERE ud.device_id = ?

        """, (
            device_id,
        ))


        row = cursor.fetchone()


        if row is None:

            return None


        columns = [
            column[0]
            for column in cursor.description
        ]


        device = dict(
            zip(
                columns,
                row
            )
        )


        # -----------------------------------------
        # TOTAL EVENTS
        # -----------------------------------------

        cursor.execute("""
            SELECT COUNT(*)
            FROM access_events
            WHERE device_id = ?
        """, (
            device_id,
        ))

        device["event_count"] = (
            cursor.fetchone()[0]
        )


        # -----------------------------------------
        # SUCCESSFUL EVENTS
        # Supports both SUCCESS and ALLOW
        # -----------------------------------------

        cursor.execute("""
            SELECT COUNT(*)
            FROM access_events

            WHERE device_id = ?

            AND result IN (
                'SUCCESS',
                'ALLOW'
            )

        """, (
            device_id,
        ))

        device["successful_events"] = (
            cursor.fetchone()[0]
        )


        # -----------------------------------------
        # FAILED / DENIED EVENTS
        # -----------------------------------------

        cursor.execute("""
            SELECT COUNT(*)
            FROM access_events

            WHERE device_id = ?

            AND result IN (
                'FAILED',
                'FAIL',
                'DENY'
            )

        """, (
            device_id,
        ))

        device["failed_events"] = (
            cursor.fetchone()[0]
        )


        # -----------------------------------------
        # ALERT COUNT
        # -----------------------------------------

        cursor.execute("""
            SELECT COUNT(*)

            FROM security_alerts sa

            INNER JOIN access_events ae
                ON sa.event_id = ae.event_id

            WHERE ae.device_id = ?

        """, (
            device_id,
        ))

        device["alert_count"] = (
            cursor.fetchone()[0]
        )


        # -----------------------------------------
        # RELATED SECURITY EVENTS
        # -----------------------------------------

        cursor.execute("""
            SELECT

                ae.event_id,
                ae.event_type,
                ae.[action],
                ae.result,
                ae.event_timestamp,
                ae.source_ip,
                ae.location,
                ae.auth_method,
                ae.user_agent,
                ae.risk_score,
                ae.reason,

                res.resource_name

            FROM access_events ae

            LEFT JOIN resources res
                ON ae.resource_id = res.resource_id

            WHERE ae.device_id = ?

            ORDER BY
                ae.event_timestamp DESC,
                ae.event_id DESC

        """, (
            device_id,
        ))


        rows = cursor.fetchall()

        columns = [
            column[0]
            for column in cursor.description
        ]


        device["events"] = [

            dict(
                zip(
                    columns,
                    row
                )
            )

            for row in rows
        ]


        # -----------------------------------------
        # RELATED SECURITY ALERTS
        # -----------------------------------------

        cursor.execute("""
            SELECT

                sa.alert_id,
                sa.alert_type,
                sa.severity,
                sa.risk_score,
                sa.description,
                sa.status,
                sa.created_at,

                ae.event_id,
                ae.event_timestamp,
                ae.reason

            FROM security_alerts sa

            INNER JOIN access_events ae
                ON sa.event_id = ae.event_id

            WHERE ae.device_id = ?

            ORDER BY
                sa.created_at DESC,
                sa.alert_id DESC

        """, (
            device_id,
        ))


        rows = cursor.fetchall()

        columns = [
            column[0]
            for column in cursor.description
        ]


        device["alerts"] = [

            dict(
                zip(
                    columns,
                    row
                )
            )

            for row in rows
        ]


        # -----------------------------------------
        # RELATED INCIDENTS
        # -----------------------------------------

        cursor.execute("""
            SELECT

                i.incident_id,
                i.incident_type,
                i.title,
                i.description,
                i.severity,
                i.risk_score,
                i.status,
                i.created_at,
                i.updated_at

            FROM incidents i

            INNER JOIN security_alerts sa
                ON i.source_alert_id = sa.alert_id

            INNER JOIN access_events ae
                ON sa.event_id = ae.event_id

            WHERE ae.device_id = ?

            ORDER BY
                i.created_at DESC,
                i.incident_id DESC

        """, (
            device_id,
        ))


        rows = cursor.fetchall()

        columns = [
            column[0]
            for column in cursor.description
        ]


        device["incidents"] = [

            dict(
                zip(
                    columns,
                    row
                )
            )

            for row in rows
        ]


        return device


    except Exception as e:

        print(
            f"Error getting device details: {e}"
        )

        return None


    finally:

        if cursor:
            cursor.close()

        if connection:
            connection.close()
# =========================================================
# DEPARTMENT SECURITY SUMMARY
# =========================================================

def get_department_summary():

    connection = get_connection()
    cursor = connection.cursor()

    try:

        cursor.execute("""
            SELECT
                d.department_name,

                COUNT(DISTINCT u.user_id)
                    AS total_users,

                COUNT(DISTINCT res.resource_id)
                    AS total_resources,

                COUNT(DISTINCT sa.alert_id)
                    AS total_alerts

            FROM departments d

            LEFT JOIN roles r
                ON d.department_id = r.department_id

            LEFT JOIN users u
                ON r.role_id = u.role_id

            LEFT JOIN resources res
                ON d.department_id = res.department_id

            LEFT JOIN security_alerts sa
                ON u.user_id = sa.user_id

            GROUP BY
                d.department_name

            ORDER BY
                d.department_name
        """)

        rows = cursor.fetchall()

        return [
            {
                "department": row[0],
                "users": row[1],
                "resources": row[2],
                "alerts": row[3]
            }
            for row in rows
        ]

    finally:

        cursor.close()
        connection.close()


# =========================================================
# REPORTS DATA
# SQL SERVER SOURCE OF TRUTH
# =========================================================

def get_reports_data(period="all"):

    connection = None
    cursor = None

    try:

        connection = get_connection()
        cursor = connection.cursor()

        # =================================================
        # DATE FILTER
        # =================================================

        period = str(period).strip().lower()

        if period == "today":

            date_condition = """
                CAST({timestamp_column} AS DATE)
                = CAST(GETDATE() AS DATE)
            """

        elif period == "7":

            date_condition = """
                {timestamp_column}
                >= DATEADD(DAY, -6, CAST(GETDATE() AS DATE))
            """

        elif period == "30":

            date_condition = """
                {timestamp_column}
                >= DATEADD(DAY, -29, CAST(GETDATE() AS DATE))
            """

        else:

            date_condition = "1 = 1"


        # =================================================
        # INCIDENT SUMMARY
        # =================================================

        incident_condition = date_condition.format(
            timestamp_column="i.created_at"
        )

        cursor.execute(f"""
            SELECT
                COUNT(*) AS total_incidents,

                SUM(
                    CASE
                        WHEN i.status IN ('OPEN', 'INVESTIGATING')
                        THEN 1
                        ELSE 0
                    END
                ) AS open_investigations,

                SUM(
                    CASE
                        WHEN i.status = 'RESOLVED'
                        THEN 1
                        ELSE 0
                    END
                ) AS resolved_incidents

            FROM incidents i

            WHERE {incident_condition}
        """)

        row = cursor.fetchone()

        total_incidents = row[0] or 0
        open_investigations = row[1] or 0
        resolved_incidents = row[2] or 0


        # =================================================
        # HIGH / CRITICAL INCIDENTS
        # =================================================

        cursor.execute(f"""
            SELECT COUNT(*)

            FROM incidents i

            WHERE {incident_condition}

            AND i.severity IN (
                'HIGH',
                'CRITICAL'
            )
        """)

        high_risk_incidents = (
            cursor.fetchone()[0] or 0
        )


        # =================================================
        # INCIDENT SEVERITY
        # =================================================

        cursor.execute(f"""
            SELECT
                i.severity,
                COUNT(*) AS incident_count

            FROM incidents i

            WHERE {incident_condition}

            GROUP BY
                i.severity

            ORDER BY
                CASE i.severity
                    WHEN 'CRITICAL' THEN 1
                    WHEN 'HIGH' THEN 2
                    WHEN 'MEDIUM' THEN 3
                    WHEN 'LOW' THEN 4
                    ELSE 5
                END
        """)

        severity_rows = cursor.fetchall()

        severity_counts = {
            "CRITICAL": 0,
            "HIGH": 0,
            "MEDIUM": 0,
            "LOW": 0
        }

        for row in severity_rows:

            severity = str(
                row[0] or ""
            ).upper()

            if severity in severity_counts:

                severity_counts[severity] = (
                    row[1] or 0
                )


        # =================================================
        # INCIDENT STATUS
        # =================================================

        cursor.execute(f"""
            SELECT
                i.status,
                COUNT(*) AS incident_count

            FROM incidents i

            WHERE {incident_condition}

            GROUP BY
                i.status
        """)

        status_rows = cursor.fetchall()

        status_counts = {
            "OPEN": 0,
            "INVESTIGATING": 0,
            "RESOLVED": 0,
            "FALSE_POSITIVE": 0
        }

        for row in status_rows:

            status = str(
                row[0] or ""
            ).upper()

            if status in status_counts:

                status_counts[status] = (
                    row[1] or 0
                )


        # =================================================
        # INCIDENT ACTIVITY BY DATE
        # =================================================

        cursor.execute(f"""
            SELECT
                CAST(i.created_at AS DATE) AS activity_date,
                COUNT(*) AS incident_count

            FROM incidents i

            WHERE {incident_condition}

            GROUP BY
                CAST(i.created_at AS DATE)

            ORDER BY
                activity_date
        """)

        activity_rows = cursor.fetchall()

        incident_activity = [

            {
                "date": row[0].strftime("%Y-%m-%d"),
                "count": row[1]
            }

            for row in activity_rows

            if row[0] is not None

        ]

                # =================================================
        # INCIDENT ACTIVITY BY DATE + SEVERITY
        # =================================================

        cursor.execute(f"""
            SELECT
                CAST(i.created_at AS DATE) AS activity_date,
                i.severity,
                COUNT(*) AS incident_count

            FROM incidents i

            WHERE {incident_condition}

            GROUP BY
                CAST(i.created_at AS DATE),
                i.severity

            ORDER BY
                activity_date
        """)

        severity_activity_rows = cursor.fetchall()

        severity_activity_by_date = {}

        for row in severity_activity_rows:

            if row[0] is None:
                continue

            date_string = row[0].strftime("%Y-%m-%d")

            if date_string not in severity_activity_by_date:
                severity_activity_by_date[date_string] = {
                    "date": date_string,
                    "CRITICAL": 0,
                    "HIGH": 0,
                    "MEDIUM": 0,
                    "LOW": 0
                }

            severity = str(row[1] or "").upper()

            if severity in (
                "CRITICAL",
                "HIGH",
                "MEDIUM",
                "LOW"
            ):
                severity_activity_by_date[date_string][severity] = (
                    row[2] or 0
                )

        incident_activity_by_severity = list(
            severity_activity_by_date.values()
        )
        # =================================================
        # TOP TARGETED USERS
        # =================================================

        cursor.execute(f"""
            SELECT TOP (5)

                u.full_name,
                COUNT(*) AS incident_count

            FROM incidents i

            INNER JOIN users u
                ON i.user_id = u.user_id

            WHERE {incident_condition}

            GROUP BY
                u.full_name

            ORDER BY
                incident_count DESC,
                u.full_name
        """)

        user_rows = cursor.fetchall()

        top_users = [

            {
                "name": row[0],
                "count": row[1]
            }

            for row in user_rows

        ]


        # =================================================
        # TOP AFFECTED DEVICES
        # =================================================

        cursor.execute(f"""
            SELECT TOP (5)

                ud.device_name,
                COUNT(*) AS incident_count

            FROM incidents i

            INNER JOIN security_alerts sa
                ON i.source_alert_id = sa.alert_id

            INNER JOIN access_events ae
                ON sa.event_id = ae.event_id

            INNER JOIN user_devices ud
                ON ae.device_id = ud.device_id

            WHERE {incident_condition}

            GROUP BY
                ud.device_name

            ORDER BY
                incident_count DESC,
                ud.device_name
        """)

        device_rows = cursor.fetchall()

        top_devices = [

            {
                "name": row[0],
                "count": row[1]
            }

            for row in device_rows

        ]


        # =================================================
        # DEVICE SECURITY POSTURE
        # CURRENT STATE — NOT PERIOD FILTERED
        # =================================================

        cursor.execute("""
            SELECT

                COUNT(*) AS total_devices,

                SUM(
                    CASE
                        WHEN managed = 1
                        THEN 1
                        ELSE 0
                    END
                ) AS managed_devices,

                SUM(
                    CASE
                        WHEN managed = 0
                        THEN 1
                        ELSE 0
                    END
                ) AS unmanaged_devices,

                SUM(
                    CASE
                        WHEN compliant = 1
                        THEN 1
                        ELSE 0
                    END
                ) AS compliant_devices,

                SUM(
                    CASE
                        WHEN compliant = 0
                        THEN 1
                        ELSE 0
                    END
                ) AS non_compliant_devices

            FROM user_devices
        """)

        device_posture_row = cursor.fetchone()

        device_posture = {

            "total": (
                device_posture_row[0] or 0
            ),

            "managed": (
                device_posture_row[1] or 0
            ),

            "unmanaged": (
                device_posture_row[2] or 0
            ),

            "compliant": (
                device_posture_row[3] or 0
            ),

            "non_compliant": (
                device_posture_row[4] or 0
            )

        }


        # =================================================
        # DETECTION ACTIVITY
        # SECURITY ALERT TYPES
        # =================================================

        alert_condition = date_condition.format(
            timestamp_column="sa.created_at"
        )

        cursor.execute(f"""
            SELECT
                sa.alert_type,
                COUNT(*) AS alert_count

            FROM security_alerts sa

            WHERE {alert_condition}

            GROUP BY
                sa.alert_type

            ORDER BY
                alert_count DESC
        """)

        detection_rows = cursor.fetchall()

        detection_activity = [

            {
                "name": row[0],
                "count": row[1]
            }

            for row in detection_rows

            if row[0] is not None

        ]


        # =================================================
        # EVENT ACTIVITY
        # ALL ACCESS EVENTS
        # =================================================

        event_condition = date_condition.format(
            timestamp_column="ae.event_timestamp"
        )

        cursor.execute(f"""
            SELECT
                ae.event_type,
                COUNT(*) AS event_count

            FROM access_events ae

            WHERE {event_condition}

            GROUP BY
                ae.event_type

            ORDER BY
                event_count DESC
        """)

        event_rows = cursor.fetchall()

        event_activity = [

            {
                "name": row[0],
                "count": row[1]
            }

            for row in event_rows

            if row[0] is not None

        ]


        # =================================================
        # RETURN COMPLETE REPORT DATA
        # =================================================

        return {

            "period": period,

            "summary": {

                "total_incidents":
                    total_incidents,

                "high_risk_incidents":
                    high_risk_incidents,

                "open_investigations":
                    open_investigations,

                "resolved_incidents":
                    resolved_incidents

            },

            "severity": severity_counts,

            "status": status_counts,

            "incident_activity": incident_activity,

            "incident_activity_by_severity":
                incident_activity_by_severity,

            "top_users": top_users,

            "top_devices":
                top_devices,

            "device_posture":
                device_posture,

            "detection_activity":
                detection_activity,

            "event_activity":
                event_activity

        }


    except Exception as e:

        print(
            f"Error getting reports data: {e}"
        )

        return None


    finally:

        if cursor:
            cursor.close()

        if connection:
            connection.close()


# =========================================================
# TEST ALL DATABASE QUERIES
# =========================================================

if __name__ == "__main__":

    print()
    print("==========================================")
    print("       AEGIS SQL DATA LAYER TEST")
    print("==========================================")

    summary = get_dashboard_summary()

    print()
    print("DATABASE SUMMARY")
    print("------------------------------------------")

    for key, value in summary.items():
        print(f"{key:20}: {value}")

    print()
    print("ALERT SUMMARY")
    print("------------------------------------------")

    alerts = get_alert_summary()

    for severity, count in alerts.items():
        print(f"{severity:20}: {count}")

    print()
    print("OPEN ALERTS")
    print("------------------------------------------")

    print(get_open_alert_count())

    print()
    print("DENIED ACCESS")
    print("------------------------------------------")

    print(get_denied_access_count())

    print()
    print("DEVICE SECURITY")
    print("------------------------------------------")

    devices = get_device_security_summary()

    for key, value in devices.items():
        print(f"{key:20}: {value}")

    print()
    print("HIGH-RISK USERS")
    print("------------------------------------------")

    high_risk = get_high_risk_users()

    for user in high_risk:
        print(
            user["employee_code"],
            "|",
            user["full_name"],
            "| Risk:",
            user["risk_score"]
        )

    print()
    print("RECENT ALERTS")
    print("------------------------------------------")

    recent_alerts = get_recent_alerts(5)

    for alert in recent_alerts:
        print(
            alert["alert_id"],
            "|",
            alert["alert_type"],
            "|",
            alert["severity"]
        )

    print()
    print("==========================================")
    print("       SQL DATA LAYER TEST COMPLETE")
    print("==========================================")
    print()

    print()
    print("REPORTS TEST")
    print("------------------------------------------")

    reports = get_reports_data("all")

    print(reports)

# =========================================================
# TODAY'S DASHBOARD DATA
# =========================================================

def get_today_dashboard_data():

    connection = get_connection()
    cursor = connection.cursor()

    try:

        # -----------------------------------------
        # TODAY'S EVENTS
        # -----------------------------------------

        cursor.execute("""
            SELECT COUNT(*)
            FROM access_events
            WHERE CAST(event_timestamp AS DATE)
                  = CAST(GETDATE() AS DATE)
        """)

        events_today = cursor.fetchone()[0]


        # -----------------------------------------
        # TODAY'S SECURITY INCIDENTS
        # Count alerts generated from events that
        # actually occurred today.
        # -----------------------------------------

        cursor.execute("""
            SELECT COUNT(*)
            FROM security_alerts sa
            INNER JOIN access_events ae
                ON sa.event_id = ae.event_id
            WHERE CAST(ae.event_timestamp AS DATE)
                  = CAST(GETDATE() AS DATE)
        """)

        incidents_today = cursor.fetchone()[0]


        # -----------------------------------------
        # TODAY'S OPEN / INVESTIGATING ALERTS
        # -----------------------------------------

        cursor.execute("""
            SELECT COUNT(*)
            FROM security_alerts sa
            INNER JOIN access_events ae
                ON sa.event_id = ae.event_id
            WHERE sa.status IN ('OPEN', 'INVESTIGATING')
              AND CAST(ae.event_timestamp AS DATE)
                  = CAST(GETDATE() AS DATE)
        """)

        unreviewed_today = cursor.fetchone()[0]


        # -----------------------------------------
        # TODAY'S RESOLVED ALERTS
        # Count alerts actually resolved today.
        # -----------------------------------------

        cursor.execute("""
            SELECT COUNT(*)
            FROM security_alerts
            WHERE status = 'RESOLVED'
              AND resolved_at IS NOT NULL
              AND CAST(resolved_at AS DATE)
                  = CAST(GETDATE() AS DATE)
        """)

        resolved_today = cursor.fetchone()[0]


        # -----------------------------------------
        # TODAY'S CRITICAL
        # -----------------------------------------

        cursor.execute("""
            SELECT COUNT(*)
            FROM security_alerts sa
            INNER JOIN access_events ae
                ON sa.event_id = ae.event_id
            WHERE sa.severity = 'CRITICAL'
              AND CAST(ae.event_timestamp AS DATE)
                  = CAST(GETDATE() AS DATE)
        """)

        critical_today = cursor.fetchone()[0]


        # -----------------------------------------
        # TODAY'S HIGH
        # -----------------------------------------

        cursor.execute("""
            SELECT COUNT(*)
            FROM security_alerts sa
            INNER JOIN access_events ae
                ON sa.event_id = ae.event_id
            WHERE sa.severity = 'HIGH'
              AND CAST(ae.event_timestamp AS DATE)
                  = CAST(GETDATE() AS DATE)
        """)

        high_today = cursor.fetchone()[0]


        # -----------------------------------------
        # TODAY'S MEDIUM
        # -----------------------------------------

        cursor.execute("""
            SELECT COUNT(*)
            FROM security_alerts sa
            INNER JOIN access_events ae
                ON sa.event_id = ae.event_id
            WHERE sa.severity = 'MEDIUM'
              AND CAST(ae.event_timestamp AS DATE)
                  = CAST(GETDATE() AS DATE)
        """)

        medium_today = cursor.fetchone()[0]


        # -----------------------------------------
        # TODAY'S LOW
        # -----------------------------------------

        cursor.execute("""
            SELECT COUNT(*)
            FROM security_alerts sa
            INNER JOIN access_events ae
                ON sa.event_id = ae.event_id
            WHERE sa.severity = 'LOW'
              AND CAST(ae.event_timestamp AS DATE)
                  = CAST(GETDATE() AS DATE)
        """)

        low_today = cursor.fetchone()[0]


        # -----------------------------------------
        # DETECTION ACTIVITY
        # Count active security alerts by detection type.
        # -----------------------------------------

        cursor.execute("""
            SELECT TOP 5
    CASE
        WHEN sa.alert_type IN (
            'UNAUTHORIZED_ACCESS',
            'UNAUTHORIZED_ACCESS_ATTEMPT'
        )
            THEN 'UNAUTHORIZED_ACCESS'

        WHEN sa.alert_type IN (
            'UNMANAGED_DEVICE',
            'UNMANAGED_DEVICE_ACCESS'
        )
            THEN 'UNMANAGED_DEVICE'

        WHEN sa.alert_type IN (
            'AFTER_HOURS_ACCESS',
            'AFTER_HOURS_CRITICAL_ACCESS'
        )
            THEN 'AFTER_HOURS_ACCESS'

        ELSE sa.alert_type
    END AS detection_type,

    COUNT(*) AS detection_count

FROM security_alerts sa

WHERE sa.status IN ('OPEN', 'INVESTIGATING')

GROUP BY
    CASE
        WHEN sa.alert_type IN (
            'UNAUTHORIZED_ACCESS',
            'UNAUTHORIZED_ACCESS_ATTEMPT'
        )
            THEN 'UNAUTHORIZED_ACCESS'

        WHEN sa.alert_type IN (
            'UNMANAGED_DEVICE',
            'UNMANAGED_DEVICE_ACCESS'
        )
            THEN 'UNMANAGED_DEVICE'

        WHEN sa.alert_type IN (
            'AFTER_HOURS_ACCESS',
            'AFTER_HOURS_CRITICAL_ACCESS'
        )
            THEN 'AFTER_HOURS_ACCESS'

        ELSE sa.alert_type
    END

ORDER BY
    COUNT(*) DESC,
    detection_type;
        """)

        detection_rows = cursor.fetchall()

        detection_activity = [
            {
                "name": row[0],
                "count": row[1]
            }
            for row in detection_rows
        ]


        return {
            "events_today": events_today,
            "incidents_today": incidents_today,
            "unreviewed_today": unreviewed_today,
            "resolved_today": resolved_today,
            "critical_today": critical_today,
            "high_today": high_today,
            "medium_today": medium_today,
            "low_today": low_today,
            "detection_activity": detection_activity
}

    finally:

        cursor.close()
        connection.close()


# =========================================================
# TODAY'S SECURITY ACTIVITY
# =========================================================

def get_today_security_activity(limit=20):
    """
    Returns today's security activity directly from SQL Server.
    Used by the AEGIS dashboard activity feed.
    """

    connection = get_connection()
    cursor = connection.cursor()

    query = """
        SELECT TOP (?)
            ae.event_id,
            ae.event_timestamp,
            ae.event_type,
            ae.action,
            ae.result,
            ae.source_ip,
            u.employee_code,
            u.full_name,
            latest_alert.alert_id
        FROM access_events ae

        INNER JOIN users u
            ON ae.user_id = u.user_id

        OUTER APPLY (
            SELECT TOP 1
                sa.alert_id
            FROM security_alerts sa
            WHERE sa.event_id = ae.event_id
            ORDER BY sa.created_at DESC, sa.alert_id DESC
        ) latest_alert

        WHERE CAST(ae.event_timestamp AS DATE)
              = CAST(GETDATE() AS DATE)

        ORDER BY ae.event_timestamp DESC;
    """

    cursor.execute(query, limit)

    rows = cursor.fetchall()

    activity = []

    for row in rows:

        # Convert SQL Server event type into dashboard wording
        if row.event_type == "LOGIN":
            event_name = "User Login"

        elif row.event_type == "LOGOUT":
            event_name = "User Logout"

        elif row.event_type == "MFA_EVENT":
            event_name = "MFA Authentication"

        elif row.event_type == "PASSWORD_CHANGE":
            event_name = "Password Change"

        elif row.event_type == "RESOURCE_ACCESS":

            if row.action:
                event_name = f"Resource {row.action.title()}"

            else:
                event_name = "Resource Access"

        else:
            event_name = row.event_type.replace("_", " ").title()


        # Dashboard currently expects FAILED for unsuccessful activity
        if row.result == "DENY":
            display_result = "FAILED"

        else:
            display_result = "SUCCESS"


        # Keep incident_id compatible with the existing HTML
        incident_id = None

        if row.alert_id is not None:
            incident_id = f"ALERT-{row.alert_id:04d}"


        activity.append({
            "timestamp": row.event_timestamp.strftime("%Y-%m-%d %H:%M:%S"),
            "event": event_name,
            "username": row.full_name,
            "result": display_result,
            "incident_id": incident_id,
            "employee_code": row.employee_code,
            "event_id": row.event_id,
            "source_ip": row.source_ip
        })


    cursor.close()
    connection.close()

    return activity

def get_incident_details(incident_id):
    conn = None
    cursor = None

    try:
        conn = get_connection()
        cursor = conn.cursor()

        cursor.execute("""
            SELECT
                i.incident_id,
                i.source_alert_id,
                i.user_id,
                i.incident_type,
                i.title,
                i.description,
                i.severity,
                i.risk_score,
                i.status AS incident_status,
                i.assigned_to,
                i.created_at,
                i.updated_at,
                i.resolved_at,
                i.resolution_notes,

                u.employee_code,
                u.full_name,
                u.email,
                u.status AS account_status,
                u.mfa_enabled,
                u.risk_score AS user_risk_score,

                r.role_name,
                d.department_name,

                sa.alert_id,
                sa.alert_type,
                sa.severity AS alert_severity,
                sa.risk_score AS alert_risk_score,
                sa.description AS alert_description,
                sa.status AS alert_status,
                sa.created_at AS alert_created_at,

                ae.event_id,
                ae.event_type,
                ae.[action],
                ae.result,
                ae.event_timestamp,
                ae.source_ip,
                ae.location,
                ae.auth_method,
                ae.user_agent,
                ae.risk_score,
                ae.reason,

                res.resource_name,
                res.resource_type,
                res.sensitivity,

                ud.device_name,
                ud.device_type,
                ud.operating_system,
                ud.managed,
                ud.compliant,
                ud.last_seen

            FROM incidents i

            INNER JOIN users u
                ON i.user_id = u.user_id

            INNER JOIN roles r
                ON u.role_id = r.role_id

            INNER JOIN departments d
                ON r.department_id = d.department_id

            LEFT JOIN security_alerts sa
                ON i.source_alert_id = sa.alert_id

            LEFT JOIN access_events ae
                ON sa.event_id = ae.event_id

            LEFT JOIN resources res
                ON ae.resource_id = res.resource_id

            LEFT JOIN user_devices ud
                ON ae.device_id = ud.device_id

            WHERE i.incident_id = ?
        """, (incident_id,))

        row = cursor.fetchone()

        if row is None:
            return None

        columns = [column[0] for column in cursor.description]

        return dict(zip(columns, row))

    except Exception as e:
        print(f"Error getting incident details: {e}")
        return None

    finally:
        if cursor:
            cursor.close()

        if conn:
            conn.close()

def get_investigation_details(incident_id):
    conn = None
    cursor = None

    try:
        conn = get_connection()
        cursor = conn.cursor()

        # =====================================================
        # INCIDENT + TRIGGERING EVENT
        # =====================================================

        cursor.execute("""
            SELECT
                i.incident_id,
                i.source_alert_id,
                i.user_id,
                i.incident_type,
                i.title,
                i.description,
                i.severity,
                i.risk_score,
                i.status AS incident_status,
                i.assigned_to,
                i.created_at,
                i.updated_at,
                i.resolved_at,
                i.resolution_notes,

                u.employee_code,
                u.full_name,
                u.email,
                u.status AS account_status,
                u.mfa_enabled,
                u.risk_score AS user_risk_score,

                r.role_name,
                d.department_name,

                sa.alert_id,
                sa.alert_type,
                sa.severity AS alert_severity,
                sa.risk_score AS alert_risk_score,
                sa.description AS alert_description,
                sa.status AS alert_status,
                sa.created_at AS alert_created_at,

                ae.event_id,
                ae.event_type,
                ae.[action],
                ae.result,
                ae.event_timestamp,
                ae.source_ip,
                ae.location,
                ae.auth_method,
                ae.user_agent,
                ae.risk_score AS event_risk_score,
                ae.reason,

                res.resource_id,
                res.resource_name,
                res.resource_type,
                res.sensitivity,

                ud.device_id,
                ud.device_name,
                ud.device_type,
                ud.operating_system,
                ud.managed,
                ud.compliant,
                ud.last_seen

            FROM incidents i

            INNER JOIN users u
                ON i.user_id = u.user_id

            INNER JOIN roles r
                ON u.role_id = r.role_id

            INNER JOIN departments d
                ON r.department_id = d.department_id

            LEFT JOIN security_alerts sa
                ON i.source_alert_id = sa.alert_id

            LEFT JOIN access_events ae
                ON sa.event_id = ae.event_id

            LEFT JOIN resources res
                ON ae.resource_id = res.resource_id

            LEFT JOIN user_devices ud
                ON ae.device_id = ud.device_id

            WHERE i.incident_id = ?
        """, (incident_id,))

        row = cursor.fetchone()

        if row is None:
            return None

        columns = [column[0] for column in cursor.description]

        incident = dict(zip(columns, row))

        # =====================================================
        # RELATED SECURITY EVENTS
        # =====================================================

        cursor.execute("""
            SELECT
                ae.event_id,
                ae.event_type,
                ae.[action],
                ae.result,
                ae.event_timestamp,
                ae.source_ip,
                ae.location,
                ae.auth_method,
                ae.user_agent,
                ae.risk_score,
                ae.reason,

                res.resource_id,
                res.resource_name,
                res.resource_type,
                res.sensitivity,

                ud.device_id,
                ud.device_name,
                ud.device_type,
                ud.operating_system,
                ud.managed,
                ud.compliant

            FROM access_events ae

            LEFT JOIN resources res
                ON ae.resource_id = res.resource_id

            LEFT JOIN user_devices ud
                ON ae.device_id = ud.device_id

            WHERE ae.user_id = ?

            ORDER BY ae.event_timestamp ASC
        """, (incident["user_id"],))

        rows = cursor.fetchall()

        columns = [column[0] for column in cursor.description]

        related_events = [
            dict(zip(columns, row))
            for row in rows
        ]

        incident["related_events"] = related_events

        return incident

    except Exception as e:
        print(f"Error getting investigation details: {e}")
        return None

    finally:
        if cursor:
            cursor.close()

        if conn:
            conn.close()

def get_incidents_queue():
    conn = None
    cursor = None

    try:
        conn = get_connection()
        cursor = conn.cursor()

        cursor.execute("""
            SELECT
                i.incident_id,
                i.incident_type,
                i.title,
                i.severity,
                i.risk_score,

                CASE
                    WHEN i.status = 'OPEN' THEN 'Open'
                    WHEN i.status = 'INVESTIGATING' THEN 'Under Review'
                    WHEN i.status = 'RESOLVED' THEN 'Resolved'
                    WHEN i.status = 'FALSE_POSITIVE' THEN 'False Positive'
                    ELSE i.status
                END AS status,

                i.created_at,

                u.employee_code,
                u.full_name,

                r.role_name,
                d.department_name,

                ae.source_ip,

                ud.device_name

            FROM incidents i

            INNER JOIN users u
                ON i.user_id = u.user_id

            INNER JOIN roles r
                ON u.role_id = r.role_id

            INNER JOIN departments d
                ON r.department_id = d.department_id

            LEFT JOIN security_alerts sa
                ON i.source_alert_id = sa.alert_id

            LEFT JOIN access_events ae
                ON sa.event_id = ae.event_id

            LEFT JOIN user_devices ud
                ON ae.device_id = ud.device_id

            ORDER BY
                CASE i.severity
                    WHEN 'CRITICAL' THEN 1
                    WHEN 'HIGH' THEN 2
                    WHEN 'MEDIUM' THEN 3
                    WHEN 'LOW' THEN 4
                    ELSE 5
                END,
                i.created_at DESC
        """)

        rows = cursor.fetchall()

        columns = [column[0] for column in cursor.description]

        incidents = [
            dict(zip(columns, row))
            for row in rows
        ]

        # Provide the legacy field names expected by the
        # current Incident Queue template.
        for incident in incidents:
            incident["event"] = incident.get("title")
            incident["username"] = incident.get("full_name")
            incident["ip_address"] = incident.get("source_ip")
            incident["device"] = incident.get("device_name")
            incident["timestamp"] = (
                 incident.get("created_at").strftime("%Y-%m-%dT%H:%M:%S")
                 if incident.get("created_at")
                 else ""
               )
        return incidents

    except Exception as e:
        print(f"Error getting incidents for queue: {e}")
        return []

    finally:
        if cursor:
            cursor.close()

        if conn:
            conn.close()

def get_investigations_queue():
    """
    Returns SQL-backed investigation records for the Investigations page.
    Includes all incidents so analysts can filter by investigation status.
    """

    conn = None
    cursor = None

    try:
        conn = get_connection()
        cursor = conn.cursor()

        cursor.execute("""
            SELECT
                i.incident_id,
                i.incident_type,
                i.title,
                i.description,
                i.severity,
                i.risk_score,
                i.status AS investigation_status,
                i.assigned_to,
                i.created_at,
                i.updated_at,

                u.employee_code,
                u.full_name,

                r.role_name,
                d.department_name,

                ae.event_id,
                ae.event_type,
                ae.[action],
                ae.result,
                ae.source_ip,

                ud.device_name

            FROM incidents i

            INNER JOIN users u
                ON i.user_id = u.user_id

            INNER JOIN roles r
                ON u.role_id = r.role_id

            INNER JOIN departments d
                ON r.department_id = d.department_id

            LEFT JOIN security_alerts sa
                ON i.source_alert_id = sa.alert_id

            LEFT JOIN access_events ae
                ON sa.event_id = ae.event_id

            LEFT JOIN user_devices ud
                ON ae.device_id = ud.device_id

            ORDER BY
                CASE i.severity
                    WHEN 'CRITICAL' THEN 1
                    WHEN 'HIGH' THEN 2
                    WHEN 'MEDIUM' THEN 3
                    WHEN 'LOW' THEN 4
                    ELSE 5
                END,
                i.updated_at DESC
        """)

        rows = cursor.fetchall()
        columns = [column[0] for column in cursor.description]

        return [
            dict(zip(columns, row))
            for row in rows
        ]

    except Exception as e:
        print(f"Error getting investigations queue: {e}")
        return []

    finally:
        if cursor:
            cursor.close()

        if conn:
            conn.close()

# ============================================================
# INVESTIGATION EVENT QUEUE
# Today's HIGH / CRITICAL security events
# ============================================================

def get_investigation_events(
    severity=None,
    department=None,
    event_type=None,
    result=None,
    search=None
):
    conn = None
    cursor = None

    try:
        conn = get_connection()
        cursor = conn.cursor()

        query = """
            SELECT
                ae.event_id,
                ae.event_type,
                ae.[action],
                ae.result,
                ae.event_timestamp,
                ae.source_ip,
                ae.location,
                ae.auth_method,
                ae.risk_score,
                ae.reason,

                u.employee_code,
                u.full_name,

                r.role_name,
                d.department_name,

                res.resource_name,

                ud.device_name

            FROM access_events ae

            INNER JOIN users u
                ON ae.user_id = u.user_id

            INNER JOIN roles r
                ON ae.role_id = r.role_id

            INNER JOIN departments d
                ON r.department_id = d.department_id

            LEFT JOIN resources res
                ON ae.resource_id = res.resource_id

            LEFT JOIN user_devices ud
                ON ae.device_id = ud.device_id

            WHERE
                CAST(ae.event_timestamp AS DATE)
                = CAST(GETDATE() AS DATE)

                AND ae.risk_score >= 70
        """

        params = []

        if severity:
            if severity.upper() == "CRITICAL":
                query += " AND ae.risk_score >= 90 "
            elif severity.upper() == "HIGH":
                query += """
                    AND ae.risk_score >= 70
                    AND ae.risk_score < 90
                """

        if department:
            query += " AND d.department_name = ? "
            params.append(department)

        if event_type:
            query += " AND ae.event_type = ? "
            params.append(event_type)

        if result:
            query += " AND ae.result = ? "
            params.append(result)

        if search:
            query += """
                AND (
                    CAST(ae.event_id AS VARCHAR(30)) LIKE ?
                    OR u.full_name LIKE ?
                    OR u.employee_code LIKE ?
                    OR ae.source_ip LIKE ?
                    OR ud.device_name LIKE ?
                    OR res.resource_name LIKE ?
                    OR ae.event_type LIKE ?
                )
            """

            search_value = f"%{search}%"

            params.extend([
                search_value,
                search_value,
                search_value,
                search_value,
                search_value,
                search_value,
                search_value
            ])

        query += """
            ORDER BY
                ae.risk_score DESC,
                ae.event_timestamp DESC
        """

        cursor.execute(query, params)

        rows = cursor.fetchall()
        columns = [
            column[0]
            for column in cursor.description
        ]

        return [
            dict(zip(columns, row))
            for row in rows
        ]

    except Exception as e:

        print(
            f"Error getting investigation events: {e}"
        )

        return []

    finally:

        if cursor:
            cursor.close()

        if conn:
            conn.close()


# ============================================================
# INVESTIGATION EVENT DETAILS
# ============================================================

def get_investigation_event_details(event_id):

    conn = None
    cursor = None

    try:

        conn = get_connection()
        cursor = conn.cursor()

        cursor.execute("""
            SELECT
                ae.event_id,
                ae.user_id,
                ae.event_type,
                ae.[action],
                ae.result,
                ae.event_timestamp,
                ae.source_ip,
                ae.location,
                ae.auth_method,
                ae.user_agent,
                ae.risk_score,
                ae.reason,

                u.employee_code,
                u.full_name,
                u.email,
                u.status AS account_status,
                u.mfa_enabled,
                u.risk_score AS user_risk_score,

                r.role_id,
                r.role_name,

                d.department_id,
                d.department_name,

                res.resource_id,
                res.resource_name,
                res.resource_type,
                res.sensitivity,

                ud.device_id,
                ud.device_name,
                ud.device_type,
                ud.operating_system,
                ud.managed,
                ud.compliant,
                ud.last_seen

            FROM access_events ae

            INNER JOIN users u
                ON ae.user_id = u.user_id

            INNER JOIN roles r
                ON ae.role_id = r.role_id

            INNER JOIN departments d
                ON r.department_id = d.department_id

            LEFT JOIN resources res
                ON ae.resource_id = res.resource_id

            LEFT JOIN user_devices ud
                ON ae.device_id = ud.device_id

            WHERE ae.event_id = ?
        """, (event_id,))

        row = cursor.fetchone()

        if row is None:
            return None

        columns = [
            column[0]
            for column in cursor.description
        ]

        investigation = dict(
            zip(columns, row)
        )

        # ----------------------------------------------------
        # Related events for this user
        # ----------------------------------------------------

        cursor.execute("""
            SELECT TOP (20)

                ae.event_id,
                ae.event_type,
                ae.[action],
                ae.result,
                ae.event_timestamp,
                ae.source_ip,
                ae.location,
                ae.auth_method,
                ae.risk_score,
                ae.reason,

                res.resource_name

            FROM access_events ae

            LEFT JOIN resources res
                ON ae.resource_id = res.resource_id

            WHERE ae.user_id = ?

            ORDER BY ae.event_timestamp DESC
        """, (
            investigation["user_id"],
        ))

        related_rows = cursor.fetchall()

        related_columns = [
            column[0]
            for column in cursor.description
        ]

        investigation["related_events"] = [
            dict(zip(related_columns, related_row))
            for related_row in related_rows
        ]

        # ----------------------------------------------------
        # Existing incident linked to this event, if any
        # ----------------------------------------------------

        cursor.execute("""
            SELECT TOP (1)
                i.incident_id,
                i.status,
                i.title
            FROM incidents i

            INNER JOIN security_alerts sa
                ON i.source_alert_id = sa.alert_id

            WHERE sa.event_id = ?

            ORDER BY i.created_at DESC
        """, (
            event_id,
        ))

        incident_row = cursor.fetchone()

        if incident_row:

            investigation["incident_id"] = incident_row[0]
            investigation["incident_status"] = incident_row[1]
            investigation["incident_title"] = incident_row[2]

        else:

            investigation["incident_id"] = None
            investigation["incident_status"] = None
            investigation["incident_title"] = None

        return investigation

    except Exception as e:

        print(
            f"Error getting investigation event details: {e}"
        )

        return None

    finally:

        if cursor:
            cursor.close()

        if conn:
            conn.close()
# =========================================================
# INVESTIGATION QUEUE
# TODAY'S HIGH / CRITICAL EVENTS ONLY
# =========================================================

def get_investigation_events(
    severity=None,
    department=None,
    event_type=None,
    result=None,
    search=None
):

    conn = None
    cursor = None

    try:
        conn = get_connection()
        cursor = conn.cursor()

        query = """
            SELECT
                ae.event_id,
                ae.event_type,
                ae.[action],
                ae.result,
                ae.event_timestamp,
                ae.source_ip,
                ae.location,
                ae.auth_method,
                ae.risk_score,
                ae.reason,

                u.employee_code,
                u.full_name,

                r.role_name,
                d.department_name,

                res.resource_name,

                ud.device_name

            FROM access_events ae

            INNER JOIN users u
                ON ae.user_id = u.user_id

            INNER JOIN roles r
                ON ae.role_id = r.role_id

            INNER JOIN departments d
                ON r.department_id = d.department_id

            LEFT JOIN resources res
                ON ae.resource_id = res.resource_id

            LEFT JOIN user_devices ud
                ON ae.device_id = ud.device_id

            WHERE
                CAST(ae.event_timestamp AS DATE)
                = CAST(GETDATE() AS DATE)

                AND ae.risk_score >= 70
        """

        params = []

        if severity:

            if severity.upper() == "HIGH":

                query += """
                    AND ae.risk_score >= 70
                    AND ae.risk_score < 90
                """

            elif severity.upper() == "CRITICAL":

                query += """
                    AND ae.risk_score >= 90
                """

        if department:

            query += """
                AND d.department_name = ?
            """

            params.append(department)

        if event_type:

            query += """
                AND ae.event_type = ?
            """

            params.append(event_type)

        if result:

            query += """
                AND ae.result = ?
            """

            params.append(result)

        if search:

            query += """
                AND (
                    CAST(ae.event_id AS VARCHAR(30)) LIKE ?
                    OR u.full_name LIKE ?
                    OR u.employee_code LIKE ?
                    OR ae.source_ip LIKE ?
                    OR ud.device_name LIKE ?
                    OR res.resource_name LIKE ?
                    OR ae.event_type LIKE ?
                )
            """

            value = f"%{search}%"

            params.extend([
                value,
                value,
                value,
                value,
                value,
                value,
                value
            ])

        query += """
            ORDER BY
                ae.risk_score DESC,
                ae.event_timestamp DESC
        """

        cursor.execute(query, params)

        rows = cursor.fetchall()

        columns = [
            column[0]
            for column in cursor.description
        ]

        return [
            dict(zip(columns, row))
            for row in rows
        ]

    except Exception as e:

        print(
            f"Error getting investigation events: {e}"
        )

        return []

    finally:

        if cursor:
            cursor.close()

        if conn:
            conn.close()

# =========================================================
# INVESTIGATION EVENT QUEUE
# TODAY + HIGH / CRITICAL ONLY
# =========================================================

def get_investigation_events(
    severity=None,
    department=None,
    event_type=None,
    result=None,
    search=None
):
    conn = None
    cursor = None

    try:
        conn = get_connection()
        cursor = conn.cursor()

        query = """
            SELECT
                ae.event_id,
                ae.event_type,
                ae.[action],
                ae.result,
                ae.event_timestamp,
                ae.source_ip,
                ae.location,
                ae.auth_method,
                ae.risk_score,
                ae.reason,

                u.user_id,
                u.employee_code,
                u.full_name,
                u.email,
                u.status AS account_status,
                u.mfa_enabled,
                u.risk_score AS user_risk_score,

                r.role_name,
                d.department_name,

                res.resource_name,
                res.resource_type,
                res.sensitivity,

                ud.device_name,
                ud.device_type,
                ud.operating_system,
                ud.managed,
                ud.compliant

            FROM access_events ae

            INNER JOIN users u
                ON ae.user_id = u.user_id

            INNER JOIN roles r
                ON u.role_id = r.role_id

            INNER JOIN departments d
                ON r.department_id = d.department_id

            LEFT JOIN resources res
                ON ae.resource_id = res.resource_id

            LEFT JOIN user_devices ud
                ON ae.device_id = ud.device_id

            WHERE
                CAST(ae.event_timestamp AS DATE)
                    = CAST(GETDATE() AS DATE)

                AND ae.risk_score >= 70
        """

        params = []

        if severity:
            severity = severity.upper()

            if severity == "HIGH":
                query += " AND ae.risk_score BETWEEN 70 AND 89 "

            elif severity == "CRITICAL":
                query += " AND ae.risk_score >= 90 "

        if department:
            query += " AND d.department_name = ? "
            params.append(department)

        if event_type:
            query += " AND ae.event_type = ? "
            params.append(event_type)

        if result:
            query += " AND ae.result = ? "
            params.append(result)

        if search:
            search_value = f"%{search}%"

            query += """
                AND (
                    CAST(ae.event_id AS VARCHAR(50)) LIKE ?
                    OR u.full_name LIKE ?
                    OR u.employee_code LIKE ?
                    OR u.email LIKE ?
                    OR ae.source_ip LIKE ?
                    OR ae.event_type LIKE ?
                    OR ae.[action] LIKE ?
                    OR ae.result LIKE ?
                    OR res.resource_name LIKE ?
                    OR ud.device_name LIKE ?
                )
            """

            params.extend([
                search_value,
                search_value,
                search_value,
                search_value,
                search_value,
                search_value,
                search_value,
                search_value,
                search_value,
                search_value
            ])

        query += """
            ORDER BY
                ae.risk_score DESC,
                ae.event_timestamp DESC
        """

        cursor.execute(query, params)

        rows = cursor.fetchall()
        columns = [column[0] for column in cursor.description]

        return [
            dict(zip(columns, row))
            for row in rows
        ]

    except Exception as e:

        print(
            f"Error getting investigation events: {e}"
        )

        return []

    finally:

        if cursor:
            cursor.close()

        if conn:
            conn.close()


# =========================================================
# INVESTIGATION EVENT DETAILS
# =========================================================

def get_investigation_event_details(event_id):

    conn = None
    cursor = None

    try:

        conn = get_connection()
        cursor = conn.cursor()

        cursor.execute("""
            SELECT

                ae.event_id,
                ae.event_type,
                ae.[action],
                ae.result,
                ae.event_timestamp,
                ae.source_ip,
                ae.location,
                ae.auth_method,
                ae.user_agent,
                ae.risk_score,
                ae.reason,

                u.user_id,
                u.employee_code,
                u.full_name,
                u.email,
                u.status AS account_status,
                u.mfa_enabled,
                u.risk_score AS user_risk_score,

                r.role_id,
                r.role_name,

                d.department_id,
                d.department_name,

                res.resource_id,
                res.resource_name,
                res.resource_type,
                res.sensitivity,

                ud.device_id,
                ud.device_name,
                ud.device_type,
                ud.operating_system,
                ud.managed,
                ud.compliant,
                ud.last_seen,

                i.incident_id,
                i.incident_type,
                i.title AS incident_title,
                i.description AS incident_description,
                i.severity AS incident_severity,
                i.risk_score AS incident_risk_score,
                i.status AS incident_status,
                i.created_at AS incident_created_at,
                i.updated_at AS incident_updated_at

            FROM access_events ae

            INNER JOIN users u
                ON ae.user_id = u.user_id

            INNER JOIN roles r
                ON u.role_id = r.role_id

            INNER JOIN departments d
                ON r.department_id = d.department_id

            LEFT JOIN resources res
                ON ae.resource_id = res.resource_id

            LEFT JOIN user_devices ud
                ON ae.device_id = ud.device_id

            LEFT JOIN security_alerts sa
                ON ae.event_id = sa.event_id

            LEFT JOIN incidents i
                ON sa.alert_id = i.source_alert_id

            WHERE ae.event_id = ?
        """, (event_id,))

        row = cursor.fetchone()

        if row is None:
            return None

        columns = [
            column[0]
            for column in cursor.description
        ]

        investigation = dict(
            zip(columns, row)
        )

        # -------------------------------------------------
        # RELATED EVENTS
        # -------------------------------------------------

        cursor.execute("""
            SELECT TOP (20)

                ae.event_id,
                ae.event_type,
                ae.[action],
                ae.result,
                ae.event_timestamp,
                ae.source_ip,
                ae.location,
                ae.auth_method,
                ae.risk_score,
                ae.reason

            FROM access_events ae

            WHERE
                ae.user_id = ?

                AND ae.event_id <> ?

               WHERE
                     ae.user_id = ?
                    AND ae.event_id <> ?

                ORDER BY
                      ae.event_timestamp ASC

            ORDER BY
                ae.event_timestamp ASC
        """, (
            investigation["user_id"],
            event_id,
            investigation["event_timestamp"],
            investigation["event_timestamp"]
        ))

        related_rows = cursor.fetchall()

        related_columns = [
            column[0]
            for column in cursor.description
        ]

        investigation["related_events"] = [
            dict(zip(related_columns, row))
            for row in related_rows
        ]

        return investigation

    except Exception as e:

        print(
            f"Error getting investigation details: {e}"
        )

        return None

    finally:

        if cursor:
            cursor.close()

        if conn:
            conn.close()


# =========================================================
# ESCALATE INCIDENT TO INVESTIGATION
# =========================================================


def escalate_incident_to_investigation(
    incident_id,
    actor_user_id=None
):
    """
    Atomically escalate an incident and create or retrieve
    its associated investigation.

    Only OPEN and INVESTIGATING incidents are eligible.
    Resolved incidents are never silently reopened.
    """

    conn = None
    cursor = None

    try:
        conn = get_connection()
        cursor = conn.cursor()

        # 1. Lock the incident row to serialize concurrent escalations.
        cursor.execute("""
            SELECT
                i.incident_id,
                i.source_alert_id,
                i.status,
                sa.event_id
            FROM incidents i WITH (UPDLOCK, HOLDLOCK)
            LEFT JOIN security_alerts sa
                ON i.source_alert_id = sa.alert_id
            WHERE i.incident_id = ?
        """, (incident_id,))

        incident = cursor.fetchone()

        if incident is None or incident.event_id is None:
            conn.rollback()
            return None

        current_status = incident.status

        if current_status not in ("OPEN", "INVESTIGATING"):
            conn.rollback()
            return None

        # 2. Check for an existing investigation.
        cursor.execute("""
            SELECT
                investigation_id,
                status
            FROM investigations WITH (UPDLOCK, HOLDLOCK)
            WHERE incident_id = ?
        """, (incident_id,))

        investigation = cursor.fetchone()
        investigation_created = False

        # 3. Move OPEN incidents into INVESTIGATING.
        if current_status == "OPEN":
            cursor.execute("""
                UPDATE incidents
                SET
                    status = 'INVESTIGATING',
                    updated_at = SYSDATETIME()
                WHERE incident_id = ?
                  AND status = 'OPEN'
            """, (incident_id,))

            if cursor.rowcount != 1:
                raise RuntimeError(
                    "Incident status changed during escalation."
                )

            cursor.execute("""
                INSERT INTO audit_logs (
                    actor_user_id,
                    audit_action,
                    target_type,
                    target_id,
                    old_value,
                    new_value
                )
                VALUES (?, ?, ?, ?, ?, ?)
            """, (
                actor_user_id,
                "INCIDENT_ESCALATED",
                "INCIDENT",
                str(incident_id),
                "OPEN",
                "INVESTIGATING"
            ))

        # 4. Create the investigation if it doesn't exist.
        if investigation is None:
            cursor.execute("""
                INSERT INTO investigations (
                    incident_id,
                    assigned_to,
                    status,
                    started_at,
                    updated_at,
                    created_at
                )
                OUTPUT INSERTED.investigation_id
                VALUES (
                    ?, ?, 'IN_PROGRESS',
                    SYSDATETIME(),
                    SYSDATETIME(),
                    SYSDATETIME()
                )
            """, (
                incident_id,
                actor_user_id
            ))

            investigation_id = cursor.fetchone()[0]
            investigation_created = True
            investigation_status = "IN_PROGRESS"

            cursor.execute("""
                INSERT INTO audit_logs (
                    actor_user_id,
                    audit_action,
                    target_type,
                    target_id,
                    old_value,
                    new_value
                )
                VALUES (?, ?, ?, ?, ?, ?)
            """, (
                actor_user_id,
                "INVESTIGATION_STARTED",
                "INVESTIGATION",
                str(investigation_id),
                None,
                "IN_PROGRESS"
            ))

        else:
            investigation_id = investigation.investigation_id
            investigation_status = investigation.status

        # 5. Commit only after all required operations succeed.
        conn.commit()

        return {
            "incident_id": incident.incident_id,
            "event_id": incident.event_id,
            "investigation_id": investigation_id,
            "investigation_status": investigation_status,
            "investigation_created": investigation_created
        }

    except Exception as e:
        if conn:
            conn.rollback()

        print(
            f"Error escalating incident "
            f"{incident_id}: {e}"
        )
        return None

    finally:
        if cursor:
            cursor.close()

        if conn:
            conn.close()
# =========================================================
# FINAL INVESTIGATION QUEUE
# =========================================================
# DEFAULT:
#   Today's HIGH / CRITICAL events only
#
# WITH SEARCH / FILTER:
#   Search the complete historical event database
# =========================================================

def get_investigation_events(
    severity=None,
    department=None,
    event_type=None,
    result=None,
    search=None
):
    conn = None
    cursor = None

    try:
        conn = get_connection()
        cursor = conn.cursor()

        has_search_or_filter = any([
            severity,
            department,
            event_type,
            result,
            search
        ])

        query = """
            SELECT
                ae.event_id,
                ae.event_type,
                ae.[action],
                ae.result,
                ae.event_timestamp,
                ae.source_ip,
                ae.location,
                ae.auth_method,
                ae.user_agent,
                ae.risk_score,
                ae.reason,

                u.user_id,
                u.employee_code,
                u.full_name,
                u.email,
                u.status AS account_status,
                u.mfa_enabled,
                u.risk_score AS user_risk_score,

                r.role_name,
                d.department_name,

                res.resource_name,
                res.resource_type,
                res.sensitivity,

                ud.device_name,
                ud.device_type,
                ud.operating_system,
                ud.managed,
                ud.compliant

            FROM access_events ae

            INNER JOIN users u
                ON ae.user_id = u.user_id

            INNER JOIN roles r
                ON ae.role_id = r.role_id

            INNER JOIN departments d
                ON r.department_id = d.department_id

            LEFT JOIN resources res
                ON ae.resource_id = res.resource_id

            LEFT JOIN user_devices ud
                ON ae.device_id = ud.device_id

            WHERE 1 = 1
        """

        params = []

        # -------------------------------------------------
        # DEFAULT QUEUE
        # No search/filter = TODAY + HIGH/CRITICAL
        # -------------------------------------------------

        if not has_search_or_filter:
            query += """
                AND CAST(ae.event_timestamp AS DATE)
                    = CAST(GETDATE() AS DATE)

                AND ae.risk_score >= 70
            """

        # -------------------------------------------------
        # SEARCH / FILTER MODE
        # Searches historical data
        # -------------------------------------------------

        else:

            if severity:
                severity = severity.upper()

                if severity == "HIGH":
                    query += """
                        AND ae.risk_score >= 70
                        AND ae.risk_score < 90
                    """

                elif severity == "CRITICAL":
                    query += """
                        AND ae.risk_score >= 90
                    """

            else:
                # Investigation queue only deals with
                # high / critical events.
                query += """
                    AND ae.risk_score >= 70
                """

            if department:
                query += """
                    AND d.department_name = ?
                """
                params.append(department)

            if event_type:
                query += """
                    AND ae.event_type = ?
                """
                params.append(event_type)

            if result:
                query += """
                    AND ae.result = ?
                """
                params.append(result)

            if search:

                search_value = f"%{search}%"

                query += """
                    AND (
                        CAST(ae.event_id AS VARCHAR(50))
                            LIKE ?

                        OR u.full_name
                            LIKE ?

                        OR u.employee_code
                            LIKE ?

                        OR u.email
                            LIKE ?

                        OR ae.source_ip
                            LIKE ?

                        OR ae.location
                            LIKE ?

                        OR ae.event_type
                            LIKE ?

                        OR ae.[action]
                            LIKE ?

                        OR ae.result
                            LIKE ?

                        OR ae.reason
                            LIKE ?

                        OR res.resource_name
                            LIKE ?

                        OR ud.device_name
                            LIKE ?

                        OR r.role_name
                            LIKE ?

                        OR d.department_name
                            LIKE ?
                    )
                """

                params.extend([
                    search_value,
                    search_value,
                    search_value,
                    search_value,
                    search_value,
                    search_value,
                    search_value,
                    search_value,
                    search_value,
                    search_value,
                    search_value,
                    search_value,
                    search_value,
                    search_value
                ])

        query += """
            ORDER BY
                ae.event_timestamp DESC,
                ae.event_id DESC
        """

        cursor.execute(query, params)

        rows = cursor.fetchall()

        columns = [
            column[0]
            for column in cursor.description
        ]

        return [
            dict(zip(columns, row))
            for row in rows
        ]

    except Exception as e:

        print(
            f"Error getting investigation events: {e}"
        )

        return []

    finally:

        if cursor:
            cursor.close()

        if conn:
            conn.close()


# =========================================================
# INVESTIGATION FILTER OPTIONS
# =========================================================

def get_investigation_filter_options():

    conn = None
    cursor = None

    try:

        conn = get_connection()
        cursor = conn.cursor()

        cursor.execute("""
            SELECT DISTINCT
                d.department_name
            FROM departments d
            INNER JOIN roles r
                ON d.department_id = r.department_id
            INNER JOIN access_events ae
                ON ae.role_id = r.role_id
            WHERE d.department_name IS NOT NULL
            ORDER BY d.department_name
        """)

        departments = [
            row[0]
            for row in cursor.fetchall()
        ]

        cursor.execute("""
            SELECT DISTINCT
                ae.event_type
            FROM access_events ae
            WHERE ae.event_type IS NOT NULL
            ORDER BY ae.event_type
        """)

        event_types = [
            row[0]
            for row in cursor.fetchall()
        ]

        return departments, event_types

    except Exception as e:

        print(
            f"Error getting investigation filter options: {e}"
        )

        return [], []

    finally:

        if cursor:
            cursor.close()

        if conn:
            conn.close()



# =========================================================
# FINAL INVESTIGATION DETAIL
# =========================================================

def get_investigation_event_details(event_id):

    conn = None
    cursor = None

    try:

        conn = get_connection()
        cursor = conn.cursor()

        cursor.execute("""
            SELECT TOP (1)

                ae.event_id,
                ae.event_type,
                ae.[action],
                ae.result,
                ae.event_timestamp,
                ae.source_ip,
                ae.location,
                ae.auth_method,
                ae.user_agent,
                ae.risk_score,
                ae.reason,

                u.user_id,
                u.employee_code,
                u.full_name,
                u.email,
                u.status AS account_status,
                u.mfa_enabled,
                u.risk_score AS user_risk_score,

                r.role_id,
                r.role_name,

                d.department_id,
                d.department_name,

                res.resource_id,
                res.resource_name,
                res.resource_type,
                res.sensitivity,

                ud.device_id,
                ud.device_name,
                ud.device_type,
                ud.operating_system,
                ud.managed,
                ud.compliant,
                ud.last_seen

            FROM access_events ae

            INNER JOIN users u
                ON ae.user_id = u.user_id

            INNER JOIN roles r
                ON ae.role_id = r.role_id

            INNER JOIN departments d
                ON r.department_id = d.department_id

            LEFT JOIN resources res
                ON ae.resource_id = res.resource_id

            LEFT JOIN user_devices ud
                ON ae.device_id = ud.device_id

            WHERE ae.event_id = ?

        """, (event_id,))

        row = cursor.fetchone()

        if row is None:
            return None

        columns = [
            column[0]
            for column in cursor.description
        ]

        investigation = dict(
            zip(columns, row)
        )

        # -------------------------------------------------
        # RELATED USER EVENTS
        # -------------------------------------------------

        cursor.execute("""
            SELECT TOP (20)

                ae.event_id,
                ae.event_type,
                ae.[action],
                ae.result,
                ae.event_timestamp,
                ae.source_ip,
                ae.location,
                ae.auth_method,
                ae.risk_score,
                ae.reason,

                res.resource_name

            FROM access_events ae

            LEFT JOIN resources res
                ON ae.resource_id = res.resource_id

            WHERE
                ae.user_id = ?
                AND ae.event_id <> ?

            ORDER BY
                ae.event_timestamp ASC

        """, (
            investigation["user_id"],
            event_id
        ))

        related_rows = cursor.fetchall()

        related_columns = [
            column[0]
            for column in cursor.description
        ]

        investigation["related_events"] = [
            dict(
                zip(
                    related_columns,
                    related_row
                )
            )
            for related_row in related_rows
        ]

        # -------------------------------------------------
        # INCIDENT LINKED TO THIS EVENT
        # -------------------------------------------------

        cursor.execute("""
            SELECT TOP (1)

                i.incident_id,
                i.incident_type,
                i.title AS incident_title,
                i.description AS incident_description,
                i.severity AS incident_severity,
                i.risk_score AS incident_risk_score,
                i.status AS incident_status,
                i.created_at AS incident_created_at,
                i.updated_at AS incident_updated_at

            FROM incidents i

            INNER JOIN security_alerts sa
                ON i.source_alert_id = sa.alert_id

            WHERE sa.event_id = ?

            ORDER BY
                i.created_at DESC

        """, (event_id,))

        incident_row = cursor.fetchone()

        if incident_row:

            incident_columns = [
                column[0]
                for column in cursor.description
            ]

            investigation.update(
                dict(
                    zip(
                        incident_columns,
                        incident_row
                    )
                )
            )

        else:

            investigation["incident_id"] = None
            investigation["incident_type"] = None
            investigation["incident_title"] = None
            investigation["incident_description"] = None
            investigation["incident_severity"] = None
            investigation["incident_risk_score"] = None
            investigation["incident_status"] = None
            investigation["incident_created_at"] = None
            investigation["incident_updated_at"] = None

        return investigation

    except Exception as e:

        print(
            f"Error getting investigation event details: {e}"
        )

        return None

    finally:

        if cursor:
            cursor.close()

        if conn:
            conn.close()
print(get_user_details(1))


