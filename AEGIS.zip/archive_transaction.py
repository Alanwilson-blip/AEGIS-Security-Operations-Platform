
from archive_database import get_archive_connection

# SAFETY GATE: do not enable until server-side authorization
# and the archive write path have been reviewed and tested.
ARCHIVE_EXECUTION_ENABLED = True
TABLES = {
    "access_events": ("event_id", "access_events_archive"),
    "security_alerts": ("alert_id", "security_alerts_archive"),
    "incidents": ("incident_id", "incidents_archive"),
    "investigations": ("investigation_id", "investigations_archive"),
    "investigation_actions": ("action_id", "investigation_actions_archive"),
    "security_alert_detections": (
        "alert_detection_id", "security_alert_detections_archive"
    ),
    "device_vpn_history": (
        "vpn_history_id", "device_vpn_history_archive"
    ),
}

COPY_ORDER = [
    "access_events",
    "security_alerts",
    "incidents",
    "investigations",
    "investigation_actions",
    "security_alert_detections",
    "device_vpn_history",
]

DELETE_ORDER = [
    "investigation_actions",
    "investigations",
    "incidents",
    "security_alert_detections",
    "security_alerts",
    "device_vpn_history",
    "access_events",
]

HOLD_ALIASES = {
    "access_events": {
        "access_events", "access_event", "event", "events"
    },
    "security_alerts": {
        "security_alerts", "security_alert", "alert", "alerts"
    },
    "incidents": {"incidents", "incident"},
    "investigations": {"investigations", "investigation"},
    "investigation_actions": {
        "investigation_actions", "investigation_action",
        "action", "actions"
    },
    "security_alert_detections": {
        "security_alert_detections", "security_alert_detection",
        "alert_detection", "alert_detections",
        "detection", "detections"
    },
    "device_vpn_history": {
        "device_vpn_history", "vpn_history"
    },
}

MAX_IN_CLAUSE_IDS = 2000


def _require_dev(cursor):
    cursor.execute("SELECT DB_NAME()")
    actual = cursor.fetchone()[0]

    if actual != "AEGIS_DB":
        raise RuntimeError(
            f"Safety stop: expected AEGIS_DB, connected to {actual}"
        )


def _quote_identifier(name):
    return "[" + name.replace("]", "]]") + "]"


def _ids(cursor, table, pk, linked_column, values):
    """Fetch related IDs; fail closed if a parameter list is too large."""
    if not values:
        return []

    if len(values) > MAX_IN_CLAUSE_IDS:
        raise RuntimeError(
            f"Safety stop: too many IDs while discovering {table}; "
            "grouping must be redesigned rather than split."
        )

    placeholders = ",".join("?" for _ in values)

    cursor.execute(
        f"SELECT [{pk}] FROM dbo.[{table}] "
        f"WHERE [{linked_column}] IN ({placeholders})",
        tuple(values),
    )
    return [row[0] for row in cursor.fetchall()]


def _discover_group(cursor, incident_id):
    """Discover the evidence connected to the incident's source event."""
    cursor.execute(
        """
        SELECT source_alert_id
        FROM dbo.incidents
        WHERE incident_id = ?
        """,
        incident_id,
    )
    row = cursor.fetchone()

    if row is None:
        raise ValueError(f"Incident {incident_id} does not exist")

    if row[0] is None:
        raise ValueError("Incident has no source alert")

    source_alert_id = row[0]

    cursor.execute(
        """
        SELECT event_id
        FROM dbo.security_alerts
        WHERE alert_id = ?
        """,
        source_alert_id,
    )
    alert = cursor.fetchone()

    if alert is None or alert[0] is None:
        raise ValueError("Source alert or source event is missing")

    event_id = alert[0]

    # Include all alerts sharing the same event.
    alert_ids = _ids(
        cursor,
        "security_alerts",
        "alert_id",
        "event_id",
        [event_id],
    )

    # Include every incident linked to those alerts.
    incident_ids = _ids(
        cursor,
        "incidents",
        "incident_id",
        "source_alert_id",
        alert_ids,
    )

    if incident_id not in incident_ids:
        raise RuntimeError("Evidence-group discovery failed")

    investigation_ids = _ids(
        cursor,
        "investigations",
        "investigation_id",
        "incident_id",
        incident_ids,
    )

    action_ids = _ids(
        cursor,
        "investigation_actions",
        "action_id",
        "investigation_id",
        investigation_ids,
    )

    detection_ids = _ids(
        cursor,
        "security_alert_detections",
        "alert_detection_id",
        "alert_id",
        alert_ids,
    )

    vpn_ids = _ids(
        cursor,
        "device_vpn_history",
        "vpn_history_id",
        "event_id",
        [event_id],
    )

    return {
        "access_events": [event_id],
        "security_alerts": alert_ids,
        "incidents": incident_ids,
        "investigations": investigation_ids,
        "investigation_actions": action_ids,
        "security_alert_detections": detection_ids,
        "device_vpn_history": vpn_ids,
    }


def _stage_group_ids(cursor, group):
    """Stage all group IDs in a temporary table for dependency checks."""
    cursor.execute(
        """
        IF OBJECT_ID('tempdb..#archive_group_ids') IS NOT NULL
            DROP TABLE #archive_group_ids;

        CREATE TABLE #archive_group_ids (
            table_name sysname NOT NULL,
            record_id bigint NOT NULL,
            PRIMARY KEY (table_name, record_id)
        );
        """
    )

    rows = [
        (table, record_id)
        for table, ids in group.items()
        for record_id in ids
    ]

    if rows:
        cursor.executemany(
            """
            INSERT INTO #archive_group_ids (table_name, record_id)
            VALUES (?, ?)
            """,
            rows,
        )


def _check_live_foreign_key_dependencies(cursor, group):
    """
    Block the archive if any live child outside the group still
    references a parent row that would be removed.

    Uses staged IDs instead of NOT IN batches, avoiding the earlier
    bug where one batch could be mistaken for external dependants.
    """
    _require_dev(cursor)
    _stage_group_ids(cursor, group)

    for parent_table, parent_ids in group.items():
        if not parent_ids:
            continue

        if parent_table not in TABLES:
            raise RuntimeError(
                f"No primary-key mapping for {parent_table}"
            )

        parent_pk = TABLES[parent_table][0]

        cursor.execute(
            """
            SELECT
                fk.object_id,
                fk.name,
                ps.name,
                pt.name,
                pc.name,
                cs.name,
                ct.name,
                cc.name,
                fkc.constraint_column_id
            FROM sys.foreign_keys AS fk
            JOIN sys.foreign_key_columns AS fkc
              ON fkc.constraint_object_id = fk.object_id
            JOIN sys.tables AS pt
              ON pt.object_id = fk.referenced_object_id
            JOIN sys.schemas AS ps
              ON ps.schema_id = pt.schema_id
            JOIN sys.columns AS pc
              ON pc.object_id = pt.object_id
             AND pc.column_id = fkc.referenced_column_id
            JOIN sys.tables AS ct
              ON ct.object_id = fk.parent_object_id
            JOIN sys.schemas AS cs
              ON cs.schema_id = ct.schema_id
            JOIN sys.columns AS cc
              ON cc.object_id = ct.object_id
             AND cc.column_id = fkc.parent_column_id
            WHERE fk.referenced_object_id = OBJECT_ID(?)
            ORDER BY fk.object_id, fkc.constraint_column_id
            """,
            f"dbo.{parent_table}",
        )

        foreign_keys = {}

        for row in cursor.fetchall():
            (
                fk_id, fk_name, parent_schema, metadata_parent,
                parent_column, child_schema, child_table,
                child_column, ordinal,
            ) = row

            fk = foreign_keys.setdefault(
                fk_id,
                {
                    "name": fk_name,
                    "parent_schema": parent_schema,
                    "child_schema": child_schema,
                    "child_table": child_table,
                    "pairs": [],
                },
            )
            fk["pairs"].append((parent_column, child_column))

        for fk in foreign_keys.values():
            if fk["parent_schema"] != "dbo":
                raise RuntimeError(
                    f"Unexpected parent schema for FK {fk['name']}"
                )

            child_schema = fk["child_schema"]
            child_table = fk["child_table"]

            join_conditions = " AND ".join(
                f"c.{_quote_identifier(child_col)} = "
                f"p.{_quote_identifier(parent_col)}"
                for parent_col, child_col in fk["pairs"]
            )

            included_child = (
                child_schema == "dbo"
                and child_table in TABLES
            )

            external_filter = ""

            if included_child:
                child_pk = TABLES[child_table][0]
                external_filter = """
                    AND NOT EXISTS (
                        SELECT 1
                        FROM #archive_group_ids AS gc
                        WHERE gc.table_name = ?
                          AND gc.record_id = c.CHILD_PK_PLACEHOLDER
                    )
                """.replace(
                    "c.CHILD_PK_PLACEHOLDER",
                    f"c.{_quote_identifier(child_pk)}",
                )

            sql = f"""
                SELECT TOP (1) 1
                FROM {_quote_identifier(child_schema)}.
                     {_quote_identifier(child_table)} AS c
                     WITH (UPDLOCK, HOLDLOCK)
                JOIN dbo.{_quote_identifier(parent_table)} AS p
                     WITH (UPDLOCK, HOLDLOCK)
                  ON {join_conditions}
                JOIN #archive_group_ids AS gp
                  ON gp.table_name = ?
                 AND gp.record_id = p.{_quote_identifier(parent_pk)}
                WHERE 1 = 1
                {external_filter}
            """

            params = [parent_table]

            if included_child:
                params.append(child_table)

            cursor.execute(sql, tuple(params))

            if cursor.fetchone() is not None:
                raise RuntimeError(
                    "Archive blocked: a live FK-dependent row would "
                    f"be left behind. FK={fk['name']}; "
                    f"child={child_schema}.{child_table}"
                )


def _check_eligibility(cursor, group):
    """Enforce event age, incident closure, investigation and hold rules."""
    event_ids = group["access_events"]
    incident_ids = group["incidents"]

    if not event_ids or not incident_ids:
        raise ValueError("Evidence group is incomplete")

    if (
        len(event_ids) > MAX_IN_CLAUSE_IDS
        or len(incident_ids) > MAX_IN_CLAUSE_IDS
    ):
        raise RuntimeError("Safety stop: eligibility group is too large")

    event_placeholders = ",".join("?" for _ in event_ids)

    cursor.execute(
        f"""
        SELECT COUNT_BIG(*)
        FROM dbo.access_events
        WHERE event_id IN ({event_placeholders})
          AND event_timestamp < DATEADD(HOUR, -24, SYSDATETIME())
        """,
        tuple(event_ids),
    )

    if cursor.fetchone()[0] != len(event_ids):
        raise ValueError(
            "At least one event is missing or is not older than 24 hours"
        )
    
    # Every alert in the evidence group must be closed.
    alert_ids = group["security_alerts"]

    if not alert_ids:
        raise ValueError("Evidence group contains no alerts")

    alert_placeholders = ",".join("?" for _ in alert_ids)

    cursor.execute(
        f"""
        SELECT COUNT_BIG(*)
        FROM dbo.security_alerts
        WHERE alert_id IN ({alert_placeholders})
          AND status NOT IN ('RESOLVED', 'FALSE_POSITIVE')
        """,
        tuple(alert_ids),
    )

    if cursor.fetchone()[0] != 0:
        raise ValueError(
            "Archive blocked: one or more linked alerts "
            "are not closed"
        )

    # Every linked incident must have been resolved after
    # its source event occurred.
    incident_placeholders = ",".join(
        "?" for _ in incident_ids
    )

    cursor.execute(
        f"""
        SELECT COUNT_BIG(*)
        FROM dbo.incidents AS i
        JOIN dbo.security_alerts AS a
          ON a.alert_id = i.source_alert_id
        JOIN dbo.access_events AS e
          ON e.event_id = a.event_id
        WHERE i.incident_id IN ({incident_placeholders})
          AND (
              i.resolved_at IS NULL
              OR e.event_timestamp > i.resolved_at
          )
        """,
        tuple(incident_ids),
    )

    if cursor.fetchone()[0] != 0:
        raise ValueError(
            "Archive blocked: an incident was resolved "
            "before its source event occurred"
        )
    incident_placeholders = ",".join("?" for _ in incident_ids)

    cursor.execute(
        f"""
        SELECT COUNT_BIG(*)
        FROM dbo.incidents AS i
        WHERE i.incident_id IN ({incident_placeholders})
          AND (
              ISNULL(i.status, '') <> 'RESOLVED'
              OR i.resolved_at IS NULL
              OR i.resolved_at > DATEADD(
                  DAY, -7, SYSDATETIME()
              )
              OR NOT EXISTS (
                  SELECT 1
                  FROM dbo.investigations AS inv
                  WHERE inv.incident_id = i.incident_id
                    AND inv.status = 'COMPLETED'
                    AND inv.completed_at IS NOT NULL
                    AND inv.completed_at >= i.resolved_at
              )
              OR EXISTS (
                  SELECT 1
                  FROM dbo.investigations AS inv
                  WHERE inv.incident_id = i.incident_id
                    AND (
                        ISNULL(inv.status, '') <> 'COMPLETED'
                        OR inv.completed_at IS NULL
                        OR inv.completed_at < i.resolved_at
                    )
              )
          )
        """,
        tuple(incident_ids),
    )

    if cursor.fetchone()[0] != 0:
        raise ValueError(
            "At least one connected incident fails the strict "
            "eligibility rules; the entire group must remain live"
        )

    # No formal evidence-group ID convention has been established.
    # Therefore any active evidence-group hold blocks archiving.
        # EVIDENCE_GROUP holds are anchored to an incident ID.
    # Only holds matching an incident in this group block archiving.
    # Unknown group identifiers fail closed.

    cursor.execute(
        """
        SELECT hold_id, record_type, record_id
        FROM dbo.archive_holds WITH (UPDLOCK, HOLDLOCK)
        WHERE hold_status = 'ACTIVE'
          AND scope_type = 'EVIDENCE_GROUP'
        """
    )

    active_group_holds = cursor.fetchall()
    group_incident_ids = set(incident_ids)
    matching_group_holds = []
    unrecognized_group_holds = []

    for hold_id, record_type, record_id in active_group_holds:
        normalized_type = (record_type or "").strip().lower()

        if normalized_type not in {"incident", "incidents"}:
            unrecognized_group_holds.append(hold_id)
        elif record_id in group_incident_ids:
            matching_group_holds.append(hold_id)

    if unrecognized_group_holds:
        raise ValueError(
            "Archive blocked: evidence-group hold(s) have an "
            "unrecognized group identifier: "
            f"{unrecognized_group_holds}."
        )

    if matching_group_holds:
        raise ValueError(
            "Archive blocked by matching evidence-group hold(s): "
            f"{matching_group_holds}."
        )

    # Check record-level holds for every member of the group.
    for table, ids in group.items():
        if not ids:
            continue

        aliases = sorted(HOLD_ALIASES[table])
        type_placeholders = ",".join("?" for _ in aliases)
        id_placeholders = ",".join("?" for _ in ids)

        cursor.execute(
            f"""
            SELECT COUNT_BIG(*)
            FROM dbo.archive_holds
            WHERE hold_status = 'ACTIVE'
              AND scope_type = 'RECORD'
              AND LOWER(record_type) IN ({type_placeholders})
              AND record_id IN ({id_placeholders})
            """,
            tuple(aliases) + tuple(ids),
        )

        if cursor.fetchone()[0] != 0:
            raise ValueError(
                f"Active record hold found for {table}"
            )




def _archive_table(cursor, table, ids):
    """Copy and verify archive rows without deleting live data."""
    if not ids:
        return

    if table not in TABLES:
        raise RuntimeError(f"Unknown archive table: {table}")

    pk, archive_table = TABLES[table]
    placeholders = ",".join("?" for _ in ids)

    cursor.execute(
        f"""
        SELECT COUNT_BIG(*)
        FROM dbo.[{table}] WITH (UPDLOCK, HOLDLOCK)
        WHERE [{pk}] IN ({placeholders})
        """,
        tuple(ids),
    )
    if cursor.fetchone()[0] != len(ids):
        raise RuntimeError(f"{table}: source row count changed")

    cursor.execute(
        """
        SELECT name
        FROM sys.columns
        WHERE object_id = OBJECT_ID(?)
        ORDER BY column_id
        """,
        f"dbo.{table}",
    )
    source_columns = [row[0] for row in cursor.fetchall()]

    cursor.execute(
        """
        SELECT name
        FROM sys.columns
        WHERE object_id = OBJECT_ID(?)
        """,
        f"dbo.{archive_table}",
    )
    archive_columns = {row[0] for row in cursor.fetchall()}

    if not source_columns or pk not in source_columns:
        raise RuntimeError(f"{table}: source primary key is missing")

    missing = set(source_columns) - archive_columns
    if missing:
        raise RuntimeError(
            f"{archive_table}: missing columns {sorted(missing)}"
        )

    data_columns = [
        name for name in source_columns
        if name not in {"archived_at", "purge_eligible_at"}
    ]
    column_list = ", ".join(f"[{name}]" for name in data_columns)

    cursor.execute(
        f"""
        SELECT [{pk}]
        FROM dbo.[{archive_table}] WITH (UPDLOCK, HOLDLOCK)
        WHERE [{pk}] IN ({placeholders})
        """,
        tuple(ids),
    )
    existing_ids = {row[0] for row in cursor.fetchall()}

    if existing_ids:
        raise RuntimeError(
            f"{table}: IDs already archived: {sorted(existing_ids)}"
        )

    # Use one timestamp for both archive metadata fields.
    cursor.execute(
        f"""
        DECLARE @archived_at datetime2(7) = SYSDATETIME();

        INSERT INTO dbo.[{archive_table}]
            ({column_list}, [archived_at], [purge_eligible_at])
        SELECT
            {column_list},
            @archived_at,
            DATEADD(MONTH, 18, @archived_at)
        FROM dbo.[{table}] WITH (UPDLOCK, HOLDLOCK)
        WHERE [{pk}] IN ({placeholders});
        """,
        tuple(ids),
    )

    cursor.execute(
        f"""
        SELECT COUNT_BIG(*)
        FROM (
            SELECT {column_list}
            FROM dbo.[{table}]
            WHERE [{pk}] IN ({placeholders})
            EXCEPT
            SELECT {column_list}
            FROM dbo.[{archive_table}]
            WHERE [{pk}] IN ({placeholders})
        ) AS differences
        """,
        tuple(ids) + tuple(ids),
    )
    source_differences = cursor.fetchone()[0]

    cursor.execute(
        f"""
        SELECT COUNT_BIG(*)
        FROM (
            SELECT {column_list}
            FROM dbo.[{archive_table}]
            WHERE [{pk}] IN ({placeholders})
            EXCEPT
            SELECT {column_list}
            FROM dbo.[{table}]
            WHERE [{pk}] IN ({placeholders})
        ) AS differences
        """,
        tuple(ids) + tuple(ids),
    )
    archive_differences = cursor.fetchone()[0]

    cursor.execute(
        f"""
        SELECT [{pk}]
        FROM dbo.[{archive_table}] WITH (HOLDLOCK)
        WHERE [{pk}] IN ({placeholders})
        """,
        tuple(ids),
    )
    copied_ids = {row[0] for row in cursor.fetchall()}

    if (
        source_differences
        or archive_differences
        or copied_ids != set(ids)
    ):
        raise RuntimeError(
            f"{table}: archive verification failed; "
            f"source_differences={source_differences}, "
            f"archive_differences={archive_differences}, "
            f"ids_match={copied_ids == set(ids)}"
        )



def _write_archive_audit(
    cursor,
    incident_id,
    actor_user_id,
    outcome,
    details,
    actor_source=None,
    actor_external_user_id=None,
    actor_display_name=None,
):
    """Insert an archive audit row and return its operation_id."""
    if outcome not in {"STARTED", "SUCCEEDED", "FAILED", "BLOCKED"}:
        raise ValueError(f"Invalid audit outcome: {outcome}")

    cursor.execute("""
        SELECT COLUMNPROPERTY(
            OBJECT_ID('dbo.archive_operation_audit'),
            'audit_id',
            'IsIdentity'
        )
    """)
    identity_value = cursor.fetchone()[0]

    if identity_value not in (0, 1):
        raise RuntimeError(
            "Cannot verify archive audit ID configuration"
        )

    external_user_id = (
        str(actor_external_user_id)
        if actor_external_user_id is not None
        else None
    )
    details_value = details[:4000] if details else None

    values = (
    incident_id,
    actor_user_id,
    actor_source,
    external_user_id,
    actor_display_name,
    outcome,
    outcome,
    details_value,
)

    if identity_value == 1:
        cursor.execute("""
            INSERT INTO dbo.archive_operation_audit
            (
                incident_id,
                actor_user_id,
                actor_source,
                actor_external_user_id,
                actor_display_name,
                operation_type,
                outcome,
                finished_at,
                details
            )
            OUTPUT INSERTED.operation_id
            VALUES (
                ?, ?, ?, ?, ?, 'ARCHIVE', ?,
                CASE WHEN ? = 'STARTED'
                     THEN NULL ELSE SYSDATETIME() END,
                ?
            )
        """, values)
    else:
        cursor.execute("""
            DECLARE @next_id bigint;

            SELECT @next_id = ISNULL(MAX(audit_id), 0) + 1
            FROM dbo.archive_operation_audit
                WITH (UPDLOCK, HOLDLOCK);

            INSERT INTO dbo.archive_operation_audit
            (
                audit_id,
                incident_id,
                actor_user_id,
                actor_source,
                actor_external_user_id,
                actor_display_name,
                operation_type,
                outcome,
                finished_at,
                details
            )
            OUTPUT INSERTED.operation_id
            VALUES (
                @next_id, ?, ?, ?, ?, ?, 'ARCHIVE', ?,
                CASE WHEN ? = 'STARTED'
                     THEN NULL ELSE SYSDATETIME() END,
                ?
            );
        """, values)

    row = cursor.fetchone()
    if row is None or row[0] is None:
        raise RuntimeError(
            "Archive audit insert did not return operation_id"
        )

    return row[0]

def _start_archive_audit(
    incident_id,
    actor_user_id,
    actor_source=None,
    actor_external_user_id=None,
    actor_display_name=None,
):
    """Commit STARTED separately and return its operation ID."""
    connection = None
    cursor = None

    try:
        connection = get_archive_connection()
        connection.autocommit = False
        cursor = connection.cursor()

        _require_dev(cursor)
        _require_dev_analyst(cursor, actor_user_id)

        operation_id = _write_archive_audit(
            cursor,
            incident_id,
            actor_user_id,
            "STARTED",
            "Archive operation started.",
            actor_source=actor_source,
            actor_external_user_id=actor_external_user_id,
            actor_display_name=actor_display_name,
        )

        connection.commit()
        return operation_id

    except Exception:
        if connection is not None:
            connection.rollback()
        raise

    finally:
        if cursor is not None:
            cursor.close()
        if connection is not None:
            connection.close()

def _record_failure(operation_id, details):
    """Update the existing audit operation after transaction rollback."""
    connection = None
    cursor = None

    try:
        connection = get_archive_connection()
        connection.autocommit = False
        cursor = connection.cursor()

        _require_dev(cursor)

        cursor.execute(
            """
            UPDATE dbo.archive_operation_audit
            SET outcome = 'FAILED',
                finished_at = SYSDATETIME(),
                details = ?
            WHERE operation_id = ?
              AND operation_type = 'ARCHIVE'
              AND outcome = 'STARTED'
            """,
            (details[:4000] if details else None, operation_id),
        )

        if cursor.rowcount != 1:
            raise RuntimeError(
                "Could not update the existing archive audit to FAILED."
            )

        connection.commit()

    except Exception:
        if connection is not None:
            try:
                connection.rollback()
            except Exception:
                pass
        raise

    finally:
        if cursor is not None:
            cursor.close()
        if connection is not None:
            connection.close()
            
def _require_dev_analyst(cursor, actor_user_id):
    """Require an active Security Analyst in AEGIS_DB."""
    if actor_user_id is None:
        raise RuntimeError(
            "Archive blocked: a Dev-local analyst is required."
        )

    cursor.execute(
        """
        SELECT u.user_id
        FROM dbo.users AS u
        INNER JOIN dbo.roles AS r
            ON r.role_id = u.role_id
        WHERE u.user_id = ?
          AND LOWER(LTRIM(RTRIM(r.role_name))) = 'security analyst'
          AND UPPER(LTRIM(RTRIM(u.status))) = 'ACTIVE'
        """,
        actor_user_id,
    )

    if cursor.fetchone() is None:
        raise RuntimeError(
            "Archive blocked: account is not an active "
            "Security Analyst in AEGIS_DB."
        )

def archive_incident_group(
    incident_id,
    execute=False,
    actor_user_id=None,
    actor_source=None,
    actor_external_user_id=None,
    actor_display_name=None,
):
    """
    Dry-run by default.

    Execution is blocked unless the explicit module safety gate is
    enabled after code review and server-side authorization integration.
    """
    connection = get_archive_connection()
    connection.autocommit = False
    cursor = connection.cursor()

    operation_started = False

    try:
        _require_dev(cursor)

        cursor.execute(
            "SET TRANSACTION ISOLATION LEVEL SERIALIZABLE"
        )
        cursor.execute("SET XACT_ABORT ON")

        group = _discover_group(cursor, incident_id)

        _check_live_foreign_key_dependencies(cursor, group)

        try:
          _check_eligibility(cursor, group)
          print("ELIGIBILITY: PASS")
        except (ValueError, RuntimeError) as exc:
             print(f"ELIGIBILITY: BLOCKED — {exc}")
             raise

        report = {
            "database": "AEGIS_DB",
            "incident_id": incident_id,
            "records": {
                table: len(ids) for table, ids in group.items()
            },
            "mode": "DRY RUN",
        }

        if not execute:
            return report

        if not ARCHIVE_EXECUTION_ENABLED:
            raise RuntimeError(
                "Archive execution is disabled. Do not enable it "
                "until authorization and transaction tests are complete."
            )
        
        if actor_user_id is None:
            raise RuntimeError(
                "Execution requires an authenticated Security Analyst."
            )
        _require_dev_analyst(cursor, actor_user_id)

        # IMPORTANT: actor_user_id is not authentication.
        # The calling Flask route must independently validate the
        # current session, active account, role, and CSRF token.
        operation_id = _start_archive_audit(
            incident_id,
            actor_user_id,
            actor_source=actor_source,
            actor_external_user_id=actor_external_user_id,
            actor_display_name=actor_display_name,
        )
        if operation_id is None:
           raise RuntimeError("Archive audit did not return an operation ID.")

        operation_started = True

        for table in COPY_ORDER:
            _archive_table(cursor, table, group[table])

        # Verify all expected IDs exist in the archive before deletion.
        for table, (pk, archive_table) in TABLES.items():
            ids = group[table]

            if not ids:
                continue

            placeholders = ",".join("?" for _ in ids)

            cursor.execute(
                f"""
                SELECT COUNT_BIG(*)
                FROM dbo.[{archive_table}] WITH (HOLDLOCK)
                WHERE [{pk}] IN ({placeholders})
                """,
                tuple(ids),
            )

            if cursor.fetchone()[0] != len(ids):
                raise RuntimeError(
                    f"Final archive verification failed for {table}"
                )

        # Delete children before parents, within this transaction.
        for table in DELETE_ORDER:
            ids = group[table]

            if not ids:
                continue

            pk, _ = TABLES[table]
            placeholders = ",".join("?" for _ in ids)

            cursor.execute(
                f"""
                DELETE FROM dbo.[{table}]
                WHERE [{pk}] IN ({placeholders})
                """,
                tuple(ids),
            )

            if cursor.rowcount != len(ids):
                raise RuntimeError(
                    f"{table}: live deletion count mismatch"
                )

        cursor.execute(
            """
            UPDATE dbo.archive_operation_audit
            SET outcome = 'SUCCEEDED',
                finished_at = SYSDATETIME(),
                details = ?
            WHERE operation_id = ?
  AND operation_type = 'ARCHIVE'
  AND outcome = 'STARTED'
            """,
            (
                (
                    "Evidence group archived and verified. "
                    f"Record counts: {report['records']}"
                )[:4000],
                operation_id,
            ),
        )

        if cursor.rowcount != 1:
            raise RuntimeError("Final audit update failed")

        connection.commit()

        report["mode"] = "COMMITTED"
        return report

    except Exception as exc:
        try:
            connection.rollback()
        except Exception:
            import logging
            logging.getLogger(__name__).exception(
                "Archive transaction rollback failed."
            )

        if execute and operation_started:
            try:
                _record_failure(
                operation_id,
                f"Archive operation failed and was rolled back: {exc}",
)
            except Exception:
                import logging
                logging.getLogger(__name__).exception(
                    "CRITICAL: Archive operation failed and its "
                    "separate FAILED audit could not be confirmed."
                )

        raise

    finally:
        cursor.close()
        connection.close()


if __name__ == "__main__":
    # Always preview here. Never set execute=True in this entry point.
    result = archive_incident_group(1, execute=False)

    print("\n=== AEGIS TRANSACTIONAL ARCHIVE PREVIEW ===")
    print(f"Database: {result['database']}")
    print(f"Incident: {result['incident_id']}")
    print(f"Mode: {result['mode']}")

    for table, count in result["records"].items():
        print(f"{table}: {count}")

    print("\nREAD-ONLY: no records were changed.")