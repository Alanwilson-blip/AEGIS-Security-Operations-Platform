import pyodbc


# =========================================================
# AEGIS SQL SERVER DATABASE CONFIGURATION
# =========================================================

SERVER = r"MR\SQLEXPRESS"
DATABASE = "AEGIS_DB"


# =========================================================
# DATABASE CONNECTION
# =========================================================

def get_connection():
    """
    Creates and returns a connection to the AEGIS SQL Server
    database using Windows Authentication.
    """

    connection_string = (
        "DRIVER={ODBC Driver 18 for SQL Server};"
        f"SERVER={SERVER};"
        f"DATABASE={DATABASE};"
        "Trusted_Connection=yes;"
        "TrustServerCertificate=yes;"
    )

    return pyodbc.connect(connection_string)


# =========================================================
# CONNECTION TEST
# =========================================================

def test_connection():

    connection = None
    cursor = None

    try:

        connection = get_connection()
        cursor = connection.cursor()

        cursor.execute("""
            SELECT
                DB_NAME() AS database_name,
                @@SERVERNAME AS server_name
        """)

        row = cursor.fetchone()

        print()
        print("==========================================")
        print("        AEGIS DATABASE CONNECTION")
        print("==========================================")
        print("Server   :", row.server_name)
        print("Database :", row.database_name)
        print("Status   : CONNECTED")
        print("==========================================")
        print()

        return True

    except Exception as e:

        print()
        print("==========================================")
        print("        AEGIS DATABASE CONNECTION")
        print("==========================================")
        print("Status   : FAILED")
        print()
        print("Error:")
        print(e)
        print("==========================================")
        print()

        return False

    finally:

        if cursor:
            cursor.close()

        if connection:
            connection.close()


# =========================================================
# RUN DIRECTLY
# =========================================================

if __name__ == "__main__":
    test_connection()