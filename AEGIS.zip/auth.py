"""AEGIS session authentication for active Security Analyst accounts."""
import os
import secrets

import pyotp
from cryptography.fernet import Fernet, InvalidToken
from dotenv import load_dotenv
from flask import flash, redirect, render_template, request, session, url_for
from werkzeug.security import check_password_hash

from database import get_connection

load_dotenv()
ANALYST_ROLE_ID = 51


def register_auth(app):
    app.config["SESSION_COOKIE_HTTPONLY"] = True
    app.config["SESSION_COOKIE_SAMESITE"] = "Lax"

    @app.before_request
    def require_analyst_session():
        if request.endpoint in ("login", "static"):
            return None
        user_id = session.get("user_id")
        if not user_id:
            return redirect(url_for("login", next=request.path))

        connection = cursor = None
        try:
            connection = get_connection()
            cursor = connection.cursor()
            cursor.execute("""
                SELECT u.user_id, u.full_name, u.status, u.role_id, r.role_name
                FROM dbo.users u
                LEFT JOIN dbo.roles r ON r.role_id = u.role_id
                WHERE u.user_id = ?
            """, (user_id,))
            account = cursor.fetchone()
            if (not account
                    or str(account[2]).strip().upper() != "ACTIVE"
                    or account[3] != ANALYST_ROLE_ID
                    or str(account[4] or "").strip().casefold() != "security analyst"):
                session.clear()
                return redirect(url_for("login"))
            session["user_name"] = account[1]
        except Exception:
            app.logger.exception("Could not verify the authenticated analyst.")
            return "Authentication verification is temporarily unavailable.", 503
        finally:
            if cursor is not None:
                cursor.close()
            if connection is not None:
                connection.close()
        return None

    @app.after_request
    def prevent_sensitive_page_caching(response):
        response.headers["Cache-Control"] = (
            "no-store, no-cache, must-revalidate, private"
        )
        response.headers["Pragma"] = "no-cache"
        response.headers["Expires"] = "0"
        return response

    def login():
        if request.method == "GET" and session.get("user_id"):
            return redirect(url_for("home"))
        if request.method == "GET" and not session.get("action_csrf_token"):
            session["action_csrf_token"] = secrets.token_urlsafe(32)

        if request.method == "POST":
            submitted = request.form.get("csrf_token", "")
            expected = session.get("action_csrf_token", "")
            if not submitted or not expected or not secrets.compare_digest(submitted, expected):
                flash("Security token expired. Refresh the page and try again.", "error")
                return render_template("login.html"), 400

            email = request.form.get("email", "").strip()
            password = request.form.get("password", "")
            otp = request.form.get("otp", "").strip()
            if not email or not password or not otp:
                flash("Enter your email, password, and authenticator code.", "error")
                return render_template("login.html"), 400

            connection = cursor = None
            try:
                connection = get_connection()
                cursor = connection.cursor()
                cursor.execute("""
                    SELECT u.user_id, u.full_name, u.status, u.role_id,
                           u.password_hash, u.mfa_enabled, u.totp_secret_encrypted,
                           r.role_name
                    FROM dbo.users u
                    LEFT JOIN dbo.roles r ON r.role_id = u.role_id
                    WHERE LOWER(u.email) = LOWER(?)
                """, (email,))
                account = cursor.fetchone()

                if (not account
                        or str(account[2]).strip().upper() != "ACTIVE"
                        or account[3] != ANALYST_ROLE_ID
                        or str(account[7] or "").strip().casefold() != "security analyst"
                        or not account[4] or not account[5] or not account[6]
                        or not check_password_hash(account[4], password)):
                    flash("Login failed. Check your credentials and account access.", "error")
                    return render_template("login.html"), 401

                encryption_key = os.getenv("AEGIS_TOTP_ENCRYPTION_KEY")
                if not encryption_key:
                    app.logger.error("AEGIS_TOTP_ENCRYPTION_KEY is not configured.")
                    return "Authentication configuration error.", 503
                try:
                    secret = Fernet(encryption_key.encode()).decrypt(
                        account[6].encode()
                    ).decode()
                except (InvalidToken, ValueError, TypeError):
                    app.logger.exception("Stored TOTP secret could not be decrypted.")
                    return "Authentication configuration error.", 503

                if not otp.isdigit() or len(otp) != 6 or not pyotp.TOTP(secret).verify(otp, valid_window=1):
                    flash("Login failed. Check your credentials and account access.", "error")
                    return render_template("login.html"), 401

                # Rotate session state after successful password + MFA verification.
                session.clear()
                session["user_id"] = int(account[0])
                session["role_id"] = int(account[3])
                session["user_name"] = account[1]
                session["action_csrf_token"] = secrets.token_urlsafe(32)
                destination = request.args.get("next", "")
                if not destination.startswith("/") or destination.startswith("//"):
                    destination = url_for("home")
                return redirect(destination)
            except Exception:
                app.logger.exception("Login processing failed.")
                return "Login service is temporarily unavailable.", 503
            finally:
                if cursor is not None:
                    cursor.close()
                if connection is not None:
                    connection.close()

        return render_template("login.html")

    def logout():
        submitted = request.form.get("csrf_token", "")
        expected = session.get("action_csrf_token", "")
        if not submitted or not expected or not secrets.compare_digest(submitted, expected):
            return "Invalid security token.", 400
        session.clear()
        return redirect(url_for("login"))

    app.add_url_rule("/login", endpoint="login", view_func=login, methods=["GET", "POST"])
    app.add_url_rule("/logout", endpoint="logout", view_func=logout, methods=["POST"])
