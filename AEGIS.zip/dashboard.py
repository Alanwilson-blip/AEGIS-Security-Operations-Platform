from database import get_connection
from flask import Flask, render_template, request, redirect, url_for, make_response, jsonify, flash
from flask import jsonify
from auth import register_auth
from archive_transaction import archive_incident_group
from detection_engine import (
    record_investigation_action,
    enforce_access,
    run_d01_d13_detections,
    detect_d14_high_risk_access,
    aggregate_risk_score,
    create_security_alert,
    create_incident_from_alert,
    create_investigation_from_incident
)
from storage.storage_manager import (
    load_all,
    save_all,
    get_all_settings,
    set_setting
)
from app import approve_device, block_device
from datetime import datetime,  timedelta
from database_queries import get_user_details
import io
import csv


from database_queries import (
    get_dashboard_summary,
    get_alert_summary,
    get_open_alert_count,
    get_denied_access_count,
    get_device_security_summary,
    get_employee_work_status,

    get_department_summary,
    get_high_risk_users,
    get_recent_alerts,
    get_today_dashboard_data,
    get_today_security_activity,
    get_incident_details,
    get_incidents_queue,
    get_investigation_details,
    get_investigations_queue,
    get_investigation_events,
    get_investigation_event_details,
    escalate_incident_to_investigation,
    get_investigation_filter_options,

    get_device_inventory,
    get_device_details,
    get_reports_data,
  
)
from analyzer.statistics import (
    count_devices,
    calculate_average_trust,
    count_incidents_by_severity,
    find_most_targeted_user,
    count_investigation_decisions
)

import os

app = Flask(__name__)

app.secret_key = os.environ.get("AEGIS_SECRET_KEY")

import secrets
from flask import session

if not app.secret_key:
    raise RuntimeError(
        "AEGIS_SECRET_KEY environment variable is not configured."
    )

@app.context_processor
def inject_action_csrf_token():
    if "action_csrf_token" not in session:
        session["action_csrf_token"] = secrets.token_urlsafe(32)

    return {
        "action_csrf_token": session["action_csrf_token"]
    }
register_auth(app)

# =========================================================
# AEGIS LOG INGESTION
# LOG → ACCESS EVENT → DETECTION → ALERT → INCIDENT
#       → INVESTIGATION
# =========================================================

@app.route("/api/ingest-log", methods=["POST"])
def ingest_log():

    data = request.get_json(silent=True)

    if not data:
        return jsonify({
            "success": False,
            "error": "JSON request body required."
        }), 400

    required_fields = [
    "user_id",
    "event_type",
    "action",
    "source_ip",
    "location"
]

    missing = [
        field for field in required_fields
        if field not in data
    ]

    if missing:
        return jsonify({
            "success": False,
            "error": "Missing required fields.",
            "missing": missing
        }), 400

    connection = None
    cursor = None

    try:
        connection = get_connection()
        cursor = connection.cursor()

        user_id = int(data["user_id"])
        event_type = str(data["event_type"]).strip().upper()
        action = str(data["action"]).strip().upper()
        source_ip = data.get("source_ip")
        location = data.get("location")
        device_id = data.get("device_id")
        resource_id = data.get("resource_id")
        user_agent = data.get("user_agent")
        auth_method = data.get("auth_method", "PASSWORD")

        current_vpn_state = bool(
            data.get("vpn_enabled", False)
        )

        event_timestamp = datetime.now()

        # -------------------------------------------------
        # 1. Get user's role
        # -------------------------------------------------

        cursor.execute("""
            SELECT role_id
            FROM users
            WHERE user_id = ?
        """, (user_id,))

        user_row = cursor.fetchone()

        if not user_row:
            return jsonify({
                "success": False,
                "error": f"User {user_id} not found."
            }), 404

        role_id = user_row.role_id

        # -------------------------------------------------
        # 2. Insert the raw security event
        # -------------------------------------------------

        # -------------------------------------------------
        # 2. Enforce access and create the access event
        # -------------------------------------------------

        access_result = enforce_access(
                user_id=user_id,
                resource_id=resource_id,
                action=action,
                device_id=device_id,
                source_ip=source_ip,
                location=location,
                auth_method=auth_method,
                user_agent=user_agent
            )

        if not access_result.get("event_id"):
                    return jsonify({
                        "success": False,
                        "error": access_result.get(
                            "reason",
                            "Access event was not created."
                        ),
                        "access": access_result
                    }), 400

        event_id = access_result["event_id"]

            # The enforcement result is authoritative.
        result = access_result["result"]

            # Detection functions query SQL, so commit first.
        connection.commit()

        # Get the actual persisted event details
        cursor = connection.cursor()

        cursor.execute("""
                    SELECT
                        event_timestamp,
                        role_id,
                        result
                    FROM access_events
                    WHERE event_id = ?
                """, (event_id,))

        event_row = cursor.fetchone()

        if not event_row:
                    raise RuntimeError(
                        f"Access event {event_id} could not be retrieved."
                    )

        event_timestamp = event_row[0]
        role_id = event_row[1]
        result = event_row[2]

                    # Commit the event first.
        #
        # The detection functions query access_events,
        # so the new event must exist in SQL before
        # detection runs.
        

        # -------------------------------------------------
        # 3. Run D01-D13
        # -------------------------------------------------

        detection_results = run_d01_d13_detections(
                user_id=user_id,
                device_id=device_id,
                role_id=role_id,
                resource_id=resource_id,
                event_type=event_type,
                action=action,
                event_timestamp=event_timestamp,
                result=result,
                location=location,
                current_vpn_state=current_vpn_state
            )

        # -------------------------------------------------
        # 4. Run D14
        # -------------------------------------------------

        # Start with the risk contributed by D01-D13.
        aggregated_result = aggregate_risk_score(
            detection_results
        )

        d14_result = detect_d14_high_risk_access(
            aggregated_result["risk_score"]
        )

        # -------------------------------------------------
        # 5. Update access_events with calculated risk
        # -------------------------------------------------

        final_risk_score = aggregated_result["risk_score"]

        cursor = connection.cursor()

        cursor.execute("""
            UPDATE access_events
            SET
                risk_score = ?
            WHERE event_id = ?
        """, (
            final_risk_score,
            event_id
        ))

        connection.commit()

        # -------------------------------------------------
        # 6. Create security alert when threshold is met
        # -------------------------------------------------

        alert_result = create_security_alert(
            event_id=event_id,
            user_id=user_id,
            aggregated_result=aggregated_result,
            d14_result=d14_result
        )

        incident_result = None
        investigation_result = None

        # -------------------------------------------------
        # 7. Create incident when risk >= 60
        # -------------------------------------------------

        if alert_result.get("created"):

            incident_result = create_incident_from_alert(
                alert_result["alert_id"]
            )

            # -------------------------------------------------
            # 8. Automatically create investigation
            # -------------------------------------------------

            if incident_result.get("created"):

                investigation_result = (
                    create_investigation_from_incident(
                        incident_result["incident_id"],
                        actor_user_id=None
                    )
                )

        return jsonify({
            "success": True,
            "event": {
                "event_id": event_id,
                "risk_score": final_risk_score
            },
            "detections": aggregated_result,
            "d14": d14_result,
            "alert": alert_result,
            "incident": incident_result,
            "investigation": investigation_result
        }), 201

    except Exception as exc:

        if connection:
            connection.rollback()

        app.logger.exception(
            "AEGIS log ingestion failed"
        )

        return jsonify({
            "success": False,
            "error": str(exc)
        }), 500

    finally:

        if cursor:
            cursor.close()

        if connection:
            connection.close()

@app.route("/")
def home():

  

    # ==========================================
    # AEGIS SQL SERVER DATA
    # ==========================================

    dashboard_summary = get_dashboard_summary()
    alert_summary = get_alert_summary()
    open_alerts = get_open_alert_count()
    denied_access = get_denied_access_count()
    device_security = get_device_security_summary()
    employee_work_status = get_employee_work_status()
    department_summary = get_department_summary()
    high_risk_users = get_high_risk_users()
    recent_alerts = get_recent_alerts(10)

    # ==========================================
    # REAL TODAY'S DATA FROM SQL SERVER
    # ==========================================

    today_sql = get_today_dashboard_data()

    events_today = today_sql["events_today"]
    incidents_today = today_sql["incidents_today"]
    unreviewed_today = today_sql["unreviewed_today"]
    resolved_today = today_sql["resolved_today"]

    critical_today = today_sql["critical_today"]
    high_today = today_sql["high_today"]
    medium_today = today_sql["medium_today"]
    low_today = today_sql["low_today"]
    detection_activity = today_sql["detection_activity"]

    # ==========================================
    # TODAY'S DATE
    # ==========================================

    today_date = datetime.now().strftime("%Y-%m-%d")

    # ==========================================
    # LEGACY DATA FOR EXISTING DASHBOARD SECTIONS
    # ==========================================


    today_events = get_today_security_activity(20)

    # ==========================================
    # RENDER DASHBOARD
    # ==========================================

    return render_template(
        "index.html",

        # --------------------------------------
        # REAL SQL SERVER TODAY VALUES
        # --------------------------------------

        today_date=today_date,

        events_today=events_today,
        incidents_today=incidents_today,
        unreviewed_today=unreviewed_today,
        resolved_today=resolved_today,

        critical_today=critical_today,
        high_today=high_today,
        medium_today=medium_today,
        low_today=low_today,
        detection_activity=detection_activity,
        # --------------------------------------
        # EXISTING DASHBOARD DATA
        # --------------------------------------


        today_events=today_events,

        dashboard_summary=dashboard_summary,
        employee_work_status=employee_work_status,
        alert_summary=alert_summary,
        open_alerts=open_alerts,
        denied_access=denied_access,
        device_security=device_security,
        department_summary=department_summary,
        high_risk_users=high_risk_users,
        recent_alerts=recent_alerts
    )
def incidents_page():

    (
       accounts,
       events,
       incidents,
       investigation_history,
       decision_log
    ) = load_all()
    # Read severity from URL:
    # /incidents?severity=HIGH
    selected_severity = request.args.get("severity")
    search_query = request.args.get("search", "").strip()
    selected_status = request.args.get("status", "").strip()
    # Keep original list for statistics
    all_incidents = incidents

    # Filter incidents if a severity was selected
    if selected_severity:

        selected_severity = selected_severity.strip().upper()

        incidents = [
           incident
           for incident in incidents
           if str(incident.get("severity", "")).strip().upper()
           == selected_severity.strip().upper()
]   
    if selected_status:

     incidents = [
        incident
        for incident in incidents
        if str(incident.get("status", "")).strip().lower()
        == selected_status.lower()
    ]
    if search_query:

     query = search_query.lower()

     incidents = [
        incident
        for incident in incidents
        if (
            query in str(
                incident.get("incident_id", "")
            ).lower()

            or query in str(
                incident.get("username", "")
            ).lower()

            or query in str(
                incident.get("event", "")
            ).lower()

            or query in str(
                incident.get("device", "")
            ).lower()

            or query in str(
                incident.get("ip_address", "")
            ).lower()
        )
    ]

    total_incidents = len(all_incidents)

    open_incidents = sum(
        1 for incident in all_incidents
        if incident.get("status") == "Open"
    )

    review_incidents = sum(
        1 for incident in all_incidents
        if incident.get("status") == "Under Review"
    )

    resolved_incidents = sum(
        1 for incident in all_incidents
        if incident.get("status") == "Resolved"
    )

    return render_template(
        "incidents.html",

        incidents=incidents,
        
        total_incidents=total_incidents,
        open_incidents=open_incidents,
        review_incidents=review_incidents,
        resolved_incidents=resolved_incidents,

        selected_severity=selected_severity,
        search_query=search_query,
        selected_status=selected_status,
        
    )
# =====================================================
# TODAY'S SECURITY ACTIVITY
# =====================================================

@app.route("/security-activity")
def security_activity_page():

    today_events = get_today_security_activity(100)

    return render_template(
        "security_activity.html",
        today_events=today_events
    )
@app.route("/incidents")
def incidents_page():

    incidents = get_incidents_queue()
    
    selected_severity = request.args.get("severity", "").strip()
    selected_status = request.args.get("status", "").strip()
    search_query = request.args.get("search", "").strip()

    # Severity filter
    if selected_severity:
        incidents = [
            incident for incident in incidents
            if str(incident.get("severity", "")).strip().upper()
            == selected_severity.upper()
        ]

    # Status filter
    if selected_status:
        incidents = [
            incident for incident in incidents
            if str(incident.get("status", "")).strip().lower()
            == selected_status.lower()
        ]

    # Search
    if search_query:

        query = search_query.lower()

        incidents = [
            incident for incident in incidents
            if (
                query in str(incident.get("incident_id", "")).lower()
                or query in str(incident.get("username", "")).lower()
                or query in str(incident.get("event", "")).lower()
                or query in str(incident.get("device", "")).lower()
                or query in str(incident.get("country", "")).lower()
                or query in str(incident.get("ip_address", "")).lower()
            )
        ]

    return render_template(
        "incidents.html",
        incidents=incidents,
        selected_severity=selected_severity,
        selected_status=selected_status,
        search_query=search_query
    )
# =========================================================
# AEGIS GLOBAL SEARCH
# =========================================================

@app.route("/api/global-search")
def global_search():

    query = request.args.get("q", "").strip()

    if len(query) < 1:
        return jsonify([])

    connection = get_connection()
    cursor = connection.cursor()

    results = []

    try:

        search = f"%{query}%"

        # -------------------------------------------------
        # USERS
        # -------------------------------------------------

        cursor.execute("""
            SELECT TOP 8
                u.user_id,
                u.full_name,
                u.employee_code,
                r.role_name,
                d.department_name
            FROM users u
            LEFT JOIN roles r
                ON u.role_id = r.role_id
            LEFT JOIN departments d
                ON r.department_id = d.department_id
            WHERE
                u.full_name LIKE ?
                OR u.employee_code LIKE ?
                OR u.email LIKE ?
                OR r.role_name LIKE ?
                OR d.department_name LIKE ?
            ORDER BY
                CASE
                    WHEN u.full_name LIKE ? THEN 0
                    WHEN u.employee_code LIKE ? THEN 1
                    ELSE 2
                END,
                u.full_name
        """, (
            search,
            search,
            search,
            search,
            search,
            f"{query}%",
            f"{query}%"
        ))

        for row in cursor.fetchall():

            results.append({
                "type": "user",
                "label": row[1],
                "meta": (
                    f"{row[2]} • "
                    f"{row[3] or 'No role'} • "
                    f"{row[4] or 'No department'}"
                ),
                "url": url_for(
    "users_page",
    search=row[1]
)
            })

        # -------------------------------------------------
        # DEVICES
        # -------------------------------------------------

        cursor.execute("""
            SELECT TOP 8
                ud.device_id,
                ud.device_name,
                ud.device_type,
                ud.operating_system,
                ud.ip_address
            FROM user_devices ud
            WHERE
                ud.device_name LIKE ?
                OR ud.device_type LIKE ?
                OR ud.operating_system LIKE ?
                OR ud.ip_address LIKE ?
            ORDER BY
                CASE
                    WHEN ud.device_name LIKE ? THEN 0
                    ELSE 1
                END,
                ud.device_name
        """, (
            search,
            search,
            search,
            search,
            f"{query}%"
        ))

        for row in cursor.fetchall():

            results.append({
                "type": "device",
                "label": row[1],
                "meta": (
                    f"{row[2] or 'Device'} • "
                    f"{row[3] or 'Unknown OS'} • "
                    f"{row[4] or 'No IP'}"
                ),
                "url": url_for(
                    "device_details",
                    device_id=row[0]
                )
            })

        # -------------------------------------------------
        # INCIDENTS
        # -------------------------------------------------

        cursor.execute("""
            SELECT TOP 8
                i.incident_id,
                i.title,
                i.incident_type,
                i.severity,
                i.status
            FROM incidents i
            WHERE
                CAST(i.incident_id AS VARCHAR(50)) LIKE ?
                OR i.title LIKE ?
                OR i.incident_type LIKE ?
                OR i.severity LIKE ?
                OR i.status LIKE ?
            ORDER BY
                CASE
                    WHEN i.title LIKE ? THEN 0
                    ELSE 1
                END,
                i.incident_id DESC
        """, (
            search,
            search,
            search,
            search,
            search,
            f"{query}%"
        ))

        for row in cursor.fetchall():

            results.append({
                "type": "incident",
                "label": row[1] or f"Incident #{row[0]}",
                "meta": (
                    f"INC-{row[0]:04d} • "
                    f"{row[2] or 'Incident'} • "
                    f"{row[3] or 'Unknown'} • "
                    f"{row[4] or 'Unknown'}"
                ),
                "url": url_for(
                    "incident_details",
                    incident_id=row[0]
                )
            })

        # -------------------------------------------------
        # DEPARTMENTS
        # -------------------------------------------------

        cursor.execute("""
            SELECT TOP 8
                d.department_id,
                d.department_name
            FROM departments d
            WHERE
                d.department_name LIKE ?
                OR d.description LIKE ?
            ORDER BY
                CASE
                    WHEN d.department_name LIKE ? THEN 0
                    ELSE 1
                END,
                d.department_name
        """, (
            search,
            search,
            f"{query}%"
        ))

        for row in cursor.fetchall():

            results.append({
                "type": "department",
                "label": row[1],
                "meta": "Department",
                "url": url_for(
                    "users_page",
                    department=row[1]
                )
            })

        # -------------------------------------------------
        # SECURITY ALERTS
        # -------------------------------------------------

        cursor.execute("""
            SELECT TOP 8
                sa.alert_id,
                sa.alert_type,
                sa.severity,
                sa.status,
                sa.description
            FROM security_alerts sa
            WHERE
                sa.alert_type LIKE ?
                OR sa.severity LIKE ?
                OR sa.status LIKE ?
                OR sa.description LIKE ?
            ORDER BY sa.created_at DESC
        """, (
            search,
            search,
            search,
            search
        ))

        for row in cursor.fetchall():

            results.append({
                "type": "alert",
                "label": row[1],
                "meta": (
                    f"Alert #{row[0]} • "
                    f"{row[2]} • "
                    f"{row[3]}"
                ),
                "url": url_for(
                    "investigations_page"
                )
            })

        # -------------------------------------------------
        # LIMIT TOTAL SUGGESTIONS
        # -------------------------------------------------

        return jsonify(results[:15])

    except Exception as e:

        print(
            f"Global search error: {e}"
        )

        return jsonify([]), 500

    finally:

        cursor.close()
        connection.close()
# =========================================================
# DASHBOARD CARD PAGES
# =========================================================

@app.route("/events")
def events_page():
    return render_template("events.html")


@app.route("/unreviewed")
def unreviewed_page():
    return render_template("unreviewed.html")


@app.route("/resolved")
def resolved_page():
    return render_template("resolved.html")

@app.route("/users")
def users_page():

    (
        accounts,
        events,
        incidents,
        investigation_history,
        decision_log
    ) = load_all()

    # =========================================
    # USER FILTERS
    # =========================================

    search_query = request.args.get(
        "search",
        ""
    ).strip().lower()

    selected_department = request.args.get(
        "department",
        ""
    ).strip()

    # =========================================
    # DEPARTMENT OPTIONS
    # =========================================

    departments = sorted({
        str(
            account.get(
                "department",
                "Unassigned"
            )
        ).strip()

        for account in accounts.values()
    })

    # =========================================
    # BUILD USER DIRECTORY
    # =========================================

    users = []

    for username, account in accounts.items():

        department = account.get(
            "department",
            "Unassigned"
        )

        role = account.get(
            "role",
            "Not Assigned"
        )

        # -----------------------------------------
        # DEPARTMENT FILTER
        # -----------------------------------------

        if (
            selected_department
            and department != selected_department
        ):
            continue

        # -----------------------------------------
        # SEARCH
        # -----------------------------------------

        if search_query:

            searchable = " ".join([
                str(username),
                str(department),
                str(role)
            ]).lower()

            if search_query not in searchable:
                continue

        # -----------------------------------------
        # DEVICE COUNTS
        # -----------------------------------------

        known_devices = account.get(
            "known_devices",
            {}
        )

        pending_devices = account.get(
            "pending_devices",
            {}
        )

        blocked_devices = account.get(
            "blocked_devices",
            {}
        )

        # -----------------------------------------
        # USER RECORD
        # -----------------------------------------

        users.append({

            "username": username,

            "department": department,

            "role": role,

            "failed_attempts": account.get(
                "failed_attempts",
                0
            ),

            "known_devices": len(
                known_devices
            ),

            "pending_devices": len(
                pending_devices
            ),

            "blocked_devices": len(
                blocked_devices
            ),

            "known_countries": len(
                account.get(
                    "known_countries",
                    set()
                )
            )
        })

    # =========================================
    # RENDER
    # =========================================

    return render_template(
        "users.html",

        users=users,

        departments=departments,

        search_query=search_query,

        selected_department=selected_department
    )
@app.route("/reports")
def reports_page():

    # =========================================
    # REPORT PERIOD
    # =========================================

    period = request.args.get(
        "period",
        "all"
    ).strip().lower()

    if period not in (
        "all",
        "30",
        "7",
        "today"
    ):
        period = "all"


    # =========================================
    # SQL SERVER REPORT DATA
    # =========================================

    reports = get_reports_data(period)

    if reports is None:
        return "Unable to load report data", 500


    # =========================================
    # RENDER REPORT
    # =========================================

    return render_template(
        "reports.html",

        period=reports["period"],

        summary=reports["summary"],

        severity=reports["severity"],

        status=reports["status"],

        incident_activity=reports["incident_activity"],

        incident_activity_by_severity=reports["incident_activity_by_severity"],

        top_users=reports["top_users"],

        top_devices=reports["top_devices"],

        device_posture=reports["device_posture"],

        detection_activity=reports["detection_activity"],

        event_activity=reports["event_activity"]
    )
@app.route("/reports/export")
def export_report():

    (
        accounts,
        events,
        incidents,
        investigation_history,
        decision_log
    ) = load_all()

    output = io.StringIO()

    writer = csv.writer(output)

    writer.writerow([
        "Timestamp",
        "Username",
        "Event",
        "Device",
        "Country",
        "Browser",
        "VPN",
        "Risk Score",
        "Severity",
        "Status"
    ])

    for incident in incidents:

        writer.writerow([
            incident.get("timestamp", ""),
            incident.get("username", ""),
            incident.get("event", ""),
            incident.get("device", ""),
            incident.get("country", ""),
            incident.get("browser", ""),
            incident.get("vpn", ""),
            incident.get("risk_score", ""),
            incident.get("severity", ""),
            incident.get("status", "")
        ])

    response = make_response(
        output.getvalue()
    )

    response.headers["Content-Disposition"] = (
        "attachment; filename=aegis_security_report.csv"
    )

    response.headers["Content-Type"] = "text/csv"

    return response

@app.route("/devices")
def devices_page():

    search_query = request.args.get(
        "search",
        ""
    ).strip()

    selected_posture = request.args.get(
        "posture",
        ""
    ).strip().upper()


    # =========================================
    # DEVICE INVENTORY FROM SQL SERVER
    # =========================================

    devices = get_device_inventory(

        search=search_query
        if search_query
        else None,

        posture=selected_posture
        if selected_posture
        else None

    )


    # =========================================
    # DEVICE SECURITY COUNTS
    # =========================================

    device_security = (
        get_device_security_summary()
    )


    return render_template(

        "devices.html",

        devices=devices,

        search_query=search_query,

        selected_posture=selected_posture,

        total_count=device_security[
            "total_devices"
        ],

        managed_count=device_security[
            "managed_devices"
        ],

        unmanaged_count=device_security[
            "unmanaged_devices"
        ],

        compliant_count=device_security[
            "compliant_devices"
        ],

        non_compliant_count=device_security[
            "non_compliant_devices"
        ]

    )
@app.route("/devices/<int:device_id>")
def device_details(device_id):

    device = get_device_details(device_id)

    if not device:
        return "Device not found", 404

    return render_template(
        "device_details.html",
        device=device,
        device_events=device.get("events", []),
        device_alerts=device.get("alerts", []),
        device_incidents=device.get("incidents", [])
    )
def archive_investigation(
    investigation_history,
    pending_device,
    username,
    device_name,
    decision
):
    investigation_history.append({

        "incident_id": pending_device.get(
            "incident_id"
        ),

        "username": username,

        "device": device_name,

        "administrator": "Web Administrator",

        "decision": decision,

        "decision_time": datetime.now().strftime(
            "%Y-%m-%d %H:%M:%S"
        ),

        "risk_score": pending_device.get(
            "risk_score",
            0
        ),

        "severity": pending_device.get(
            "severity",
            "LOW"
        ),

        "countries": pending_device.get(
            "countries",
            []
        ),

        "browsers": pending_device.get(
            "browsers",
            []
        ),

        "vpn_history": pending_device.get(
            "vpn_history",
            []
        ),

        "recommended_actions": pending_device.get(
            "recommended_actions",
            []
        ),

        "detection_reasons": pending_device.get(
            "detection_reasons",
            []
        )
    })


def log_decision(
    decision_log,
    pending_device,
    username,
    device_name,
    decision
):
    decision_log.append({

        "incident_id": pending_device.get(
            "incident_id"
        ),

        "username": username,

        "device": device_name,

        "decision": decision,

        "administrator": "Web Administrator",

        "decision_time": datetime.now().strftime(
            "%Y-%m-%d %H:%M:%S"
        )
    })



# ==========================================
# ESCALATE INVESTIGATION
# ==========================================

# =========================================================
# ESCALATE INCIDENT → SPECIFIC INVESTIGATION
# =========================================================

@app.route(
    "/incidents/<incident_id>/escalate",
    methods=["POST"]
)
def escalate_investigation(incident_id):

    try:
        incident_id = int(
            str(incident_id).replace("INC-", "")
        )
    except ValueError:
        return "Invalid incident ID", 400

    result = escalate_incident_to_investigation(
    incident_id,
    actor_user_id=session.get("user_id")
)

    if result is None:
        return "Incident or triggering event not found", 404

    return redirect(
    url_for(
        "investigation_record_detail",
        investigation_id=result["investigation_id"]
    )
)

@app.route(
    "/incident/<int:incident_id>/escalate",
    methods=["POST"]
)
def escalate_incident(incident_id):

    result = escalate_incident_to_investigation(
    incident_id,
    actor_user_id=session.get("user_id")
)

    if result is None:
        return (
            "Incident not found, triggering event missing, "
            "or incident is not eligible for escalation.",
            404
        )

    return redirect(
    url_for(
        "investigation_record_detail",
        investigation_id=result["investigation_id"]
    )
)

# =========================================================
# INVESTIGATION QUEUE
# TODAY'S HIGH / CRITICAL EVENTS ONLY
# =========================================================

@app.route("/investigations")
def investigations_page():

    selected_severity = request.args.get(
        "severity",
        ""
    ).strip().upper()

    selected_department = request.args.get(
        "department",
        ""
    ).strip()

    selected_event_type = request.args.get(
        "event_type",
        ""
    ).strip()

    selected_result = request.args.get(
        "result",
        ""
    ).strip().upper()

    search_query = request.args.get(
        "search",
        ""
    ).strip()

    investigation_events = get_investigation_events(
        severity=selected_severity or None,
        department=selected_department or None,
        event_type=selected_event_type or None,
        result=selected_result or None,
        search=search_query or None
    )

    departments, event_types = (
        get_investigation_filter_options()
    )

    return render_template(
        "investigations.html",

        investigation_events=investigation_events,

        departments=departments,

        event_types=event_types,

        selected_severity=selected_severity,

        selected_department=selected_department,

        selected_event_type=selected_event_type,

        selected_result=selected_result,

        search_query=search_query
    )
# =========================================================
# INVESTIGATION DETAIL
# =========================================================

@app.route("/investigation/<int:event_id>")
def investigation_detail(event_id):

    investigation = (
        get_investigation_event_details(
            event_id
        )
    )

    if investigation is None:
        return "Investigation event not found", 404

    
    action_history = []
    history_connection = None
    history_cursor = None

    try:
        history_connection = get_connection()
        history_cursor = history_connection.cursor()

        history_cursor.execute("""
            SELECT
                ia.action_type,
                ia.action_reason,
                ia.created_at,
                u.full_name
            FROM investigation_actions ia
            LEFT JOIN users u ON u.user_id = ia.actor_user_id
            WHERE ia.investigation_id = ?
            ORDER BY ia.created_at DESC, ia.action_id DESC
        """, (investigation_id,))

        action_history = [
            {
                "action_type": row[0],
                "action_reason": row[1],
                "created_at": row[2],
                "actor_name": row[3] or "Unknown analyst",
            }
            for row in history_cursor.fetchall()
        ]

    except Exception:
        app.logger.exception("Could not load investigation action history")

    finally:
        if history_cursor:
            history_cursor.close()
        if history_connection:
            history_connection.close()
    
    return render_template(
        "investigation_detail.html",
        investigation=investigation,
        action_history=action_history
    )


@app.route("/incident/<int:incident_id>/investigation")
def incident_investigation(incident_id):
    connection = None
    cursor = None

    try:
        connection = get_connection()
        cursor = connection.cursor()

        cursor.execute("""
            SELECT investigation_id
            FROM investigations
            WHERE incident_id = ?
        """, (incident_id,))

        row = cursor.fetchone()

        if row is None:
            return "Investigation record not found", 404

        investigation_id = row[0]

        return redirect(
            url_for(
                "investigation_record_detail",
                investigation_id=investigation_id
            )
        )

    except Exception as e:
        print(f"Error opening incident investigation: {e}")
        return "Failed to open investigation", 500

    finally:
        if cursor:
            cursor.close()
        if connection:
            connection.close()
@app.route("/investigation/record/<int:investigation_id>")
def investigation_record_detail(investigation_id):
    connection = None
    cursor = None

    try:
        connection = get_connection()
        cursor = connection.cursor()

        cursor.execute("""
            SELECT
                inv.investigation_id,
                inv.incident_id,
                inv.status AS investigation_status,
                inv.assigned_to,
                sa.event_id
            FROM investigations inv
            INNER JOIN incidents i
                ON inv.incident_id = i.incident_id
            INNER JOIN security_alerts sa
                ON i.source_alert_id = sa.alert_id
            WHERE inv.investigation_id = ?
        """, (investigation_id,))

        row = cursor.fetchone()

    except Exception as e:
        print(f"Error loading investigation record: {e}")
        return "Failed to load investigation", 500

    finally:
        if cursor:
            cursor.close()
        if connection:
            connection.close()

    if row is None:
        return "Investigation record not found", 404

    investigation = get_investigation_event_details(row[4])

    if investigation is None:
        return "Triggering event details not found", 404

    # Preserve the existing event and incident context.
    investigation["investigation_id"] = row[0]
    investigation["incident_id"] = row[1]
    investigation["investigation_status"] = row[2]
    investigation["assigned_to"] = row[3]


    action_history = []
    history_connection = None
    history_cursor = None

    try:
        history_connection = get_connection()
        history_cursor = history_connection.cursor()

        history_cursor.execute("""
            SELECT
                ia.action_type,
                ia.action_reason,
                ia.created_at,
                u.full_name
            FROM investigation_actions ia
            LEFT JOIN users u
                ON u.user_id = ia.actor_user_id
            WHERE ia.investigation_id = ?
            ORDER BY ia.created_at DESC, ia.action_id DESC
        """, (investigation_id,))

        action_history = [
            {
                "action_type": item[0],
                "action_reason": item[1],
                "created_at": item[2],
                "actor_name": item[3] or "Unknown analyst",
            }
            for item in history_cursor.fetchall()
        ]

    except Exception:
        app.logger.exception("Failed to load investigation action history")

    finally:
        if history_cursor:
            history_cursor.close()
        if history_connection:
            history_connection.close()

    return render_template(
        "investigation_detail.html",
        investigation=investigation,
        action_history=action_history
    )



@app.route(
    "/investigation/record/<int:investigation_id>/action",
    methods=["POST"]
)
def submit_investigation_action(investigation_id):
    submitted_token = request.form.get("csrf_token", "")
    session_token = session.get("action_csrf_token", "")

    # Validate CSRF token
    if (
        not submitted_token
        or not session_token
        or not secrets.compare_digest(submitted_token, session_token)
    ):
        flash(
            "Invalid security token. Refresh the page and try again.",
            "error"
        )
        return redirect(
            request.referrer or url_for("home")
        )

    # Use the authenticated analyst's identity
    actor_user_id = session.get("user_id")
    if not actor_user_id:
        return redirect(url_for("login"))

    action_type = request.form.get("action_type", "").strip().upper()
    action_reason = request.form.get("action_reason", "").strip()

    try:
        result = record_investigation_action(
            investigation_id=investigation_id,
            actor_user_id=actor_user_id,
            action_type=action_type,
            action_reason=action_reason
        )

        if result.get("success"):
            flash(
                "Investigation action recorded successfully.",
                "success"
            )
        else:
            reason = result.get("reason", "ACTION_FAILED")

            messages = {
                "CONTAINMENT_NOT_CONFIGURED":
                    "Containment is not configured and remains disabled.",
                "ACTION_REASON_REQUIRED":
                    "Please provide a reason for this decision.",
                "INVESTIGATION_NOT_FOUND":
                    "Investigation not found.",
                "INVESTIGATION_ALREADY_COMPLETED":
                    "This investigation is already completed.",
                "ACTOR_NOT_FOUND":
                    "Your analyst account was not found.",
                "ACTOR_NOT_ACTIVE":
                    "Your analyst account is not active.",
                "INCIDENT_NOT_FOUND":
                    "The linked incident was not found.",
                "INCIDENT_NOT_ELIGIBLE":
                    "The linked incident cannot accept this action.",
                "INVALID_ACTION":
                    "Invalid investigation action."
            }

            flash(
                messages.get(reason, "Could not record the action."),
                "error"
            )

    except Exception:
        app.logger.exception(
            "Failed to record investigation action"
        )
        flash(
            "An error occurred while recording the action.",
            "error"
        )

    return redirect(
        url_for(
            "investigation_record_detail",
            investigation_id=investigation_id
        )
    )
@app.route("/incident/<incident_id>")
def incident_details(incident_id):

    # Convert display ID such as INC-0001 to database ID 1
    if str(incident_id).upper().startswith("INC-"):
        try:
            incident_id = int(str(incident_id)[4:])
        except ValueError:
            return "Invalid incident ID", 400
    else:
        try:
            incident_id = int(incident_id)
        except ValueError:
            return "Invalid incident ID", 400

    incident = get_incident_details(incident_id)

    if incident is None:
        return "Incident not found", 404

    return render_template(
        "incident.html",
        incident=incident
    )
@app.route("/users/id/<int:user_id>")
def sql_user_profile(user_id):
    user = get_user_details(user_id)

    if not user:
        return "User not found", 404

    return render_template(
        "user_profile.html",
        user=user
    )

@app.route("/users/<username>")
def user_profile(username):

    (
        accounts,
        events,
        incidents,
        investigation_history,
        decision_log
    ) = load_all()

    # =========================================
    # FIND USER
    # =========================================

    account = accounts.get(username)

    if account is None:
        return "User not found", 404


    # =========================================
    # USER EVENTS
    # =========================================

    user_events = [

        event

        for event in events

        if str(
            event.get("username", "")
        ).strip().lower()
        == username.strip().lower()

    ]

    user_events.sort(
        key=lambda event: str(
            event.get("timestamp", "")
        ),
        reverse=True
    )


    # =========================================
    # USER INCIDENTS
    # =========================================

    user_incidents = [

        incident

        for incident in incidents

        if str(
            incident.get("username", "")
        ).strip().lower()
        == username.strip().lower()

    ]

    user_incidents.sort(
        key=lambda incident: str(
            incident.get("timestamp", "")
        ),
        reverse=True
    )


    # =========================================
    # AUTHENTICATION STATISTICS
    # =========================================

    successful_logins = sum(

        1

        for event in user_events

        if str(
            event.get("result", "")
        ).strip().upper()
        == "SUCCESS"

    )

    failed_logins = sum(

        1

        for event in user_events

        if str(
            event.get("result", "")
        ).strip().upper()
        == "FAILED"

    )


    # =========================================
    # LAST LOGIN
    # =========================================

    last_login = None

    for event in user_events:

        if str(
            event.get("result", "")
        ).strip().upper() == "SUCCESS":

            last_login = event
            break


    # =========================================
    # LAST FAILED LOGIN
    # =========================================

    last_failed_login = None

    for event in user_events:

        if str(
            event.get("result", "")
        ).strip().upper() == "FAILED":

            last_failed_login = event
            break


    # =========================================
    # USER DEVICES
    # =========================================

    user_devices = []


    # KNOWN DEVICES

    for device_name, device_data in account.get(
        "known_devices",
        {}
    ).items():

        user_devices.append({

            "name": device_name,

            "status": "Known",

            "trust_score": device_data.get(
                "trust_score",
                0
            ),

            "risk_score": device_data.get(
                "risk_score",
                0
            ),

            "severity": device_data.get(
                "severity",
                "LOW"
            ),

            "first_seen": device_data.get(
                "first_seen"
            ),

            "last_seen": device_data.get(
                "last_seen"
            ),

            "countries": device_data.get(
                "countries",
                []
            ),

            "browsers": device_data.get(
                "browsers",
                []
            )

        })


    # PENDING DEVICES

    for device_name, device_data in account.get(
        "pending_devices",
        {}
    ).items():

        user_devices.append({

            "name": device_name,

            "status": "Pending",

            "trust_score": device_data.get(
                "trust_score"
            ),

            "risk_score": device_data.get(
                "risk_score"
            ),

            "severity": device_data.get(
                "severity",
                "LOW"
            ),

            "first_seen": device_data.get(
                "first_seen"
            ),

            "last_seen": device_data.get(
                "last_seen"
            ),

            "countries": device_data.get(
                "countries",
                []
            ),

            "browsers": device_data.get(
                "browsers",
                []
            )

        })


    # BLOCKED DEVICES

    for device_name, device_data in account.get(
        "blocked_devices",
        {}
    ).items():

        user_devices.append({

            "name": device_name,

            "status": "Blocked",

            "trust_score": device_data.get(
                "trust_score"
            ),

            "risk_score": device_data.get(
                "risk_score"
            ),

            "severity": device_data.get(
                "severity",
                "LOW"
            ),

            "first_seen": device_data.get(
                "first_seen"
            ),

            "last_seen": device_data.get(
                "last_seen"
            ),

            "countries": device_data.get(
                "countries",
                []
            ),

            "browsers": device_data.get(
                "browsers",
                []
            )

        })


    # =========================================
    # SECURITY STATUS
    # =========================================

    pending_count = len(
        account.get(
            "pending_devices",
            {}
        )
    )

    blocked_count = len(
        account.get(
            "blocked_devices",
            {}
        )
    )

    failed_attempts = account.get(
        "failed_attempts",
        0
    )


    if blocked_count > 0:

        security_status = "DEVICE BLOCKED"
        security_status_class = "danger"

    elif pending_count > 0:

        security_status = "PENDING REVIEW"
        security_status_class = "warning"

    elif failed_attempts >= 5:

        security_status = "HIGH RISK"
        security_status_class = "danger"

    else:

        security_status = "NORMAL"
        security_status_class = "normal"


    # =========================================
    # OPEN INCIDENTS
    # =========================================

    open_incidents = [

        incident

        for incident in user_incidents

        if str(
            incident.get("status", "")
        ).strip().lower()
        in [
            "open",
            "under review",
            "investigating"
        ]

    ]


    # =========================================
    # DETECTION COUNTS
    # =========================================

    detection_counts = {

        "Brute Force": 0,

        "Unknown Device": 0,

        "Unknown Country": 0,

        "Impossible Travel": 0,

        "VPN Anomaly": 0

    }


    for investigation in investigation_history:

        if str(
            investigation.get("username", "")
        ).strip().lower() != username.strip().lower():

            continue


        reasons = investigation.get(
            "detection_reasons",
            []
        )


        for reason in reasons:

            reason_text = str(
                reason
            ).lower()


            if "brute" in reason_text:

                detection_counts[
                    "Brute Force"
                ] += 1


            if "unknown device" in reason_text:

                detection_counts[
                    "Unknown Device"
                ] += 1


            if "unknown country" in reason_text:

                detection_counts[
                    "Unknown Country"
                ] += 1


            if "impossible travel" in reason_text:

                detection_counts[
                    "Impossible Travel"
                ] += 1


            if "vpn" in reason_text:

                detection_counts[
                    "VPN Anomaly"
                ] += 1


    # =========================================
    # USER SUMMARY
    # =========================================

    user = {

        "username": username,

        "department": account.get(
            "department",
            "Unassigned"
        ),

        "role": account.get(
            "role",
            "Not Assigned"
        ),

        "failed_attempts": failed_attempts,

        "known_devices": account.get(
            "known_devices",
            {}
        ),

        "pending_devices": account.get(
            "pending_devices",
            {}
        ),

        "blocked_devices": account.get(
            "blocked_devices",
            {}
        ),

        "known_countries": account.get(
            "known_countries",
            set()
        ),

        "authorized_contexts": account.get(
            "authorized_contexts",
            []
        ),

        "successful_logins": successful_logins,

        "failed_logins": failed_logins,

        "last_login": last_login,

        "last_failed_login": last_failed_login,

        "security_status": security_status,

        "security_status_class": security_status_class

    }


    # =========================================
    # RENDER
    # =========================================

    return render_template(

        "user_profile.html",

        user=user,

        user_events=user_events,

        user_incidents=user_incidents,

        user_devices=user_devices,

        open_incidents=open_incidents,

        detection_counts=detection_counts

    )
@app.route("/settings/update", methods=["POST"])
def update_settings():

    checkbox_settings = [
        "brute_force_enabled",
        "unknown_device_enabled",
        "unknown_country_enabled",
        "impossible_travel_enabled",
        "vpn_anomaly_enabled",
        "admin_notifications",
        "security_alerts",
        "monitoring_enabled"
        
    ]

    number_settings = [
        "brute_force_points",
        "unknown_device_points",
        "unknown_country_points",
        "impossible_travel_points",
        "vpn_anomaly_points",
        "medium_threshold",
        "high_threshold",
        "critical_threshold"
    ]

    for setting_name in checkbox_settings:

        value = (
            "true"
            if setting_name in request.form
            else "false"
        )

        set_setting(
            setting_name,
            value
        )

    for setting_name in number_settings:

        if setting_name in request.form:

            set_setting(
                setting_name,
                request.form[setting_name]
            )

    return redirect("/settings")
@app.route("/settings")
def settings_page():

    return render_template(
        "settings.html"
    )

@app.route(
    "/archive/incident/<int:incident_id>/preview",
    methods=["POST"],
)
def archive_incident_preview(incident_id):
    # auth.py also rechecks the active account and analyst role
    # before this route is reached.
    if session.get("role_id") != 51:
        return jsonify({"error": "Security Analyst access required"}), 403

    submitted = request.form.get("csrf_token", "")
    expected = session.get("action_csrf_token", "")

    if (
        not submitted
        or not expected
        or not secrets.compare_digest(submitted, expected)
    ):
        return jsonify({"error": "Invalid CSRF token"}), 400

    try:
        report = archive_incident_group(
            incident_id,
            execute=False,
        )
        return jsonify(report), 200

    except (ValueError, RuntimeError) as exc:
        return jsonify({"error": str(exc)}), 409

    except Exception:
        app.logger.exception("Archive preview failed")
        return jsonify({"error": "Archive preview failed"}), 500

@app.route(
    "/restore/incident/<int:incident_id>/execute",
    methods=["POST"],
)
def restore_incident_execute(incident_id):
    # Require an authenticated Security Analyst.
    if (
        not session.get("user_id")
        or session.get("role_id") != 51
    ):
        return jsonify({
            "error": "Authenticated Security Analyst access required"
        }), 403

    # Validate CSRF token.
    submitted = request.form.get("csrf_token", "")
    expected = session.get("action_csrf_token", "")

    if (
        not submitted
        or not expected
        or not secrets.compare_digest(submitted, expected)
    ):
        return jsonify({"error": "Invalid CSRF token"}), 400

    try:
        from archive_restore import restore_incident_group

        # Execution remains blocked by RESTORE_EXECUTION_ENABLED=False.
        report = restore_incident_group(
            incident_id,
            execute=True,
            actor_user_id=int(session["user_id"]),
            actor_source="AEGIS_DB",
            actor_external_user_id=str(session["user_id"]),
            actor_display_name=session.get("user_name"),
        )

        return jsonify(report), 200

    except (ValueError, RuntimeError) as exc:
        return jsonify({"error": str(exc)}), 409

    except Exception:
        app.logger.exception("Restore execution failed")
        return jsonify({"error": "Restore execution failed"}), 500

@app.route(
    "/restore/incident/<int:incident_id>/preview",
    methods=["POST"],
)
def restore_incident_preview(incident_id):
    # Require an authenticated Security Analyst.
    if (
        not session.get("user_id")
        or session.get("role_id") != 51
    ):
        return jsonify({
            "error": "Authenticated Security Analyst access required"
        }), 403

    # Validate CSRF token.
    submitted = request.form.get("csrf_token", "")
    expected = session.get("action_csrf_token", "")

    if (
        not submitted
        or not expected
        or not secrets.compare_digest(submitted, expected)
    ):
        return jsonify({"error": "Invalid CSRF token"}), 400

    try:
        from archive_restore import restore_incident_group

        report = restore_incident_group(
            incident_id,
            execute=False,
        )
        return jsonify(report), 200

    except (ValueError, RuntimeError) as exc:
        return jsonify({"error": str(exc)}), 409

    except Exception:
        app.logger.exception("Restore preview failed")
        return jsonify({"error": "Restore preview failed"}), 500


@app.route(
    "/archive/incident/<int:incident_id>/execute",
    methods=["POST"],
)
def archive_incident_execute(incident_id):
    # auth.py rechecks the active account and analyst role.
    if (
        not session.get("user_id")
        or session.get("role_id") != 51
    ):
        return jsonify({
            "error": "Authenticated Security Analyst access required"
        }), 403

    submitted = request.form.get("csrf_token", "")
    expected = session.get("action_csrf_token", "")

    if (
        not submitted
        or not expected
        or not secrets.compare_digest(submitted, expected)
    ):
        return jsonify({"error": "Invalid CSRF token"}), 400

    try:
        # The transaction module's execution gate remains disabled.
        # This call must fail safely until that gate is explicitly
        # enabled after the remaining review and acceptance tests.
        
        report = archive_incident_group(
        incident_id,
        execute=True,
        actor_user_id=int(session["user_id"]),
        actor_source="AEGIS_DB",
        actor_external_user_id=session["user_id"],
        actor_display_name=session.get("user_name"),
    )
        return jsonify(report), 200

    except (ValueError, RuntimeError) as exc:
        return jsonify({"error": str(exc)}), 409

    except Exception:
        app.logger.exception("Archive execution failed")
        return jsonify({"error": "Archive execution failed"}), 500

print()
print("EMPLOYEE WORK STATUS")
print("------------------------------------------")

work_status = get_employee_work_status()

for key, value in work_status.items():
        print(f"{key:20}: {value}")
if __name__ == "__main__":
    app.run(debug=True)