"""
AEGIS Archive Restore Workflow
Development database only: AEGIS_DB.

Preview is read-only.
Restore execution remains disabled until acceptance testing and
server-side authorization are approved.
"""

from collections import defaultdict

from archive_database import get_archive_connection


RESTORE_EXECUTION_ENABLED = False

TABLES = {
    "access_events": "event_id",
    "security_alerts": "alert_id",
    "incidents": "incident_id",
    "investigations": "investigation_id",
    "investigation_actions": "action_id",
    "security_alert_detections": "alert_detection_id",
    "device_vpn_history": "vpn_history_id",
}

# Parent-first restore order.
COPY_ORDER = [
    "access_events",
    "security_alerts",
    "incidents",
    "investigations",
    "investigation_actions",
    "security_alert_detections",
    "device_vpn_history",
]

# Child-first archive cleanup order.
DELETE_ORDER = list(reversed(COPY_ORDER))

# (parent table, parent PK, child table, child FK)
RELATIONSHIPS = [
    ("access_events", "event_id",
     "security_alerts", "event_id"),
    ("access_events", "event_id",
     "device_vpn_history", "event_id"),
    ("security_alerts", "alert_id",
     "incidents", "source_alert_id"),
    ("incidents", "incident_id",
     "investigations", "incident_id"),
    ("investigations", "investigation_id",
     "investigation_actions", "investigation_id"),
    ("security_alerts", "alert_id",
     "security_alert_detections", "alert_id"),
]


def _require_dev(cursor):
    cursor.execute("SELECT DB_NAME()")
    database_name = cursor.fetchone()[0]

    if database_name != "AEGIS_DB":
        raise RuntimeError(
            "Safety stop: restore is permitted only in AEGIS_DB; "
            f"connected to {database_name!r}."
        )



def _require_dev_analyst(cursor, actor_user_id):
    """Require an active Security Analyst in AEGIS_DB."""
    if actor_user_id is None:
        raise RuntimeError(
            "Restore blocked: a Dev-local analyst is required."
        )

    cursor.execute(
        """
        SELECT u.user_id
        FROM dbo.users AS u
        INNER JOIN dbo.roles AS r
            ON r.role_id = u.role_id
        WHERE u.user_id = ?
          AND LOWER(LTRIM(RTRIM(r.role_name))) = 'security analyst'
          AND UPPER(LTRIM(RTRIM(u.status))) = 'ACTIVE'
        """,
        actor_user_id,
    )

    if cursor.fetchone() is None:
        raise RuntimeError(
            "Restore blocked: account is not an active "
            "Security Analyst in AEGIS_DB."
        )
def _get_data_columns(cursor, table):
    live_columns = _get_columns(cursor, table)
    archive_columns = _get_columns(cursor, table + "_archive")

    if not live_columns or not archive_columns:
        raise RuntimeError(
            f"Restore blocked: missing live/archive table for {table}."
        )

    archive_data_columns = [
        column for column in archive_columns
        if column not in {"archived_at", "purge_eligible_at"}
    ]

    if set(live_columns) != set(archive_data_columns):
        raise RuntimeError(
            f"Restore blocked: live/archive column mismatch for {table}."
        )

    return live_columns


def _get_archived_ids(cursor, table, pk, fk, parent_ids):
    if not parent_ids:
        return set()

    values = sorted(parent_ids)
    placeholders = ", ".join("?" for _ in values)

    cursor.execute(
        f"""
        SELECT [{pk}]
        FROM dbo.[{table}_archive]
        WHERE [{fk}] IN ({placeholders})
        """,
        tuple(values),
    )
    return {row[0] for row in cursor.fetchall()}


def _discover_archived_group(cursor, incident_id):
    """Discover the complete archived evidence group around an incident."""
    group = defaultdict(set)

    cursor.execute(
        """
        SELECT incident_id
        FROM dbo.incidents_archive
        WHERE incident_id = ?
        """,
        incident_id,
    )

    if cursor.fetchone() is None:
        raise ValueError(
            f"Incident {incident_id} was not found in the archive."
        )

    group["incidents"].add(incident_id)

    changed = True

    while changed:
        changed = False

        for parent, parent_pk, child, child_fk in RELATIONSHIPS:
            # Discover archived children of known parents.
            child_ids = _get_archived_ids(
                cursor,
                child,
                TABLES[child],
                child_fk,
                group[parent],
            )

            new_children = child_ids - group[child]
            if new_children:
                group[child].update(new_children)
                changed = True

            # Discover archived parents referenced by known children.
            child_ids = sorted(group[child])

            if child_ids:
                placeholders = ", ".join("?" for _ in child_ids)

                cursor.execute(
                    f"""
                    SELECT [{child_fk}]
                    FROM dbo.[{child}_archive]
                    WHERE [{TABLES[child]}] IN ({placeholders})
                      AND [{child_fk}] IS NOT NULL
                    """,
                    tuple(child_ids),
                )

                parent_ids = {
                    row[0] for row in cursor.fetchall()
                } - group[parent]

                if parent_ids:
                    group[parent].update(parent_ids)
                    changed = True

    result = {
        table: sorted(group[table])
        for table in TABLES
        if group[table]
    }

    # Every discovered ID must exist in its archive table.
    for table, ids in result.items():
        pk = TABLES[table]
        placeholders = ", ".join("?" for _ in ids)

        cursor.execute(
            f"""
            SELECT [{pk}]
            FROM dbo.[{table}_archive]
            WHERE [{pk}] IN ({placeholders})
            """,
            tuple(ids),
        )

        found = {row[0] for row in cursor.fetchall()}
        missing = set(ids) - found

        if missing:
            raise RuntimeError(
                f"Archive group is inconsistent: "
                f"{table}_archive is missing IDs {sorted(missing)}."
            )

    return result


def _validate_group_relationships(cursor, group):
    """
    Verify that archived child records reference parents
    included in the same evidence group.
    """
    for parent, parent_pk, child, child_fk in RELATIONSHIPS:
        child_ids = group.get(child, [])
        if not child_ids:
            continue

        parent_ids = set(group.get(parent, []))
        placeholders = ", ".join("?" for _ in child_ids)

        cursor.execute(
            f"""
            SELECT [{TABLES[child]}], [{child_fk}]
            FROM dbo.[{child}_archive]
            WHERE [{TABLES[child]}] IN ({placeholders})
            """,
            tuple(child_ids),
        )

        rows = cursor.fetchall()

        if len(rows) != len(child_ids):
            raise RuntimeError(
                f"Restore blocked: relationship validation count "
                f"mismatch for {child}_archive."
            )

        for child_id, referenced_parent_id in rows:
            if (
                referenced_parent_id is not None
                and referenced_parent_id not in parent_ids
            ):
                raise RuntimeError(
                    f"Restore blocked: {child}_archive ID {child_id} "
                    f"references {parent} ID {referenced_parent_id}, "
                    "which is not included in the restore group."
                )

def _validate_archive_retention_metadata(cursor, group):
    """
    Validate archive timestamps before restoring evidence.
    Read-only validation; does not modify archive records.
    """
    for table, ids in group.items():
        if not ids:
            continue

        pk = TABLES[table]
        placeholders = ", ".join("?" for _ in ids)

        cursor.execute(
            f"""
            SELECT
                [{pk}],
                archived_at,
                purge_eligible_at,
                DATEADD(MONTH, 18, archived_at)
                    AS expected_purge_eligible_at
            FROM dbo.[{table}_archive]
            WHERE [{pk}] IN ({placeholders})
            """,
            tuple(ids),
        )

        rows = cursor.fetchall()

        if len(rows) != len(ids):
            raise RuntimeError(
                f"Restore blocked: archive metadata count mismatch "
                f"for {table}."
            )

        for (
            record_id,
            archived_at,
            purge_eligible_at,
            expected_purge_eligible_at,
        ) in rows:
            if archived_at is None:
                raise RuntimeError(
                    f"Restore blocked: {table} ID {record_id} "
                    "has no archived_at timestamp."
                )

            if table == "audit_logs":
                continue

            if purge_eligible_at is None:
                raise RuntimeError(
                    f"Restore blocked: {table} ID {record_id} "
                    "has no purge_eligible_at timestamp."
                )

            if purge_eligible_at != expected_purge_eligible_at:
                raise RuntimeError(
                    f"Restore blocked: {table} ID {record_id} "
                    "has an incorrect purge_eligible_at timestamp."
                )

def _check_restore_holds(cursor, incident_id, group):
    """
    Block restoration if an active hold applies to any record in
    the evidence group.

    Supports:
      - RECORD holds, matched by record_type and record_id.
      - EVIDENCE_GROUP holds, conservatively blocking the entire
        restore when the group hold is active.
    """
    cursor.execute(
        """
        SELECT hold_id, scope_type, record_type, record_id
        FROM dbo.archive_holds WITH (UPDLOCK, HOLDLOCK)
        WHERE status = 'ACTIVE'
          AND scope_type IN ('RECORD', 'EVIDENCE_GROUP')
        """
    )

    active_holds = cursor.fetchall()

    if not active_holds:
        return
    # EVIDENCE_GROUP holds are anchored to an incident ID.
    # A hold applies when its incident belongs to this group.
    # Unknown group identifiers fail closed.
    """
    Block restoration when an active hold applies to the evidence group.

    Supports:
      - RECORD holds matching a record in the evidence group.
      - EVIDENCE_GROUP holds anchored to an incident ID in the group.
      - Unknown evidence-group identifiers fail closed.
    """
    group_incident_ids = set(group.get("incidents", []))
    matching_group_holds = []
    unrecognized_group_holds = []

    for hold_id, scope_type, record_type, record_id in active_holds:
        if scope_type != "EVIDENCE_GROUP":
            continue

        normalized_type = (record_type or "").strip().lower()

        if normalized_type not in {"incident", "incidents"}:
            unrecognized_group_holds.append(hold_id)
        elif record_id in group_incident_ids:
            matching_group_holds.append(hold_id)

    if unrecognized_group_holds:
        raise RuntimeError(
            "Restore blocked: evidence-group hold(s) have an "
            "unrecognized group identifier: "
            f"{unrecognized_group_holds}."
        )

    if matching_group_holds:
        raise RuntimeError(
            "Restore blocked by matching evidence-group hold(s): "
            f"{matching_group_holds}."
        )

    # Map actual live/archive table names to the record_type names
    # stored by the hold-placement workflow.
    record_type_aliases = {
        "access_events": {"access_events", "access_event"},
        "security_alerts": {"security_alerts", "security_alert"},
        "incidents": {"incidents", "incident"},
        "investigations": {"investigations", "investigation"},
        "investigation_actions": {
            "investigation_actions",
            "investigation_action",
        },
        "security_alert_detections": {
            "security_alert_detections",
            "security_alert_detection",
        },
        "device_vpn_history": {
            "device_vpn_history",
            "vpn_history",
        },
    }

    group_records = set()

    for table, ids in group.items():
        aliases = record_type_aliases.get(table, {table})
        for record_id in ids:
            group_records.add(
                (record_id, frozenset(alias.lower() for alias in aliases))
            )

    matching_holds = []

    for hold in active_holds:
        hold_id, scope_type, record_type, record_id = hold

        if scope_type != "RECORD":
            continue

        normalized_type = (record_type or "").strip().lower()

        if any(
            record_id == group_record_id
            and normalized_type in aliases
            for group_record_id, aliases in group_records
        ):
            matching_holds.append(hold_id)

    if matching_holds:
        raise RuntimeError(
            "Restore blocked by active record hold(s): "
            f"{matching_holds}."
        )

    # Fail closed for an active record hold whose record type is
    # not recognized. We cannot safely prove it is unrelated.
    known_aliases = {
        alias
        for aliases in record_type_aliases.values()
        for alias in aliases
    }

    unknown_holds = [
        row[0]
        for row in active_holds
        if row[1] == "RECORD"
        and (row[2] or "").strip().lower() not in known_aliases
    ]

    if unknown_holds:
        raise RuntimeError(
            "Restore blocked because active record hold(s) use "
            "unrecognized record types: "
            f"{unknown_holds}."
        )



def _check_no_live_conflicts(cursor, group):
    """Never overwrite a live row with the same primary key."""
    for table, ids in group.items():
        if not ids:
            continue

        pk = TABLES[table]
        placeholders = ", ".join("?" for _ in ids)

        cursor.execute(
            f"""
            SELECT [{pk}]
            FROM dbo.[{table}] WITH (UPDLOCK, HOLDLOCK)
            WHERE [{pk}] IN ({placeholders})
            """,
            tuple(ids),
        )

        conflicts = [row[0] for row in cursor.fetchall()]

        if conflicts:
            raise RuntimeError(
                f"Restore blocked: dbo.{table} already contains "
                f"IDs {conflicts}. No rows were overwritten."
            )


def _verify_rows_match(cursor, table, ids, columns):
    """Compare restored data with archived data in both directions."""
    if not ids:
        return

    pk = TABLES[table]
    placeholders = ", ".join("?" for _ in ids)
    column_list = ", ".join(f"[{column}]" for column in columns)
    params = tuple(ids) + tuple(ids)

    cursor.execute(
        f"""
        SELECT {column_list}
        FROM dbo.[{table}]
        WHERE [{pk}] IN ({placeholders})

        EXCEPT

        SELECT {column_list}
        FROM dbo.[{table}_archive]
        WHERE [{pk}] IN ({placeholders})
        """,
        params,
    )

    if cursor.fetchone() is not None:
        raise RuntimeError(
            f"Restore verification failed: live {table} "
            "contains data that differs from the archive."
        )

    cursor.execute(
        f"""
        SELECT {column_list}
        FROM dbo.[{table}_archive]
        WHERE [{pk}] IN ({placeholders})

        EXCEPT

        SELECT {column_list}
        FROM dbo.[{table}]
        WHERE [{pk}] IN ({placeholders})
        """,
        params,
    )

    if cursor.fetchone() is not None:
        raise RuntimeError(
            f"Restore verification failed: archived {table} "
            "contains data missing or different in the live table."
        )


def _write_restore_audit(
    cursor,
    incident_id,
    actor_user_id,
    outcome,
    details,
    actor_source=None,
    actor_external_user_id=None,
    actor_display_name=None,
):
    """Write a RESTORE audit entry and return its operation_id."""
    if outcome not in {"STARTED", "SUCCEEDED", "FAILED", "BLOCKED"}:
        raise ValueError(f"Invalid restore audit outcome: {outcome}")

    cursor.execute(
        """
        SELECT COLUMNPROPERTY(
            OBJECT_ID('dbo.archive_operation_audit'),
            'audit_id',
            'IsIdentity'
        )
        """
    )
    identity_value = cursor.fetchone()[0]

    if identity_value not in (0, 1):
        raise RuntimeError(
            "Cannot verify archive audit ID configuration."
        )

    finished_expression = (
        "NULL" if outcome == "STARTED" else "SYSDATETIME()"
    )
    details_value = details[:4000] if details else None

    audit_columns = """
        incident_id,
        actor_user_id,
        actor_source,
        actor_external_user_id,
        actor_display_name,
        operation_type,
        outcome,
        finished_at,
        details
    """

    if identity_value == 1:
        cursor.execute(
            f"""
            INSERT INTO dbo.archive_operation_audit
            ({audit_columns})
            OUTPUT INSERTED.operation_id
            VALUES (
                ?, ?, ?, ?, ?, 'RESTORE', ?,
                {finished_expression}, ?
            )
            """,
            (
                incident_id,
                actor_user_id,
                actor_source,
                actor_external_user_id,
                actor_display_name,
                outcome,
                details_value,
            ),
        )
    else:
        cursor.execute(
            f"""
            DECLARE @next_id bigint;

            SELECT @next_id = ISNULL(MAX(audit_id), 0) + 1
            FROM dbo.archive_operation_audit
                WITH (UPDLOCK, HOLDLOCK);

            INSERT INTO dbo.archive_operation_audit
            (
                audit_id,
                {audit_columns}
            )
            OUTPUT INSERTED.operation_id
            VALUES (
                @next_id, ?, ?, ?, ?, ?, 'RESTORE', ?,
                {finished_expression}, ?
            );
            """,
            (
                incident_id,
                actor_user_id,
                actor_source,
                actor_external_user_id,
                actor_display_name,
                outcome,
                details_value,
            ),
        )

    row = cursor.fetchone()

    if row is None or row[0] is None:
        raise RuntimeError(
            "Restore audit insert did not return operation_id."
        )

    return row[0]

def _start_restore_audit(
    incident_id,
    actor_user_id,
    actor_source=None,
    actor_external_user_id=None,
    actor_display_name=None,
):
    """Commit STARTED separately and return its operation ID."""
    connection = None
    cursor = None

    try:
        connection = get_archive_connection()
        connection.autocommit = False
        cursor = connection.cursor()

        _require_dev(cursor)
        _require_dev_analyst(cursor, actor_user_id)

        operation_id = _write_restore_audit(
            cursor,
            incident_id,
            actor_user_id,
            "STARTED",
            "Restore operation started.",
            actor_source,
            actor_external_user_id,
            actor_display_name,
)
        
        if operation_id is None:
            raise RuntimeError("Restore audit did not return an operation ID.")
        operation_started = True

        connection.commit()
        return operation_id

    except Exception:
        if connection is not None:
            connection.rollback()
        raise

    finally:
        if cursor is not None:
            cursor.close()
        if connection is not None:
            connection.close()


def _record_restore_failure(operation_id, details):
    """Update the existing audit operation after transaction rollback."""
    connection = None
    cursor = None

    try:
        connection = get_archive_connection()
        connection.autocommit = False
        cursor = connection.cursor()

        _require_dev(cursor)

        cursor.execute(
            """
            UPDATE dbo.archive_operation_audit
            SET outcome = 'FAILED',
                finished_at = SYSDATETIME(),
                details = ?
            WHERE operation_id = ?
              AND operation_type = 'RESTORE'
              AND outcome = 'STARTED'
            """,
            (details[:4000] if details else None, operation_id),
        )

        if cursor.rowcount != 1:
            raise RuntimeError(
                "Could not update the existing restore audit to FAILED."
            )

        connection.commit()

    except Exception as audit_error:
        if connection is not None:
            try:
                connection.rollback()
            except Exception:
                pass

        raise RuntimeError(
            "Restore failed, and its durable failure audit also failed: "
            f"{audit_error}"
        ) from audit_error

    finally:
        if cursor is not None:
            cursor.close()
        if connection is not None:
            connection.close()

def restore_incident_group(
    incident_id,
    execute=False,
    actor_user_id=None,
    actor_source=None,
    actor_external_user_id=None,
    actor_display_name=None,
):
    """
    Preview by default.

    Execution requires the module gate plus a caller that has already
    authenticated the active Security Analyst and validated CSRF.
    """
    connection = get_archive_connection()
    connection.autocommit = False
    cursor = connection.cursor()

    operation_started = False

    try:
        _require_dev(cursor)

        cursor.execute(
            "SET TRANSACTION ISOLATION LEVEL SERIALIZABLE"
        )
        cursor.execute("SET XACT_ABORT ON")
        cursor.execute("BEGIN TRANSACTION")

        group = _discover_archived_group(cursor, incident_id)

        _validate_group_relationships(cursor, group)
        _check_restore_holds(cursor, incident_id, group)
        _validate_archive_retention_metadata(cursor, group)
        _check_no_live_conflicts(cursor, group)
        report = {
            "database": "AEGIS_DB",
            "incident_id": incident_id,
            "mode": "DRY RUN",
            "records": {
                table: len(ids) for table, ids in group.items()
            },
        }

        if not execute:
            connection.rollback()
            return report

        if not RESTORE_EXECUTION_ENABLED:
            raise RuntimeError(
                "Restore execution is disabled. Preview only."
            )

        if not isinstance(actor_source, str) or not actor_source.strip():
            raise RuntimeError(
                "Restore blocked: actor_source is required."
            )

        if (
            actor_external_user_id is None
            or not str(actor_external_user_id).strip()
        ):
            raise RuntimeError(
                "Restore blocked: authenticated external identity "
                "is required."
            )

        _require_dev_analyst(cursor, actor_user_id)

        operation_id = _start_restore_audit(
            incident_id,
            actor_user_id,
            actor_source=actor_source,
            actor_external_user_id=actor_external_user_id,
            actor_display_name=actor_display_name,
        )

        if operation_id is None:
         raise RuntimeError(
         "Restore audit did not return an operation ID."
    )

        operation_started = True

        # Restore parents before children, preserving original IDs.
        for table in COPY_ORDER:
            ids = group.get(table, [])

            if not ids:
                continue

            pk = TABLES[table]
            columns = _get_data_columns(cursor, table)
            column_list = ", ".join(
                f"[{column}]" for column in columns
            )
            placeholders = ", ".join("?" for _ in ids)

            # Only use IDENTITY_INSERT when the live PK is an identity.
            cursor.execute(
                """
                SELECT COLUMNPROPERTY(
                    OBJECT_ID(?), ?, 'IsIdentity'
                )
                """,
                f"dbo.{table}",
                pk,
            )
            is_identity = cursor.fetchone()[0]

            if is_identity not in (0, 1):
                raise RuntimeError(
                    f"Cannot determine identity status for {table}.{pk}."
                )

            identity_enabled = False

            try:
                if is_identity == 1:
                    cursor.execute(
                        f"SET IDENTITY_INSERT dbo.[{table}] ON"
                    )
                    identity_enabled = True

                cursor.execute(
                    f"""
                    INSERT INTO dbo.[{table}] ({column_list})
                    SELECT {column_list}
                    FROM dbo.[{table}_archive]
                    WHERE [{pk}] IN ({placeholders})
                    """,
                    tuple(ids),
                )

                if cursor.rowcount != len(ids):
                    raise RuntimeError(
                        f"Restore count mismatch for {table}: "
                        f"expected {len(ids)}, inserted {cursor.rowcount}."
                    )

            finally:
                if identity_enabled:
                    cursor.execute(
                        f"SET IDENTITY_INSERT dbo.[{table}] OFF"
                    )

        # Verify all restored data before deleting any archive copies.
        for table, ids in group.items():
            _verify_rows_match(
                cursor,
                table,
                ids,
                _get_data_columns(cursor, table),
            )

        # Delete archived children before archived parents.
        for table in DELETE_ORDER:
            ids = group.get(table, [])

            if not ids:
                continue

            pk = TABLES[table]
            placeholders = ", ".join("?" for _ in ids)

            cursor.execute(
                f"""
                DELETE FROM dbo.[{table}_archive]
                WHERE [{pk}] IN ({placeholders})
                """,
                tuple(ids),
            )

            if cursor.rowcount != len(ids):
                raise RuntimeError(
                    f"Archive cleanup count mismatch for {table}; "
                    "restore transaction must roll back."
                )

        cursor.execute(
            """
            UPDATE dbo.archive_operation_audit
            SET outcome = 'SUCCEEDED',
                finished_at = SYSDATETIME(),
                details = ?
            WHERE operation_id = ?
              AND operation_type = 'RESTORE'
              AND outcome = 'STARTED'
            """,
            (
                (
                    "Evidence group restored and verified. "
                    f"Record counts: {report['records']}"
                )[:4000],
                operation_id,
            ),
        )

        if cursor.rowcount != 1:
            raise RuntimeError("Final restore audit update failed.")

        connection.commit()

        report["mode"] = "COMMITTED"
        return report

    except Exception as exc:
        try:
            connection.rollback()
        except Exception:
            pass

        if execute and operation_started:
            _record_restore_failure(
            operation_id,
           f"Restore operation failed and was rolled back: {exc}",
)

        raise

    finally:
        cursor.close()
        connection.close()




if __name__ == "__main__":
    # Safe by default: preview only.
    result = restore_incident_group(incident_id=1, execute=False)

    print("=== AEGIS RESTORE PREVIEW ===")
    print(f"Database: {result['database']}")
    print(f"Incident: {result['incident_id']}")
    print(f"Mode: {result['mode']}")

    for table, count in result["records"].items():
        print(f"{table}: {count}")

    print("\nREAD-ONLY: no records were changed.")