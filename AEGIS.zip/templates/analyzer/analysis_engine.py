# ============================================================
# AEGIS - ANALYSIS ENGINE
# Phase 4 - Step 5
# ============================================================

from database import get_connection


# ============================================================
# RISK CONFIGURATION
# ============================================================

RISK_WEIGHTS = {
    "DENIED_ACCESS": 25,
    "SENSITIVE_RESOURCE": 20,
    "UNMANAGED_DEVICE": 20,
    "NON_COMPLIANT_DEVICE": 20,
    "PRIVILEGED_ACTION": 30,
    "CROSS_DEPARTMENT": 30,
    "AFTER_HOURS": 15,
    "REPEATED_UNAUTHORIZED": 25,
}


# ============================================================
# RISK SEVERITY
# ============================================================

def get_severity(risk_score):

    if risk_score >= 90:
        return "CRITICAL"

    elif risk_score >= 70:
        return "HIGH"

    elif risk_score >= 40:
        return "MEDIUM"

    else:
        return "LOW"


# ============================================================
# CHECK WHETHER CURRENT TIME IS AFTER HOURS
# ============================================================

def is_after_hours(event_timestamp):

    if event_timestamp is None:
        return False

    hour = event_timestamp.hour

    # Normal working hours:
    # 08:00 - 18:00

    return hour < 8 or hour >= 18


# ============================================================
# GET EVENT INFORMATION
# ============================================================

def get_event_details(event_id):

    connection = get_connection()
    cursor = connection.cursor()

    query = """
        SELECT
            ae.event_id,
            ae.user_id,
            u.employee_code,
            u.full_name,

            ae.role_id,
            r.role_name,

            d.department_id,
            d.department_name,

            ae.device_id,
            ud.device_name,
            ud.device_type,
            ud.operating_system,
            ud.managed,
            ud.compliant,

            ae.resource_id,
            res.resource_name,
            res.resource_type,
            res.sensitivity,
            res.department_id AS resource_department_id,

            ae.event_type,
            ae.[action],
            ae.event_timestamp,
            ae.result,

            ae.source_ip,
            ae.location,
            ae.auth_method,
            ae.user_agent,

            ae.risk_score,
            ae.reason

        FROM access_events ae

        INNER JOIN users u
            ON ae.user_id = u.user_id

        INNER JOIN roles r
            ON ae.role_id = r.role_id

        INNER JOIN departments d
            ON r.department_id = d.department_id

        LEFT JOIN user_devices ud
            ON ae.device_id = ud.device_id

        LEFT JOIN resources res
            ON ae.resource_id = res.resource_id

        WHERE ae.event_id = ?

    """

    cursor.execute(query, event_id)

    row = cursor.fetchone()

    cursor.close()
    connection.close()

    if not row:
        return None

    columns = [column[0] for column in cursor.description] \
        if False else None

    return row


# ============================================================
# ANALYZE PERMISSION
# ============================================================

def analyze_permission(role_id, resource_id, action):

    if role_id is None or resource_id is None or action is None:
        return {
            "permission_exists": False,
            "allowed": False
        }

    connection = get_connection()
    cursor = connection.cursor()

    query = """
        SELECT
            can_view,
            can_create,
            can_edit,
            can_delete,
            can_admin

        FROM permissions

        WHERE role_id = ?
          AND resource_id = ?
    """

    cursor.execute(
        query,
        role_id,
        resource_id
    )

    row = cursor.fetchone()

    cursor.close()
    connection.close()

    if not row:
        return {
            "permission_exists": False,
            "allowed": False
        }

    action = action.upper()

    allowed = False

    if action == "VIEW":
        allowed = bool(row.can_view)

    elif action == "CREATE":
        allowed = bool(row.can_create)

    elif action == "EDIT":
        allowed = bool(row.can_edit)

    elif action == "DELETE":
        allowed = bool(row.can_delete)

    elif action == "ADMIN":
        allowed = bool(row.can_admin)

    return {
        "permission_exists": True,
        "allowed": allowed
    }

# ============================================================
# PHASE 5 - STEP 1
# CHECK USER ACCESS
# ============================================================

def check_user_access(user_id, resource_id, action):

    if user_id is None or resource_id is None or action is None:
        return {
            "user_id": user_id,
            "resource_id": resource_id,
            "action": action,
            "allowed": False,
            "reason": "User, resource, and action are required."
        }

    connection = get_connection()
    cursor = connection.cursor()

    query = """
        SELECT
            u.user_id,
            u.employee_code,
            u.full_name,
            u.status,
            u.role_id,
            r.role_name,
            res.resource_name
        FROM users u
        INNER JOIN roles r
            ON u.role_id = r.role_id
        INNER JOIN resources res
            ON res.resource_id = ?
        WHERE u.user_id = ?
    """

    cursor.execute(
        query,
        resource_id,
        user_id
    )

    row = cursor.fetchone()

    cursor.close()
    connection.close()

    if not row:

        return {
            "user_id": user_id,
            "resource_id": resource_id,
            "action": action.upper(),
            "allowed": False,
            "reason": "User or resource not found."
        }

    if row.status != "ACTIVE":

        return {
            "user_id": row.user_id,
            "employee_code": row.employee_code,
            "full_name": row.full_name,
            "role_id": row.role_id,
            "role_name": row.role_name,
            "resource_id": resource_id,
            "resource_name": row.resource_name,
            "action": action.upper(),
            "allowed": False,
            "reason": f"User account is {row.status.lower()}."
        }

    permission = analyze_permission(
        row.role_id,
        resource_id,
        action
    )

    if not permission["permission_exists"]:

        return {
            "user_id": row.user_id,
            "employee_code": row.employee_code,
            "full_name": row.full_name,
            "role_id": row.role_id,
            "role_name": row.role_name,
            "resource_id": resource_id,
            "resource_name": row.resource_name,
            "action": action.upper(),
            "allowed": False,
            "reason": "No permission is defined for this role and resource."
        }

    if permission["allowed"]:

        return {
            "user_id": row.user_id,
            "employee_code": row.employee_code,
            "full_name": row.full_name,
            "role_id": row.role_id,
            "role_name": row.role_name,
            "resource_id": resource_id,
            "resource_name": row.resource_name,
            "action": action.upper(),
            "allowed": True,
            "reason": "Access permitted by role permission."
        }

    return {
        "user_id": row.user_id,
        "employee_code": row.employee_code,
        "full_name": row.full_name,
        "role_id": row.role_id,
        "role_name": row.role_name,
        "resource_id": resource_id,
        "resource_name": row.resource_name,
        "action": action.upper(),
        "allowed": False,
        "reason": "Role does not have permission for this action."
    }

# ============================================================
# PHASE 5 - STEP 2
# ACCESS ENFORCEMENT
# ============================================================

def enforce_access(
    user_id,
    resource_id,
    action,
    device_id=None,
    source_ip=None,
    location=None,
    auth_method=None,
    user_agent=None
):

    # --------------------------------------------------------
    # CHECK USER ACCESS
    # --------------------------------------------------------

    access = check_user_access(
        user_id,
        resource_id,
        action
    )

    # --------------------------------------------------------
    # IF THE USER OR RESOURCE DOES NOT EXIST
    # --------------------------------------------------------

    if "role_id" not in access:

        return {
            **access,
            "enforced": True,
            "event_id": None
        }

    # --------------------------------------------------------
    # NORMALIZE ACCESS RESULT
    # --------------------------------------------------------

    result = "ALLOW" if access["allowed"] else "DENY"

    action_upper = str(action).upper()

    # --------------------------------------------------------
    # RECORD THE ACCESS ATTEMPT
    # --------------------------------------------------------

    connection = get_connection()
    cursor = connection.cursor()

    query = """
        INSERT INTO access_events
        (
            user_id,
            device_id,
            role_id,
            resource_id,
            event_type,
            [action],
            result,
            source_ip,
            location,
            auth_method,
            user_agent,
            risk_score,
            reason
        )
        OUTPUT INSERTED.event_id
        VALUES
        (
            ?,
            ?,
            ?,
            ?,
            'RESOURCE_ACCESS',
            ?,
            ?,
            ?,
            ?,
            ?,
            ?,
            0,
            ?
        )
    """

    cursor.execute(
        query,
        user_id,
        device_id,
        access["role_id"],
        resource_id,
        action_upper,
        result,
        source_ip,
        location,
        auth_method,
        user_agent,
        access["reason"]
    )

    event_id = cursor.fetchone()[0]

    connection.commit()

    cursor.close()
    connection.close()

    # --------------------------------------------------------
    # RETURN ENFORCEMENT RESULT
    # --------------------------------------------------------

    return {
        **access,
        "result": result,
        "enforced": True,
        "event_id": event_id
    }

# ============================================================
# PHASE 5 - STEP 3
# ACCESS LOGGING & AUDIT
# ============================================================

def log_audit_event(
    actor_user_id,
    audit_action,
    target_type,
    target_id=None,
    old_value=None,
    new_value=None
):
    connection = get_connection()
    cursor = connection.cursor()

    query = """
        INSERT INTO audit_logs
        (
            actor_user_id,
            audit_action,
            target_type,
            target_id,
            old_value,
            new_value,
            event_timestamp
        )
        VALUES
        (
            ?,
            ?,
            ?,
            ?,
            ?,
            ?,
            SYSDATETIME()
        )
    """

    cursor.execute(
        query,
        actor_user_id,
        audit_action,
        target_type,
        target_id,
        old_value,
        new_value
    )

    connection.commit()

    cursor.close()
    connection.close()

    return {
        "logged": True,
        "actor_user_id": actor_user_id,
        "audit_action": audit_action,
        "target_type": target_type,
        "target_id": target_id
    }

# ============================================================
# PHASE 5 - STEP 4
# PRIVILEGED ACCESS
# ============================================================

def check_privileged_access(user_id, resource_id, action):

    action_upper = str(action).upper()

    access = check_user_access(
        user_id,
        resource_id,
        action_upper
    )

    # --------------------------------------------------------
    # ADMIN ACTION
    # --------------------------------------------------------

    if action_upper == "ADMIN":

        return {
            **access,
            "is_privileged": True,
            "privileged_allowed": access["allowed"]
        }

    # --------------------------------------------------------
    # NORMAL ACTION
    # --------------------------------------------------------

    return {
        **access,
        "is_privileged": False,
        "privileged_allowed": False
    }

# ============================================================
# PHASE 5 - STEP 5
# IAM MANAGEMENT
# ============================================================

def get_user_access_profile(user_id):

    connection = get_connection()
    cursor = connection.cursor()

    query = """
        SELECT
            u.user_id,
            u.employee_code,
            u.full_name,
            u.status,
            r.role_id,
            r.role_name,
            res.resource_id,
            res.resource_name,
            res.resource_type,
            res.sensitivity,
            p.can_view,
            p.can_create,
            p.can_edit,
            p.can_delete,
            p.can_admin
        FROM users u
        INNER JOIN roles r
            ON u.role_id = r.role_id
        INNER JOIN permissions p
            ON p.role_id = r.role_id
        INNER JOIN resources res
            ON p.resource_id = res.resource_id
        WHERE u.user_id = ?
        ORDER BY res.resource_id
    """

    cursor.execute(query, user_id)
    rows = cursor.fetchall()

    cursor.close()
    connection.close()

    if not rows:
        return {
            "success": False,
            "user_id": user_id,
            "message": "User not found or no permissions are defined."
        }

    user = rows[0]

    permissions = []

    for row in rows:
        permissions.append({
            "resource_id": row.resource_id,
            "resource_name": row.resource_name,
            "resource_type": row.resource_type,
            "sensitivity": row.sensitivity,
            "can_view": bool(row.can_view),
            "can_create": bool(row.can_create),
            "can_edit": bool(row.can_edit),
            "can_delete": bool(row.can_delete),
            "can_admin": bool(row.can_admin)
        })

    return {
        "success": True,
        "user_id": user.user_id,
        "employee_code": user.employee_code,
        "full_name": user.full_name,
        "status": user.status,
        "role_id": user.role_id,
        "role_name": user.role_name,
        "permissions": permissions
    }

def update_user_role(actor_user_id, target_user_id, new_role_id):

    connection = get_connection()
    cursor = connection.cursor()

    # --------------------------------------------------------
    # Verify actor exists and is ACTIVE
    # --------------------------------------------------------
    cursor.execute("""
        SELECT
            u.user_id,
            u.status
        FROM users u
        WHERE u.user_id = ?
    """, actor_user_id)

    actor = cursor.fetchone()

    if not actor:
        cursor.close()
        connection.close()

        return {
            "success": False,
            "message": "Actor user not found."
        }

    if actor.status != "ACTIVE":
        cursor.close()
        connection.close()

        return {
            "success": False,
            "message": "Actor account is not active."
        }

    # --------------------------------------------------------
    # Verify actor has ADMIN permission on User Accounts
    # Resource 56 = User Accounts
    # --------------------------------------------------------
    cursor.execute("""
        SELECT
            p.can_admin
        FROM users u
        INNER JOIN permissions p
            ON p.role_id = u.role_id
        WHERE u.user_id = ?
          AND p.resource_id = 56
    """, actor_user_id)

    admin_row = cursor.fetchone()

    if not admin_row or not bool(admin_row.can_admin):
        cursor.close()
        connection.close()

        return {
            "success": False,
            "message": "Actor is not authorized to manage user roles."
        }

    # --------------------------------------------------------
    # Get current role of target user
    # --------------------------------------------------------
    cursor.execute("""
        SELECT
            u.role_id,
            r.role_name
        FROM users u
        INNER JOIN roles r
            ON u.role_id = r.role_id
        WHERE u.user_id = ?
    """, target_user_id)

    old_row = cursor.fetchone()

    if not old_row:
        cursor.close()
        connection.close()

        return {
            "success": False,
            "message": "Target user not found."
        }

    # --------------------------------------------------------
    # Verify new role exists
    # --------------------------------------------------------
    cursor.execute("""
        SELECT
            role_id,
            role_name
        FROM roles
        WHERE role_id = ?
    """, new_role_id)

    new_row = cursor.fetchone()

    if not new_row:
        cursor.close()
        connection.close()

        return {
            "success": False,
            "message": "New role not found."
        }

    old_role_id = old_row.role_id
    old_role_name = old_row.role_name
    new_role_name = new_row.role_name

    # --------------------------------------------------------
    # Update target user's role
    # --------------------------------------------------------
    cursor.execute("""
        UPDATE users
        SET role_id = ?
        WHERE user_id = ?
    """, new_role_id, target_user_id)

    connection.commit()

    cursor.close()
    connection.close()

    # --------------------------------------------------------
    # Audit the role change
    # --------------------------------------------------------
    log_audit_event(
        actor_user_id,
        "ROLE_CHANGE",
        "USER",
        target_user_id,
        f"role_id={old_role_id}, role_name={old_role_name}",
        f"role_id={new_role_id}, role_name={new_role_name}"
    )

    return {
        "success": True,
        "target_user_id": target_user_id,
        "old_role_id": old_role_id,
        "old_role_name": old_role_name,
        "new_role_id": new_role_id,
        "new_role_name": new_role_name
    }

def create_incident_from_alert(alert_id):

    connection = get_connection()
    cursor = connection.cursor()

    # Get the alert
    cursor.execute("""
        SELECT
            alert_id,
            user_id,
            alert_type,
            severity,
            risk_score,
            description
        FROM security_alerts
        WHERE alert_id = ?
    """, alert_id)

    alert = cursor.fetchone()

    if not alert:
        cursor.close()
        connection.close()

        return {
            "success": False,
            "message": "Security alert not found."
        }

    # Only HIGH and CRITICAL alerts become incidents
    if alert.severity not in ("HIGH", "CRITICAL"):
        cursor.close()
        connection.close()

        return {
            "success": False,
            "message": "Only HIGH and CRITICAL alerts can be escalated to incidents."
        }

    # Prevent duplicate incidents for the same alert
    cursor.execute("""
        SELECT
            incident_id
        FROM incidents
        WHERE source_alert_id = ?
    """, alert_id)

    existing_incident = cursor.fetchone()

    if existing_incident:
        cursor.close()
        connection.close()

        return {
            "success": True,
            "already_exists": True,
            "incident_id": existing_incident.incident_id,
            "message": "Incident already exists for this alert."
        }

    # Create incident title
    incident_title = f"{alert.alert_type.replace('_', ' ').title()}"

    # Create incident
    cursor.execute("""
    INSERT INTO incidents
    (
        source_alert_id,
        user_id,
        incident_type,
        title,
        description,
        severity,
        risk_score,
        status
    )
    OUTPUT INSERTED.incident_id
    VALUES (?, ?, ?, ?, ?, ?, ?, 'OPEN')
""",
    alert.alert_id,
    alert.user_id,
    alert.alert_type,
    incident_title,
    alert.description,
    alert.severity,
    alert.risk_score
)

    incident_id = cursor.fetchone()[0]
    connection.commit()

    cursor.close()
    connection.close()

    return {
        "success": True,
        "already_exists": False,
        "incident_id": incident_id,
        "source_alert_id": alert.alert_id,
        "user_id": alert.user_id,
        "incident_type": alert.alert_type,
        "severity": alert.severity,
        "risk_score": alert.risk_score,
        "status": "OPEN"
    }


def get_incident(incident_id):

    connection = get_connection()
    cursor = connection.cursor()

    cursor.execute("""
        SELECT
            i.incident_id,
            i.source_alert_id,
            i.user_id,
            u.full_name,
            u.employee_code,
            r.role_name,
            d.department_name,
            i.incident_type,
            i.title,
            i.description,
            i.severity,
            i.risk_score,
            i.status,
            i.assigned_to,
            i.created_at,
            i.updated_at,
            i.resolved_at,
            i.resolution_notes
        FROM incidents i
        INNER JOIN users u
            ON i.user_id = u.user_id
        INNER JOIN roles r
            ON u.role_id = r.role_id
        INNER JOIN departments d
            ON r.department_id = d.department_id
        WHERE i.incident_id = ?
    """, incident_id)

    row = cursor.fetchone()

    cursor.close()
    connection.close()

    if not row:
        return {
            "success": False,
            "message": "Incident not found."
        }

    return {
        "success": True,
        "incident_id": row.incident_id,
        "source_alert_id": row.source_alert_id,
        "user_id": row.user_id,
        "full_name": row.full_name,
        "employee_code": row.employee_code,
        "role_name": row.role_name,
        "department_name": row.department_name,
        "incident_type": row.incident_type,
        "title": row.title,
        "description": row.description,
        "severity": row.severity,
        "risk_score": row.risk_score,
        "status": row.status,
        "assigned_to": row.assigned_to,
        "created_at": row.created_at,
        "updated_at": row.updated_at,
        "resolved_at": row.resolved_at,
        "resolution_notes": row.resolution_notes
    }
def investigate_incident(incident_id):

    connection = get_connection()
    cursor = connection.cursor()

    # Get incident and source event
    cursor.execute("""
        SELECT
            i.incident_id,
            i.source_alert_id,
            i.user_id,
            i.incident_type,
            i.title,
            i.severity,
            i.risk_score,
            i.status,
            sa.event_id,
            ae.event_timestamp
        FROM incidents i
        INNER JOIN security_alerts sa
            ON i.source_alert_id = sa.alert_id
        INNER JOIN access_events ae
            ON sa.event_id = ae.event_id
        WHERE i.incident_id = ?
    """, incident_id)

    incident = cursor.fetchone()

    if not incident:
        cursor.close()
        connection.close()

        return {
            "success": False,
            "message": "Incident not found."
        }

    # Get the triggering event
    cursor.execute("""
        SELECT
            ae.event_id,
            ae.user_id,
            ae.event_type,
            ae.action,
            ae.event_timestamp,
            ae.result,
            ae.source_ip,
            ae.location,
            ae.auth_method,
            ae.risk_score,
            ae.reason
        FROM access_events ae
        WHERE ae.event_id = ?
    """, incident.event_id)

    event = cursor.fetchone()

    # Get related activity from the same user
    cursor.execute("""
        SELECT
            ae.event_id,
            ae.event_type,
            ae.action,
            ae.event_timestamp,
            ae.result,
            ae.source_ip,
            ae.location,
            ae.risk_score,
            ae.reason
        FROM access_events ae
        WHERE ae.user_id = ?
          AND ae.event_timestamp BETWEEN
                DATEADD(HOUR, -24, ?)
                AND DATEADD(HOUR, 24, ?)
        ORDER BY ae.event_timestamp
    """,
        incident.user_id,
        incident.event_timestamp,
        incident.event_timestamp
    )

    related_rows = cursor.fetchall()

    related_events = []

    for row in related_rows:
        related_events.append({
            "event_id": row.event_id,
            "event_type": row.event_type,
            "action": row.action,
            "event_timestamp": row.event_timestamp,
            "result": row.result,
            "source_ip": row.source_ip,
            "location": row.location,
            "risk_score": row.risk_score,
            "reason": row.reason
        })

    cursor.close()
    connection.close()

    return {
        "success": True,
        "incident": {
            "incident_id": incident.incident_id,
            "source_alert_id": incident.source_alert_id,
            "user_id": incident.user_id,
            "incident_type": incident.incident_type,
            "title": incident.title,
            "severity": incident.severity,
            "risk_score": incident.risk_score,
            "status": incident.status
        },
        "triggering_event": {
            "event_id": event.event_id,
            "user_id": event.user_id,
            "event_type": event.event_type,
            "action": event.action,
            "event_timestamp": event.event_timestamp,
            "result": event.result,
            "source_ip": event.source_ip,
            "location": event.location,
            "auth_method": event.auth_method,
            "risk_score": event.risk_score,
            "reason": event.reason
        },
        "related_events": related_events,
        "related_event_count": len(related_events)
    }

def update_incident_status(
    incident_id,
    new_status,
    resolution_notes=None
):

    connection = get_connection()
    cursor = connection.cursor()

    # Check incident exists
    cursor.execute("""
        SELECT
            incident_id,
            status
        FROM incidents
        WHERE incident_id = ?
    """, incident_id)

    incident = cursor.fetchone()

    if not incident:
        cursor.close()
        connection.close()

        return {
            "success": False,
            "message": "Incident not found."
        }

    current_status = incident.status

    # Validate requested status
    valid_statuses = (
        "OPEN",
        "INVESTIGATING",
        "RESOLVED",
        "FALSE_POSITIVE"
    )

    if new_status not in valid_statuses:
        cursor.close()
        connection.close()

        return {
            "success": False,
            "message": "Invalid incident status."
        }

    # Prevent reopening or changing a closed incident
    if current_status in ("RESOLVED", "FALSE_POSITIVE"):
        cursor.close()
        connection.close()

        return {
            "success": False,
            "message": "Closed incidents cannot be reopened or changed."
        }

    # Validate status transition
    allowed_transitions = {
        "OPEN": ("INVESTIGATING",),
        "INVESTIGATING": ("RESOLVED", "FALSE_POSITIVE")
    }

    if new_status not in allowed_transitions.get(current_status, ()):
        cursor.close()
        connection.close()

        return {
            "success": False,
            "message": (
                f"Invalid status transition: "
                f"{current_status} -> {new_status}."
            )
        }

    # Resolution requires resolution notes
    if new_status in ("RESOLVED", "FALSE_POSITIVE"):
        if not resolution_notes or not resolution_notes.strip():
            cursor.close()
            connection.close()

            return {
                "success": False,
                "message": (
                    "Resolution notes are required when closing an incident."
                )
            }

        cursor.execute("""
            UPDATE incidents
            SET
                status = ?,
                updated_at = SYSDATETIME(),
                resolved_at = SYSDATETIME(),
                resolution_notes = ?
            WHERE incident_id = ?
        """,
            new_status,
            resolution_notes,
            incident_id
        )

    else:
        cursor.execute("""
            UPDATE incidents
            SET
                status = ?,
                updated_at = SYSDATETIME()
            WHERE incident_id = ?
        """,
            new_status,
            incident_id
        )

    connection.commit()

    cursor.close()
    connection.close()

    return {
        "success": True,
        "incident_id": incident_id,
        "old_status": current_status,
        "new_status": new_status
    }
def add_investigator_note(incident_id, actor_user_id, note):

    connection = get_connection()
    cursor = connection.cursor()

    # Verify incident exists
    cursor.execute("""
        SELECT incident_id
        FROM incidents
        WHERE incident_id = ?
    """, incident_id)

    incident = cursor.fetchone()

    if not incident:
        cursor.close()
        connection.close()

        return {
            "success": False,
            "message": "Incident not found."
        }

    # Verify investigator exists and is active
    cursor.execute("""
        SELECT
            user_id,
            status
        FROM users
        WHERE user_id = ?
    """, actor_user_id)

    actor = cursor.fetchone()

    if not actor:
        cursor.close()
        connection.close()

        return {
            "success": False,
            "message": "Investigator not found."
        }

    if actor.status != "ACTIVE":
        cursor.close()
        connection.close()

        return {
            "success": False,
            "message": "Investigator account is not active."
        }

    # Validate note
    if not note or not note.strip():
        cursor.close()
        connection.close()

        return {
            "success": False,
            "message": "Investigator note cannot be empty."
        }

    # Update incident timestamp
    cursor.execute("""
        UPDATE incidents
        SET updated_at = SYSDATETIME()
        WHERE incident_id = ?
    """, incident_id)

    connection.commit()

    cursor.close()
    connection.close()

    # Store note in audit trail
    audit_result = log_audit_event(
        actor_user_id,
        "INCIDENT_NOTE",
        "INCIDENT",
        incident_id,
        None,
        note.strip()
    )

    return {
        "success": True,
        "incident_id": incident_id,
        "actor_user_id": actor_user_id,
        "audit_logged": audit_result.get("logged", False),
        "message": "Investigator note added successfully."
    }
# ============================================================
# ANALYZE ONE ACCESS EVENT
# ============================================================

def analyze_event(event_id):

    connection = get_connection()
    cursor = connection.cursor()

    query = """
        SELECT
            ae.event_id,
            ae.user_id,
            u.employee_code,
            u.full_name,

            ae.role_id,
            r.role_name,

            d.department_id,
            d.department_name,

            ae.device_id,
            ud.device_name,
            ud.device_type,
            ud.managed,
            ud.compliant,

            ae.resource_id,
            res.resource_name,
            res.resource_type,
            res.sensitivity,
            res.department_id AS resource_department_id,

            ae.event_type,
            ae.[action],
            ae.event_timestamp,
            ae.result,

            ae.source_ip,
            ae.location,
            ae.auth_method,
            ae.user_agent

        FROM access_events ae

        INNER JOIN users u
            ON ae.user_id = u.user_id

        INNER JOIN roles r
            ON ae.role_id = r.role_id

        INNER JOIN departments d
            ON r.department_id = d.department_id

        LEFT JOIN user_devices ud
            ON ae.device_id = ud.device_id

        LEFT JOIN resources res
            ON ae.resource_id = res.resource_id

        WHERE ae.event_id = ?
    """

    cursor.execute(query, event_id)

    row = cursor.fetchone()

    cursor.close()
    connection.close()

    if not row:
        return {
            "success": False,
            "message": "Event not found."
        }

    # ========================================================
    # BASIC EVENT INFORMATION
    # ========================================================

    (
        event_id,
        user_id,
        employee_code,
        full_name,

        role_id,
        role_name,

        department_id,
        department_name,

        device_id,
        device_name,
        device_type,
        managed,
        compliant,

        resource_id,
        resource_name,
        resource_type,
        sensitivity,
        resource_department_id,

        event_type,
        action,
        event_timestamp,
        result,

        source_ip,
        location,
        auth_method,
        user_agent
    ) = row


    # ========================================================
    # START RISK ANALYSIS
    # ========================================================

    risk_score = 0
    reasons = []
    detections = []


    # ========================================================
    # 1. DENIED ACCESS
    # ========================================================

    if str(result).upper() == "DENY":

        risk_score += RISK_WEIGHTS["DENIED_ACCESS"]

        detections.append("UNAUTHORIZED_ACCESS")
        reasons.append(
            "Access attempt was denied by the authorization system."
        )


    # ========================================================
    # 2. RESOURCE SENSITIVITY
    # ========================================================

    if sensitivity:

        sensitivity_upper = str(sensitivity).upper()

        if sensitivity_upper in (
            "CONFIDENTIAL",
            "RESTRICTED",
            "CRITICAL"
        ):

            risk_score += RISK_WEIGHTS["SENSITIVE_RESOURCE"]

            detections.append("SENSITIVE_RESOURCE_ACCESS")

            reasons.append(
                f"Resource sensitivity level is {sensitivity_upper}."
            )


    # ========================================================
    # 3. DEVICE SECURITY
    # ========================================================

    if managed is not None:

        if not bool(managed):

            risk_score += RISK_WEIGHTS["UNMANAGED_DEVICE"]

            detections.append("UNMANAGED_DEVICE")

            reasons.append(
                "The access originated from an unmanaged device."
            )


    if compliant is not None:

        if not bool(compliant):

            risk_score += RISK_WEIGHTS["NON_COMPLIANT_DEVICE"]

            detections.append("NON_COMPLIANT_DEVICE")

            reasons.append(
                "The device does not meet compliance requirements."
            )


    # ========================================================
    # 4. PRIVILEGED ACTION
    # ========================================================

    if action:

        action_upper = str(action).upper()

        if action_upper == "ADMIN":

            risk_score += RISK_WEIGHTS["PRIVILEGED_ACTION"]

            detections.append("PRIVILEGED_ACTION")

            reasons.append(
                "A privileged administrative action was attempted."
            )


    # ========================================================
    # 5. CROSS-DEPARTMENT ACCESS
    # ========================================================

    if department_id is not None and resource_department_id is not None:

        if department_id != resource_department_id:

            risk_score += RISK_WEIGHTS["CROSS_DEPARTMENT"]

            detections.append("CROSS_DEPARTMENT_ACCESS")

            reasons.append(
                "User attempted to access a resource owned by another department."
            )


    # ========================================================
    # 6. AFTER-HOURS ACCESS
    # ========================================================

    if is_after_hours(event_timestamp):

        risk_score += RISK_WEIGHTS["AFTER_HOURS"]

        detections.append("AFTER_HOURS_ACCESS")

        reasons.append(
            "The event occurred outside normal working hours."
        )


    # ========================================================
    # 7. REPEATED UNAUTHORIZED ACCESS
    # ========================================================

    connection = get_connection()
    cursor = connection.cursor()

    repeated_query = """

        SELECT COUNT(*)

        FROM access_events

        WHERE user_id = ?
          AND result = 'DENY'
          AND event_timestamp >= DATEADD(HOUR, -24, ?)

    """

    cursor.execute(
        repeated_query,
        user_id,
        event_timestamp
    )

    denied_count = cursor.fetchone()[0]

    cursor.close()
    connection.close()

    if denied_count >= 3:

        risk_score += RISK_WEIGHTS["REPEATED_UNAUTHORIZED"]

        detections.append("REPEATED_UNAUTHORIZED_ACCESS")

        reasons.append(
            f"{denied_count} denied access attempts were recorded "
            "for this user within 24 hours."
        )


    # ========================================================
    # CAP RISK SCORE
    # ========================================================

    risk_score = min(risk_score, 100)


    # ========================================================
    # DETERMINE SEVERITY
    # ========================================================

    severity = get_severity(risk_score)


    # ========================================================
    # ANALYSIS RESULT
    # ========================================================

    return {

        "success": True,

        "event_id": event_id,
        "user_id": user_id,

        "employee_code": employee_code,
        "full_name": full_name,

        "role": role_name,
        "department": department_name,

        "device": device_name,
        "device_type": device_type,

        "resource": resource_name,
        "resource_type": resource_type,
        "sensitivity": sensitivity,

        "event_type": event_type,
        "action": action,
        "result": result,

        "source_ip": source_ip,
        "location": location,
        "auth_method": auth_method,

        "risk_score": risk_score,
        "severity": severity,

        "detections": detections,
        "reasons": reasons,

        "is_suspicious": risk_score >= 40
    }

# ============================================================
# BATCH ANALYSIS
# ============================================================

def analyze_all_events(limit=None):
    """
    Analyze access events from SQL Server.

    If limit is provided, only the newest 'limit' events
    are analyzed.
    """

    connection = get_connection()
    cursor = connection.cursor()

    if limit is not None:
        query = """
            SELECT TOP (?)
                event_id
            FROM access_events
            ORDER BY event_timestamp DESC
        """

        cursor.execute(query, limit)

    else:
        query = """
            SELECT
                event_id
            FROM access_events
            ORDER BY event_timestamp DESC
        """

        cursor.execute(query)

    rows = cursor.fetchall()

    cursor.close()
    connection.close()

    results = []

    for row in rows:

        event_id = row[0]

        try:
            result = analyze_event(event_id)

            if result.get("success"):
                results.append(result)

        except Exception as error:

            results.append({
                "success": False,
                "event_id": event_id,
                "message": str(error)
            })

    return results


# ============================================================
# SAVE RISK SCORES
# ============================================================

def save_risk_scores(results):
    """
    Persist calculated event risk scores and refresh user risk scores.

    Event risk scores are written back to access_events.
    Each user's risk_score is set to the highest persisted event risk
    score currently associated with that user.
    """

    connection = get_connection()
    cursor = connection.cursor()

    updated_events = 0

    try:
        for result in results:
            if not result.get("success"):
                continue

            event_id = result.get("event_id")
            risk_score = result.get("risk_score", 0)

            cursor.execute(
                """
                UPDATE access_events
                SET risk_score = ?
                WHERE event_id = ?
                """,
                risk_score,
                event_id
            )

            updated_events += 1

        cursor.execute(
            """
            UPDATE users
            SET risk_score = ISNULL(
                (
                    SELECT MAX(ae.risk_score)
                    FROM access_events ae
                    WHERE ae.user_id = users.user_id
                ),
                0
            )
            """
        )

        updated_users = cursor.rowcount
        connection.commit()

    except Exception:
        connection.rollback()
        raise

    finally:
        cursor.close()
        connection.close()

    return updated_events, updated_users


# ============================================================
# SAVE SECURITY ALERTS
# ============================================================

def save_security_alerts(results):
    """
    Save suspicious analysis findings into security_alerts.

    One alert is created for each detection on an event.
    Existing (event_id, alert_type) combinations are not duplicated.
    """

    connection = get_connection()
    cursor = connection.cursor()

    inserted_count = 0

    try:
        for result in results:

            if not result.get("success"):
                continue

            if not result.get("is_suspicious"):
                continue

            event_id = result.get("event_id")
            user_id = result.get("user_id")
            severity = result.get("severity", "LOW")
            risk_score = result.get("risk_score", 0)
            detections = result.get("detections", [])
            reasons = result.get("reasons", [])

            for index, detection in enumerate(detections):

                reason = (
                    reasons[index]
                    if index < len(reasons)
                    else "Suspicious activity detected by the AEGIS analysis engine."
                )

                duplicate_query = """
                    SELECT 1
                    FROM security_alerts
                    WHERE event_id = ?
                      AND alert_type = ?
                """

                cursor.execute(
                    duplicate_query,
                    event_id,
                    detection
                )

                if cursor.fetchone():
                    continue

                insert_query = """
                    INSERT INTO security_alerts (
                        event_id,
                        user_id,
                        alert_type,
                        severity,
                        risk_score,
                        description,
                        status,
                        created_at
                    )
                    VALUES (?, ?, ?, ?, ?, ?, 'OPEN', SYSDATETIME())
                """

                cursor.execute(
                    insert_query,
                    event_id,
                    user_id,
                    detection,
                    severity,
                    risk_score,
                    reason
                )

                inserted_count += 1

        connection.commit()

    except Exception:
        connection.rollback()
        raise

    finally:
        cursor.close()
        connection.close()

    return inserted_count


# ============================================================
# ANALYSIS SUMMARY
# ============================================================

def get_analysis_summary(results):

    summary = {
        "total_events": len(results),
        "suspicious_events": 0,
        "low": 0,
        "medium": 0,
        "high": 0,
        "critical": 0,
        "detections": {}
    }

    for result in results:

        if not result.get("success"):
            continue

        if result.get("is_suspicious"):
            summary["suspicious_events"] += 1

        severity = result.get("severity", "LOW").upper()

        if severity == "LOW":
            summary["low"] += 1

        elif severity == "MEDIUM":
            summary["medium"] += 1

        elif severity == "HIGH":
            summary["high"] += 1

        elif severity == "CRITICAL":
            summary["critical"] += 1

        for detection in result.get("detections", []):

            if detection not in summary["detections"]:
                summary["detections"][detection] = 0

            summary["detections"][detection] += 1

    return summary



# ============================================================
# USER BEHAVIOR ANALYSIS - STEP 5
# ============================================================

def analyze_user_behavior(user_id):
    """
    Analyze a user's activity patterns over the last 24 hours.

    This layer complements event-level risk analysis by looking for
    repeated or concentrated behavior across multiple events.
    """

    connection = get_connection()
    cursor = connection.cursor()

    query = """
        SELECT
            u.user_id,
            u.employee_code,
            u.full_name,
            u.risk_score,
            COUNT(ae.event_id) AS total_events,
            SUM(CASE WHEN ae.result = 'DENY' THEN 1 ELSE 0 END) AS denied_events,
            SUM(
                CASE
                    WHEN ae.risk_score >= 40 THEN 1
                    ELSE 0
                END
            ) AS suspicious_events,
            COUNT(
                DISTINCT CASE
                    WHEN res.sensitivity IN ('CONFIDENTIAL', 'RESTRICTED', 'CRITICAL')
                    THEN ae.resource_id
                END
            ) AS sensitive_resources,
            COUNT(
                DISTINCT CASE
                    WHEN res.department_id IS NOT NULL
                     AND d.department_id <> res.department_id
                    THEN res.department_id
                END
            ) AS cross_department_count
        FROM users u
        LEFT JOIN access_events ae
            ON u.user_id = ae.user_id
           AND ae.event_timestamp >= DATEADD(HOUR, -24, SYSDATETIME())
        LEFT JOIN roles r
            ON u.role_id = r.role_id
        LEFT JOIN departments d
            ON r.department_id = d.department_id
        LEFT JOIN resources res
            ON ae.resource_id = res.resource_id
        WHERE u.user_id = ?
        GROUP BY
            u.user_id,
            u.employee_code,
            u.full_name,
            u.risk_score,
            d.department_id
    """

    cursor.execute(query, user_id)
    row = cursor.fetchone()

    if not row:
        cursor.close()
        connection.close()
        return None

    columns = [column[0] for column in cursor.description]
    profile = dict(zip(columns, row))

    cursor.close()
    connection.close()

    # Convert SQL NULL aggregate values to zero.
    for field in (
        "total_events",
        "denied_events",
        "suspicious_events",
        "sensitive_resources",
        "cross_department_count"
    ):
        profile[field] = profile.get(field) or 0

    indicators = []
    behavior_risk = 0

    if profile["denied_events"] >= 3:
        indicators.append(
            f"{profile['denied_events']} denied access attempts in the last 24 hours."
        )
        behavior_risk += 25

    if profile["sensitive_resources"] >= 3:
        indicators.append(
            f"Accessed {profile['sensitive_resources']} sensitive resources in the last 24 hours."
        )
        behavior_risk += 25

    if profile["cross_department_count"] >= 2:
        indicators.append(
            f"Activity spans {profile['cross_department_count']} other departments."
        )
        behavior_risk += 25

    if profile["suspicious_events"] >= 3:
        indicators.append(
            f"{profile['suspicious_events']} suspicious events recorded in the last 24 hours."
        )
        behavior_risk += 25

    behavior_risk = min(behavior_risk, 100)

    if behavior_risk >= 70:
        behavior_severity = "HIGH"
    elif behavior_risk >= 40:
        behavior_severity = "MEDIUM"
    elif behavior_risk > 0:
        behavior_severity = "LOW"
    else:
        behavior_severity = "NORMAL"

    profile["behavior_risk"] = behavior_risk
    profile["behavior_severity"] = behavior_severity
    profile["indicators"] = indicators
    profile["is_suspicious_behavior"] = behavior_risk >= 40

    return profile


def get_behavior_risk_users(min_risk=40, limit=10):
    """
    Return users whose recent behavior indicates elevated risk.
    """

    connection = get_connection()
    cursor = connection.cursor()

    query = """
        SELECT TOP (?)
            u.user_id,
            u.employee_code,
            u.full_name,
            u.risk_score,
            SUM(CASE WHEN ae.result = 'DENY' THEN 1 ELSE 0 END) AS denied_events,
            SUM(CASE WHEN ae.risk_score >= 40 THEN 1 ELSE 0 END) AS suspicious_events,
            COUNT(
                DISTINCT CASE
                    WHEN res.sensitivity IN ('CONFIDENTIAL', 'RESTRICTED', 'CRITICAL')
                    THEN ae.resource_id
                END
            ) AS sensitive_resources
        FROM users u
        LEFT JOIN access_events ae
            ON u.user_id = ae.user_id
           AND ae.event_timestamp >= DATEADD(HOUR, -24, SYSDATETIME())
        LEFT JOIN resources res
            ON ae.resource_id = res.resource_id
        GROUP BY
            u.user_id,
            u.employee_code,
            u.full_name,
            u.risk_score
                HAVING
            u.risk_score >= ?
            AND
            (
                SUM(CASE WHEN ae.result = 'DENY' THEN 1 ELSE 0 END) >= 3
                OR SUM(CASE WHEN ae.risk_score >= 40 THEN 1 ELSE 0 END) >= 3
                OR COUNT(
                    DISTINCT CASE
                        WHEN res.sensitivity IN ('CONFIDENTIAL', 'RESTRICTED', 'CRITICAL')
                        THEN ae.resource_id
                    END
                ) >= 3
            )
        ORDER BY
            u.risk_score DESC,
            u.employee_code ASC
    """

    cursor.execute(query, limit, min_risk)
    rows = cursor.fetchall()
    columns = [column[0] for column in cursor.description]

    users = [dict(zip(columns, row)) for row in rows]

    cursor.close()
    connection.close()

    return users

# ============================================================
# RUN FULL AEGIS ANALYSIS
# ============================================================

def run_analysis(limit=None):

    print()
    print("=" * 60)
    print("AEGIS SECURITY ANALYSIS")
    print("=" * 60)

    print()
    print("Loading access events from SQL Server...")

    results = analyze_all_events(limit)

    print(f"Events analyzed : {len(results)}")

    events_updated, users_updated = save_risk_scores(results)
    print(f"Event risk scores updated: {events_updated}")
    print(f"User risk scores updated : {users_updated}")

    alerts_saved = save_security_alerts(results)
    print(f"New alerts saved: {alerts_saved}")

    summary = get_analysis_summary(results)

    print()
    print("-" * 60)
    print("ANALYSIS SUMMARY")
    print("-" * 60)

    print(
        f"Total events       : "
        f"{summary['total_events']}"
    )

    print(
        f"Suspicious events  : "
        f"{summary['suspicious_events']}"
    )

    print(
        f"Low severity       : "
        f"{summary['low']}"
    )

    print(
        f"Medium severity    : "
        f"{summary['medium']}"
    )

    print(
        f"High severity      : "
        f"{summary['high']}"
    )

    print(
        f"Critical severity  : "
        f"{summary['critical']}"
    )

    print()
    print("DETECTION COUNTS")
    print("-" * 60)

    if summary["detections"]:

        for detection, count in sorted(
            summary["detections"].items(),
            key=lambda item: item[1],
            reverse=True
        ):

            print(
                f"{detection:<35} : {count}"
            )

    else:

        print("No detections.")

    print()
    print("=" * 60)

    return results, summary
# ============================================================
# TEST THE ENGINE
# ============================================================

if __name__ == "__main__":
    results, summary = run_analysis()

if __name__ == "__main__":
    run_analysis(limit=8)
