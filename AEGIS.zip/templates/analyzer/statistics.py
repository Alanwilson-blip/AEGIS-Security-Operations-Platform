def count_devices(accounts):

    known = 0
    pending = 0
    blocked = 0

    for username in accounts:

        known += len(
            accounts[username]["known_devices"]
        )

        pending += len(
            accounts[username]["pending_devices"]
        )

        blocked += len(
            accounts[username]["blocked_devices"]
        )

    return known, pending, blocked



def count_incidents_by_severity(incidents):

    critical = 0
    high = 0
    medium = 0
    low = 0

    for incident in incidents:

        severity = incident["severity"]

        if severity == "CRITICAL":
            critical += 1

        elif severity == "HIGH":
            high += 1

        elif severity == "MEDIUM":
            medium += 1

        elif severity == "LOW":
            low += 1

    return critical, high, medium, low


def find_most_targeted_user(incidents):

    user_counts = {}

    for incident in incidents:

        username = incident["username"]

        if username not in user_counts:
            user_counts[username] = 0

        user_counts[username] += 1

    if len(user_counts) == 0:
        return None, 0

    most_targeted = max(
        user_counts,
        key=user_counts.get
    )

    return (
        most_targeted,
        user_counts[most_targeted]
    )

def calculate_average_trust(accounts):

    total_trust = 0
    device_count = 0

    for username in accounts:

        for device in accounts[username]["known_devices"]:

            trust_score = (
                accounts[username]
                ["known_devices"]
                [device]
                ["trust_score"]
            )

            total_trust += trust_score

            device_count += 1

    if device_count == 0:
        return 0

    return round(
        total_trust / device_count,
        2
    )

def count_investigation_decisions(investigation_history):

    approved = 0
    blocked = 0

    for investigation in investigation_history:

        if investigation["decision"] == "Approved":
            approved += 1

        elif investigation["decision"] == "Blocked":
            blocked += 1

    return approved, blocked
